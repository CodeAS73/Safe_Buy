-- ============================================================================
-- Migration 0001: Extensions, Schemas, Enums
-- Safe Buy (buysafely.africa) — Escrow Commerce Platform
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "pgcrypto";   -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "citext";     -- case-insensitive email/handle

-- ---------------------------------------------------------------------------
-- Schemas (one per bounded context / database module)
-- ---------------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS merchant;
CREATE SCHEMA IF NOT EXISTS catalog;
CREATE SCHEMA IF NOT EXISTS orders;
CREATE SCHEMA IF NOT EXISTS escrow;
CREATE SCHEMA IF NOT EXISTS payments;
CREATE SCHEMA IF NOT EXISTS delivery;
CREATE SCHEMA IF NOT EXISTS insurance;
CREATE SCHEMA IF NOT EXISTS support;
CREATE SCHEMA IF NOT EXISTS fees;
CREATE SCHEMA IF NOT EXISTS hr;
CREATE SCHEMA IF NOT EXISTS bi;
CREATE SCHEMA IF NOT EXISTS sys;

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------

-- Merchant
CREATE TYPE merchant.onboarding_step AS ENUM ('KYC', 'TILL_LINKED', 'VERIFIED');
CREATE TYPE merchant.fee_plan_kind AS ENUM ('DEFAULT', 'CUSTOM', 'CAMPAIGN', 'ENTERPRISE');

-- Catalog
CREATE TYPE catalog.product_category AS ENUM (
  'Apparel & Fashion', 'Electronics & Gadgets', 'Vehicles & Motors',
  'Machinery & Tools', 'Furniture & Living', 'Other Products'
);
CREATE TYPE catalog.verification_status AS ENUM (
  'UNVERIFIED', 'AUDITOR_ASSIGNED', 'INSPECTION_COMPLETED', 'VERIFIED', 'EXPIRED'
);
CREATE TYPE catalog.verification_tier AS ENUM ('STANDARD', 'PRIORITY', 'PREMIUM');
CREATE TYPE catalog.condition_grade AS ENUM ('Excellent', 'Good', 'Fair', 'Poor');
CREATE TYPE catalog.verification_outcome AS ENUM ('Verified', 'Verified with Notes', 'Verification Failed');
CREATE TYPE catalog.bulk_plan AS ENUM ('NONE', 'BASIC', 'GROWTH', 'ENTERPRISE');

-- Orders
CREATE TYPE orders.transaction_status AS ENUM (
  'PENDING_DEPOSIT', 'ESCROW_HELD', 'ITEMS_SHIPPED', 'FUNDS_RELEASED', 'DISPUTED', 'REFUNDED'
);
CREATE TYPE orders.social_platform AS ENUM ('WhatsApp', 'Instagram', 'TikTok', 'Facebook', 'Telegram');
CREATE TYPE orders.buyer_account_type AS ENUM ('GUEST', 'REGISTERED');
CREATE TYPE orders.shipping_method AS ENUM ('Courier', 'Pickup', 'Seller Delivery');
CREATE TYPE orders.timeline_actor AS ENUM ('BUYER', 'SELLER', 'SYSTEM', 'AI_MODERATOR', 'HUMAN_MODERATOR');
CREATE TYPE orders.escrow_model AS ENUM ('model_1', 'model_2');
CREATE TYPE orders.package_status AS ENUM ('PICKUP_REQUESTED', 'IN_TRANSIT', 'DELIVERED', 'CONFIRMED');

-- Payments
CREATE TYPE payments.network AS ENUM ('mpesa', 'airtel', 'tcash');
CREATE TYPE payments.escrow_fee_payer AS ENUM ('BUYER', 'SELLER', 'SHARED', 'SPONSORED', 'WAIVED');
CREATE TYPE payments.stk_status AS ENUM ('INITIATED', 'PENDING', 'SUCCESS', 'FAILED', 'TIMEOUT', 'CANCELLED');

-- Delivery
CREATE TYPE delivery.partner_type AS ENUM ('COURIER', 'RIDER', 'DRIVER', 'PICKER');
CREATE TYPE delivery.availability AS ENUM ('ONLINE', 'OFFLINE', 'BUSY');
CREATE TYPE delivery.status AS ENUM (
  'PICKUP_REQUESTED', 'COURIER_ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'ARRIVED', 'DELIVERED', 'CONFIRMED'
);

-- Insurance
CREATE TYPE insurance.policy_kind AS ENUM ('NONE', 'BUYER_CHOOSES', 'SELLER_COVERS', 'MANDATORY');
CREATE TYPE insurance.option_kind AS ENUM ('NONE', 'BASIC', 'ENHANCED');
CREATE TYPE insurance.paid_by AS ENUM ('BUYER', 'SELLER', 'SHARED', 'NONE');
CREATE TYPE insurance.claim_status AS ENUM (
  'SUBMITTED', 'UNDER_REVIEW', 'AWAITING_EVIDENCE', 'APPROVED', 'REJECTED', 'PAID'
);
CREATE TYPE insurance.claim_type AS ENUM ('DAMAGE', 'LOSS');
CREATE TYPE insurance.structure AS ENUM ('ORDER', 'ITEM');

-- Support / CRM / Field Ops
CREATE TYPE support.urgency AS ENUM ('Low', 'Medium', 'High', 'Critical');
CREATE TYPE support.ticket_status AS ENUM ('OPEN', 'RESOLVED');
CREATE TYPE support.recommendation AS ENUM (
  'Release Funds to Seller', 'Refund Buyer', 'Partial Refund', 'Courier Compensation',
  'Reject Claim', 'Escalate to Fraud Team', 'Escalate to Field Operations'
);
CREATE TYPE support.outcome AS ENUM (
  'Approve Recommendation', 'Modify Recommendation', 'Return for More Information',
  'Escalate to CRM Manager', 'Escalate to Finance', 'Escalate to Fraud Review'
);
CREATE TYPE support.financial_action AS ENUM (
  'Release Escrow', 'Full Refund', 'Partial Refund', 'Split Settlement', 'Hold Funds',
  'Fraud Investigation Hold', 'None'
);
CREATE TYPE support.charge_status AS ENUM ('UNPAID', 'PAID');

-- Fees / Settlement
CREATE TYPE fees.audit_status AS ENUM ('PENDING', 'IN_REVIEW', 'RESOLVED', 'ESCALATED');
CREATE TYPE fees.settlement_status AS ENUM ('PENDING', 'PROCESSING', 'SETTLED', 'FAILED', 'REVERSED');
CREATE TYPE fees.reconciliation_status AS ENUM ('PENDING', 'MATCHED', 'MISMATCHED', 'RESOLVED');

-- HR
CREATE TYPE hr.leave_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

-- BI
CREATE TYPE bi.security_level AS ENUM ('PUBLIC', 'INTERNAL', 'CONFIDENTIAL', 'RESTRICTED', 'EXECUTIVE');
CREATE TYPE bi.viz_type AS ENUM ('table', 'line', 'bar', 'pie', 'heatmap', 'kpi');
CREATE TYPE bi.frequency AS ENUM ('Daily', 'Weekly', 'Monthly', 'Quarterly');
CREATE TYPE bi.export_format AS ENUM ('Excel', 'CSV', 'PDF', 'PPT');

COMMIT;

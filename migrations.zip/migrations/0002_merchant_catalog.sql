-- ============================================================================
-- Migration 0002: Merchant & Catalog
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- merchant.merchants
-- ---------------------------------------------------------------------------
CREATE TABLE merchant.merchants (
  id                          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_name               text NOT NULL,
  seller_handle               citext NOT NULL UNIQUE,
  phone                       text NOT NULL UNIQUE,
  email                       citext NOT NULL UNIQUE,
  onboarding_step             merchant.onboarding_step NOT NULL DEFAULT 'KYC',
  verified_at                 timestamptz,
  volume_ksh                  numeric(14,2) NOT NULL DEFAULT 0 CHECK (volume_ksh >= 0),
  trust_rating                numeric(5,2) NOT NULL DEFAULT 0 CHECK (trust_rating BETWEEN 0 AND 100),
  default_fee_plan            merchant.fee_plan_kind NOT NULL DEFAULT 'DEFAULT',
  custom_fee_plan_id          uuid,
  campaign_fee_plan_id        uuid,
  enterprise_fee_plan_id      uuid,
  fee_override_approved_by    text,
  fee_override_approved_date  timestamptz,
  created_at                  timestamptz NOT NULL DEFAULT now(),
  updated_at                  timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE merchant.merchants IS 'Sellers operating storefronts/checkout widgets on social platforms.';

CREATE INDEX idx_merchants_onboarding_step ON merchant.merchants (onboarding_step);
CREATE INDEX idx_merchants_seller_handle   ON merchant.merchants (seller_handle);

-- ---------------------------------------------------------------------------
-- merchant.fee_override_history (was a JSON array on Merchant; normalized)
-- ---------------------------------------------------------------------------
CREATE TABLE merchant.fee_override_history (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id   uuid NOT NULL REFERENCES merchant.merchants(id) ON DELETE CASCADE,
  approved_by   text NOT NULL,
  approved_at   timestamptz NOT NULL DEFAULT now(),
  previous_plan merchant.fee_plan_kind,
  new_plan      merchant.fee_plan_kind,
  notes         text
);

CREATE INDEX idx_fee_override_history_merchant ON merchant.fee_override_history (merchant_id);

-- ---------------------------------------------------------------------------
-- catalog.products  (VerifiedProduct)
-- ---------------------------------------------------------------------------
CREATE TABLE catalog.products (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id           uuid NOT NULL REFERENCES merchant.merchants(id) ON DELETE CASCADE,
  title                 text NOT NULL,
  category              catalog.product_category NOT NULL,
  price                 numeric(14,2) NOT NULL CHECK (price >= 0),
  description           text,
  seller_handle         citext NOT NULL,
  seller_phone          text NOT NULL,
  verification_status   catalog.verification_status NOT NULL DEFAULT 'UNVERIFIED',
  verification_tier     catalog.verification_tier,
  verification_fee      numeric(14,2) CHECK (verification_fee >= 0),
  auditor_id            uuid,
  bulk_plan_subscribed  catalog.bulk_plan NOT NULL DEFAULT 'NONE',
  is_featured           boolean NOT NULL DEFAULT false,
  verified_at           timestamptz,
  expires_at            timestamptz,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT chk_verified_at_requires_status
    CHECK (verified_at IS NULL OR verification_status IN ('VERIFIED', 'EXPIRED'))
);

CREATE INDEX idx_products_merchant   ON catalog.products (merchant_id);
CREATE INDEX idx_products_category   ON catalog.products (category);
CREATE INDEX idx_products_verif_stat ON catalog.products (verification_status);
CREATE INDEX idx_products_featured   ON catalog.products (is_featured) WHERE is_featured = true;

-- ---------------------------------------------------------------------------
-- catalog.auditors
-- ---------------------------------------------------------------------------
CREATE TABLE catalog.auditors (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,
  phone       text,
  email       citext,
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE catalog.products
  ADD CONSTRAINT fk_products_auditor
  FOREIGN KEY (auditor_id) REFERENCES catalog.auditors(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- catalog.verification_reports (1:1 with product at time of inspection,
-- kept as its own table to allow re-inspection history)
-- ---------------------------------------------------------------------------
CREATE TABLE catalog.verification_reports (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id        uuid NOT NULL REFERENCES catalog.products(id) ON DELETE CASCADE,
  auditor_id        uuid REFERENCES catalog.auditors(id) ON DELETE SET NULL,
  condition         catalog.condition_grade NOT NULL,
  functional_pass   boolean NOT NULL,
  serial_number     text,
  notes             text,
  outcome           catalog.verification_outcome NOT NULL,
  submitted_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_verification_reports_product ON catalog.verification_reports (product_id);

CREATE TABLE catalog.verification_report_photos (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id    uuid NOT NULL REFERENCES catalog.verification_reports(id) ON DELETE CASCADE,
  photo_url    text NOT NULL,
  position     smallint NOT NULL DEFAULT 0
);

CREATE INDEX idx_verif_report_photos_report ON catalog.verification_report_photos (report_id);

COMMIT;

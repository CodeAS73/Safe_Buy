-- ============================================================================
-- Migration 0003: Orders (Transaction core + cart/package/timeline)
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- orders.transactions  (the central hub entity of the whole platform)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.transactions (
  id                              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id                      uuid REFERENCES catalog.products(id) ON DELETE SET NULL,
  merchant_id                     uuid REFERENCES merchant.merchants(id) ON DELETE SET NULL,

  buyer_phone                     text NOT NULL,
  buyer_email                     citext,
  buyer_name                      text,
  buyer_account_type              orders.buyer_account_type NOT NULL DEFAULT 'GUEST',
  buyer_national_id               text,
  is_not_recipient                boolean NOT NULL DEFAULT false,

  seller_phone                    text NOT NULL,
  seller_handle                   citext NOT NULL,
  social_platform                 orders.social_platform NOT NULL,

  amount                          numeric(14,2) NOT NULL CHECK (amount >= 0),
  fee                             numeric(14,2) NOT NULL DEFAULT 0 CHECK (fee >= 0),
  platform_fee                    numeric(14,2) DEFAULT 0 CHECK (platform_fee >= 0),
  quantity                        integer NOT NULL DEFAULT 1 CHECK (quantity > 0),

  description                     text,
  status                          orders.transaction_status NOT NULL DEFAULT 'PENDING_DEPOSIT',

  shipping_method                 orders.shipping_method,
  shipping_fee                    numeric(14,2) DEFAULT 0 CHECK (shipping_fee >= 0),
  total_amount                    numeric(14,2) CHECK (total_amount >= 0),

  shipping_proof_url              text,

  countdown_hours                 integer NOT NULL DEFAULT 0 CHECK (countdown_hours >= 0),
  risk_score                      numeric(5,2) NOT NULL DEFAULT 0 CHECK (risk_score BETWEEN 0 AND 100),
  buyer_trust_score                numeric(5,2) NOT NULL DEFAULT 0 CHECK (buyer_trust_score BETWEEN 0 AND 100),
  seller_trust_score               numeric(5,2) NOT NULL DEFAULT 0 CHECK (seller_trust_score BETWEEN 0 AND 100),

  order_status                    text,
  cart_enabled                    boolean NOT NULL DEFAULT false,
  escrow_model                    orders.escrow_model,

  created_at                      timestamptz NOT NULL DEFAULT now(),
  updated_at                      timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE orders.transactions IS 'Central escrow order entity. Every other module FKs to this table.';

CREATE INDEX idx_tx_merchant     ON orders.transactions (merchant_id);
CREATE INDEX idx_tx_product      ON orders.transactions (product_id);
CREATE INDEX idx_tx_status       ON orders.transactions (status);
CREATE INDEX idx_tx_buyer_phone  ON orders.transactions (buyer_phone);
CREATE INDEX idx_tx_seller_phone ON orders.transactions (seller_phone);
CREATE INDEX idx_tx_created_at   ON orders.transactions (created_at DESC);
CREATE INDEX idx_tx_social       ON orders.transactions (social_platform);

-- ---------------------------------------------------------------------------
-- orders.recipient_details (1:1, only set when is_not_recipient = true)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.recipient_details (
  transaction_id   uuid PRIMARY KEY REFERENCES orders.transactions(id) ON DELETE CASCADE,
  name             text NOT NULL,
  phone            text NOT NULL,
  address          text NOT NULL,
  relationship     text
);

-- ---------------------------------------------------------------------------
-- orders.shipping_details (1:1)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.shipping_details (
  transaction_id     uuid PRIMARY KEY REFERENCES orders.transactions(id) ON DELETE CASCADE,
  county              text,
  town                text,
  address             text,
  contact_person      text,
  phone               text,
  pickup_location     text,
  pickup_date         date,
  pickup_contact      text,
  delivery_area       text,
  delivery_contact    text
);

-- ---------------------------------------------------------------------------
-- orders.timeline_events (audit trail per transaction)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.timeline_events (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  status          text NOT NULL,
  title           text NOT NULL,
  description     text,
  actor           orders.timeline_actor NOT NULL,
  occurred_at     timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_timeline_events_tx ON orders.timeline_events (transaction_id, occurred_at);

-- ---------------------------------------------------------------------------
-- orders.cart_items
-- ---------------------------------------------------------------------------
CREATE TABLE orders.cart_items (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id     uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  product_id         uuid REFERENCES catalog.products(id) ON DELETE SET NULL,
  title              text NOT NULL,
  price              numeric(14,2) NOT NULL CHECK (price >= 0),
  quantity           integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  insured            boolean NOT NULL DEFAULT false,
  delivery_status    text,
  released_amount    numeric(14,2) DEFAULT 0 CHECK (released_amount >= 0)
);

CREATE INDEX idx_cart_items_tx ON orders.cart_items (transaction_id);

-- ---------------------------------------------------------------------------
-- orders.packages (multi-parcel shipments for cart-enabled orders)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.packages (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id    uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  carrier           text,
  status            orders.package_status NOT NULL DEFAULT 'PICKUP_REQUESTED',
  shipping_fee      numeric(14,2) NOT NULL DEFAULT 0 CHECK (shipping_fee >= 0),
  tracking_number   text,
  released          boolean NOT NULL DEFAULT false,
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_packages_tx ON orders.packages (transaction_id);

CREATE TABLE orders.package_items (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id   uuid NOT NULL REFERENCES orders.packages(id) ON DELETE CASCADE,
  cart_item_id uuid REFERENCES orders.cart_items(id) ON DELETE SET NULL,
  title        text NOT NULL,
  price        numeric(14,2) NOT NULL CHECK (price >= 0),
  quantity     integer NOT NULL DEFAULT 1 CHECK (quantity > 0)
);

CREATE INDEX idx_package_items_package ON orders.package_items (package_id);

COMMIT;

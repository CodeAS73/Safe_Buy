-- ============================================================================
-- Migration 0004: Escrow, Payments, Risk & AI Verification
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- escrow.wallets — singleton-per-currency platform wallet
-- ---------------------------------------------------------------------------
CREATE TABLE escrow.wallets (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  currency              text NOT NULL DEFAULT 'Ksh',
  total_escrow_held     numeric(16,2) NOT NULL DEFAULT 0,
  total_fees_collected  numeric(16,2) NOT NULL DEFAULT 0,
  total_settled         numeric(16,2) NOT NULL DEFAULT 0,
  reserve_pool          numeric(16,2) NOT NULL DEFAULT 0,
  updated_at            timestamptz NOT NULL DEFAULT now(),
  UNIQUE (currency)
);

-- ---------------------------------------------------------------------------
-- escrow.ledger_entries — append-only double-entry style ledger per transaction
-- ---------------------------------------------------------------------------
CREATE TABLE escrow.ledger_entries (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id       uuid NOT NULL REFERENCES escrow.wallets(id),
  transaction_id  uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  entry_type      text NOT NULL CHECK (entry_type IN ('DEPOSIT', 'RELEASE', 'REFUND', 'FEE', 'ADJUSTMENT')),
  amount          numeric(14,2) NOT NULL,
  balance_after   numeric(16,2) NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  created_by      text
);

CREATE INDEX idx_ledger_entries_tx     ON escrow.ledger_entries (transaction_id);
CREATE INDEX idx_ledger_entries_wallet ON escrow.ledger_entries (wallet_id, created_at);

-- ---------------------------------------------------------------------------
-- payments.payment_attempts (STK push / mpesa-airtel-tcash)
-- ---------------------------------------------------------------------------
CREATE TABLE payments.payment_attempts (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id      uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  network             payments.network NOT NULL,
  amount              numeric(14,2) NOT NULL CHECK (amount >= 0),
  status              payments.stk_status NOT NULL DEFAULT 'INITIATED',
  mpesa_code          text,
  initiated_at        timestamptz NOT NULL DEFAULT now(),
  resolved_at         timestamptz
);

CREATE INDEX idx_payment_attempts_tx ON payments.payment_attempts (transaction_id);
CREATE UNIQUE INDEX uq_payment_attempts_mpesa_code ON payments.payment_attempts (mpesa_code) WHERE mpesa_code IS NOT NULL;

-- ---------------------------------------------------------------------------
-- payments.fee_ledger — per-transaction fee breakdown (revenue split)
-- ---------------------------------------------------------------------------
CREATE TABLE payments.fee_ledger (
  transaction_id                 uuid PRIMARY KEY REFERENCES orders.transactions(id) ON DELETE CASCADE,
  merchant_success_fee           numeric(14,2) DEFAULT 0,
  escrow_fee                     numeric(14,2) DEFAULT 0,
  communication_fee              numeric(14,2) DEFAULT 0,
  insurance_fee                  numeric(14,2) DEFAULT 0,
  logistics_commission           numeric(14,2) DEFAULT 0,
  courier_revenue                numeric(14,2) DEFAULT 0,
  picker_revenue                 numeric(14,2) DEFAULT 0,
  psp_revenue                    numeric(14,2) DEFAULT 0,
  bank_revenue                   numeric(14,2) DEFAULT 0,
  platform_revenue               numeric(14,2) DEFAULT 0,
  escrow_fee_paid_by              payments.escrow_fee_payer,
  merchant_success_fee_rate_applied text,
  escrow_fee_rate_applied         text,
  campaign_applied                text,
  volume_tier_applied             text
);

-- ---------------------------------------------------------------------------
-- orders.security_scorecards (1:1 risk snapshot per transaction)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.security_scorecards (
  transaction_id           uuid PRIMARY KEY REFERENCES orders.transactions(id) ON DELETE CASCADE,
  velocity_limit_passed    boolean NOT NULL,
  device_fingerprint_score smallint NOT NULL CHECK (device_fingerprint_score BETWEEN 0 AND 100),
  sim_swap_risk            text NOT NULL CHECK (sim_swap_risk IN ('LOW', 'MEDIUM', 'HIGH')),
  ip_location_match        boolean NOT NULL,
  overall_risk             smallint NOT NULL CHECK (overall_risk BETWEEN 0 AND 100),
  computed_at              timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- orders.ai_verification_results (receipt OCR / social-extract output)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.ai_verification_results (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id        uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  verified              boolean NOT NULL DEFAULT false,
  confidence            numeric(5,2) CHECK (confidence BETWEEN 0 AND 100),
  extracted_mpesa_code  text,
  extracted_carrier     text,
  merchant_name         text,
  detected_text         text,
  fraud_score           numeric(5,2) CHECK (fraud_score BETWEEN 0 AND 100),
  created_at            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_verification_tx ON orders.ai_verification_results (transaction_id);

CREATE TABLE orders.ai_verification_anomalies (
  id                       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ai_verification_result_id uuid NOT NULL REFERENCES orders.ai_verification_results(id) ON DELETE CASCADE,
  anomaly                  text NOT NULL
);

CREATE INDEX idx_ai_anomalies_result ON orders.ai_verification_anomalies (ai_verification_result_id);

COMMIT;

-- ============================================================================
-- Migration 0005: Delivery & Logistics
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- delivery.partners
-- ---------------------------------------------------------------------------
CREATE TABLE delivery.partners (
  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                   text NOT NULL,
  phone                  text NOT NULL UNIQUE,
  type                   delivery.partner_type NOT NULL,
  avatar_url             text,
  national_id            text,
  is_verified            boolean NOT NULL DEFAULT false,
  trust_score            numeric(5,2) NOT NULL DEFAULT 0 CHECK (trust_score BETWEEN 0 AND 100),
  completed_deliveries   integer NOT NULL DEFAULT 0 CHECK (completed_deliveries >= 0),
  dispute_rate           numeric(5,2) NOT NULL DEFAULT 0 CHECK (dispute_rate BETWEEN 0 AND 100),
  on_time_rate           numeric(5,2) NOT NULL DEFAULT 0 CHECK (on_time_rate BETWEEN 0 AND 100),
  feedback_score         numeric(5,2) NOT NULL DEFAULT 0 CHECK (feedback_score BETWEEN 0 AND 100),
  vehicle_details        text,
  driving_license        text,
  emergency_contact      text,
  availability           delivery.availability NOT NULL DEFAULT 'OFFLINE',
  ai_risk_score          numeric(5,2) NOT NULL DEFAULT 0 CHECK (ai_risk_score BETWEEN 0 AND 100),
  created_at             timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_partners_type         ON delivery.partners (type);
CREATE INDEX idx_partners_availability ON delivery.partners (availability);

-- ---------------------------------------------------------------------------
-- delivery.bids
-- ---------------------------------------------------------------------------
CREATE TABLE delivery.bids (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id    uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  partner_id        uuid NOT NULL REFERENCES delivery.partners(id) ON DELETE CASCADE,
  bid_amount        numeric(14,2) NOT NULL CHECK (bid_amount >= 0),
  estimated_hours   numeric(6,2) NOT NULL CHECK (estimated_hours >= 0),
  accepted          boolean NOT NULL DEFAULT false,
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_bids_tx      ON delivery.bids (transaction_id);
CREATE INDEX idx_bids_partner ON delivery.bids (partner_id);
-- a partner may bid only once per transaction
CREATE UNIQUE INDEX uq_bids_tx_partner ON delivery.bids (transaction_id, partner_id);

-- ---------------------------------------------------------------------------
-- orders.delivery_assignment (1:1 per transaction; the accepted partner/state)
-- ---------------------------------------------------------------------------
CREATE TABLE orders.delivery_assignment (
  transaction_id          uuid PRIMARY KEY REFERENCES orders.transactions(id) ON DELETE CASCADE,
  delivery_partner_id     uuid REFERENCES delivery.partners(id) ON DELETE SET NULL,
  delivery_pin            text,
  delivery_pin_entered    boolean NOT NULL DEFAULT false,
  delivery_status         delivery.status,
  delivery_risk_score     numeric(5,2) CHECK (delivery_risk_score BETWEEN 0 AND 100),
  picker_inspected        boolean NOT NULL DEFAULT false,
  picker_report           text,
  picker_fee              numeric(14,2) CHECK (picker_fee >= 0),
  delivery_agent_signature_url text,
  delivery_agent_photo_url     text
);

-- ---------------------------------------------------------------------------
-- delivery.milestones (audit trail of status transitions)
-- ---------------------------------------------------------------------------
CREATE TABLE delivery.milestones (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  status          delivery.status NOT NULL,
  recorded_at     timestamptz NOT NULL DEFAULT now(),
  notes           text
);

CREATE INDEX idx_delivery_milestones_tx ON delivery.milestones (transaction_id, recorded_at);

COMMIT;

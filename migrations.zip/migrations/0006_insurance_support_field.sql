-- ============================================================================
-- Migration 0006: Insurance, Support/CRM, Field Operations
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- insurance.policies (1:1 per transaction)
-- ---------------------------------------------------------------------------
CREATE TABLE insurance.policies (
  transaction_id   uuid PRIMARY KEY REFERENCES orders.transactions(id) ON DELETE CASCADE,
  policy_kind      insurance.policy_kind NOT NULL DEFAULT 'NONE',
  option_kind      insurance.option_kind NOT NULL DEFAULT 'NONE',
  premium          numeric(14,2) DEFAULT 0 CHECK (premium >= 0),
  paid_by          insurance.paid_by NOT NULL DEFAULT 'NONE',
  structure        insurance.structure NOT NULL DEFAULT 'ORDER'
);

-- ---------------------------------------------------------------------------
-- insurance.claims
-- ---------------------------------------------------------------------------
CREATE TABLE insurance.claims (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  type            insurance.claim_type NOT NULL,
  status          insurance.claim_status NOT NULL DEFAULT 'SUBMITTED',
  evidence_notes  text,
  feedback        text,
  payout_amount   numeric(14,2) CHECK (payout_amount >= 0),
  submitted_at    timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);

CREATE INDEX idx_claims_tx     ON insurance.claims (transaction_id);
CREATE INDEX idx_claims_status ON insurance.claims (status);

CREATE TABLE insurance.claim_evidence_photos (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id    uuid NOT NULL REFERENCES insurance.claims(id) ON DELETE CASCADE,
  photo_url   text NOT NULL
);

CREATE INDEX idx_claim_evidence_claim ON insurance.claim_evidence_photos (claim_id);

-- ---------------------------------------------------------------------------
-- support.tickets (CRM)
-- ---------------------------------------------------------------------------
CREATE TABLE support.tickets (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid REFERENCES orders.transactions(id) ON DELETE SET NULL,
  customer        text NOT NULL,
  category        text NOT NULL,
  urgency         support.urgency NOT NULL DEFAULT 'Medium',
  status          support.ticket_status NOT NULL DEFAULT 'OPEN',
  assigned_to     text,
  message         text,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_tickets_tx       ON support.tickets (transaction_id);
CREATE INDEX idx_tickets_status   ON support.tickets (status);
CREATE INDEX idx_tickets_urgency  ON support.tickets (urgency);

CREATE TABLE support.ticket_decisions (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id          uuid NOT NULL REFERENCES support.tickets(id) ON DELETE CASCADE,
  recommendation     support.recommendation,
  outcome            support.outcome,
  financial_action   support.financial_action,
  decided_by         text,
  decided_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_ticket_decisions_ticket ON support.ticket_decisions (ticket_id);

CREATE TABLE support.ticket_communications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id   uuid NOT NULL REFERENCES support.tickets(id) ON DELETE CASCADE,
  author      text NOT NULL,
  message     text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_ticket_comms_ticket ON support.ticket_communications (ticket_id);

CREATE TABLE support.ticket_appeals (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id    uuid NOT NULL REFERENCES support.tickets(id) ON DELETE CASCADE,
  reason       text NOT NULL,
  status       support.ticket_status NOT NULL DEFAULT 'OPEN',
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_ticket_appeals_ticket ON support.ticket_appeals (ticket_id);

-- ---------------------------------------------------------------------------
-- support.field_assignments
-- ---------------------------------------------------------------------------
CREATE TABLE support.field_assignments (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id        uuid REFERENCES merchant.merchants(id) ON DELETE SET NULL,
  transaction_id     uuid REFERENCES orders.transactions(id) ON DELETE SET NULL,
  location           text,
  task               text NOT NULL,
  status             text NOT NULL DEFAULT 'ASSIGNED',
  assignment_type    text,
  assigned_by        text,
  assigned_to        text,
  date_assigned      timestamptz NOT NULL DEFAULT now(),
  visit_date         date,
  visit_time         time,
  gps_coordinates    point,
  charge_amount      numeric(14,2) CHECK (charge_amount >= 0),
  charge_status      support.charge_status DEFAULT 'UNPAID',
  report_details     text
);

CREATE INDEX idx_field_assignments_merchant ON support.field_assignments (merchant_id);
CREATE INDEX idx_field_assignments_tx       ON support.field_assignments (transaction_id);
CREATE INDEX idx_field_assignments_status   ON support.field_assignments (status);

CREATE TABLE support.field_evidence (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id   uuid NOT NULL REFERENCES support.field_assignments(id) ON DELETE CASCADE,
  photo_url       text,
  notes           text,
  submitted_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_field_evidence_assignment ON support.field_evidence (assignment_id);

CREATE TABLE support.field_adjudications (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id      uuid NOT NULL REFERENCES support.field_assignments(id) ON DELETE CASCADE,
  risk_assessment    support.urgency NOT NULL DEFAULT 'Low',
  supervisor_action  text,
  adjudicated_by     text,
  adjudicated_at     timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_field_adjudications_assignment ON support.field_adjudications (assignment_id);

COMMIT;

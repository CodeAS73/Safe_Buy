-- ============================================================================
-- Migration 0007: Fees, Settlements & Finance Operations
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- fees.plans
-- ---------------------------------------------------------------------------
CREATE TABLE fees.plans (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  kind          merchant.fee_plan_kind NOT NULL,
  rate_config   jsonb NOT NULL DEFAULT '{}'::jsonb,  -- rate table per fee component
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_fee_plans_kind ON fees.plans (kind);

ALTER TABLE merchant.merchants
  ADD CONSTRAINT fk_merchant_custom_fee_plan     FOREIGN KEY (custom_fee_plan_id)     REFERENCES fees.plans(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_merchant_campaign_fee_plan    FOREIGN KEY (campaign_fee_plan_id)   REFERENCES fees.plans(id) ON DELETE SET NULL,
  ADD CONSTRAINT fk_merchant_enterprise_fee_plan  FOREIGN KEY (enterprise_fee_plan_id) REFERENCES fees.plans(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- fees.campaigns
-- ---------------------------------------------------------------------------
CREATE TABLE fees.campaigns (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  fee_plan_id   uuid REFERENCES fees.plans(id) ON DELETE SET NULL,
  starts_at     timestamptz NOT NULL,
  ends_at       timestamptz NOT NULL,
  approved_by   text,
  approved_at   timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT chk_campaign_window CHECK (ends_at > starts_at)
);

CREATE INDEX idx_campaigns_window ON fees.campaigns (starts_at, ends_at);

-- ---------------------------------------------------------------------------
-- fees.psp_configs (Payment Service Provider configs)
-- ---------------------------------------------------------------------------
CREATE TABLE fees.psp_configs (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider     text NOT NULL,
  network      payments.network NOT NULL,
  config       jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_active    boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, network)
);

-- ---------------------------------------------------------------------------
-- fees.settlements
-- ---------------------------------------------------------------------------
CREATE TABLE fees.settlements (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id     uuid NOT NULL REFERENCES merchant.merchants(id) ON DELETE CASCADE,
  transaction_id  uuid REFERENCES orders.transactions(id) ON DELETE SET NULL,
  amount          numeric(14,2) NOT NULL CHECK (amount >= 0),
  status          fees.settlement_status NOT NULL DEFAULT 'PENDING',
  scheduled_for   timestamptz,
  settled_at      timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_settlements_merchant ON fees.settlements (merchant_id);
CREATE INDEX idx_settlements_status   ON fees.settlements (status);
CREATE INDEX idx_settlements_tx       ON fees.settlements (transaction_id);

-- ---------------------------------------------------------------------------
-- fees.commissions (logistics/picker/courier commission tracking)
-- ---------------------------------------------------------------------------
CREATE TABLE fees.commissions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  partner_id      uuid REFERENCES delivery.partners(id) ON DELETE SET NULL,
  amount          numeric(14,2) NOT NULL CHECK (amount >= 0),
  status          fees.settlement_status NOT NULL DEFAULT 'PENDING',
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_commissions_tx      ON fees.commissions (transaction_id);
CREATE INDEX idx_commissions_partner ON fees.commissions (partner_id);

-- ---------------------------------------------------------------------------
-- fees.reconciliations / psp_reconciliations
-- ---------------------------------------------------------------------------
CREATE TABLE fees.reconciliations (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid REFERENCES orders.transactions(id) ON DELETE SET NULL,
  status          fees.reconciliation_status NOT NULL DEFAULT 'PENDING',
  expected_amount numeric(14,2),
  actual_amount   numeric(14,2),
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);

CREATE INDEX idx_reconciliations_tx     ON fees.reconciliations (transaction_id);
CREATE INDEX idx_reconciliations_status ON fees.reconciliations (status);

CREATE TABLE fees.psp_reconciliations (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  psp_config_id   uuid REFERENCES fees.psp_configs(id) ON DELETE SET NULL,
  transaction_id  uuid REFERENCES orders.transactions(id) ON DELETE SET NULL,
  status          fees.reconciliation_status NOT NULL DEFAULT 'PENDING',
  expected_amount numeric(14,2),
  actual_amount   numeric(14,2),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_psp_reconciliations_tx ON fees.psp_reconciliations (transaction_id);

-- ---------------------------------------------------------------------------
-- fees.refunds
-- ---------------------------------------------------------------------------
CREATE TABLE fees.refunds (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid NOT NULL REFERENCES orders.transactions(id) ON DELETE CASCADE,
  amount          numeric(14,2) NOT NULL CHECK (amount >= 0),
  status          fees.settlement_status NOT NULL DEFAULT 'PENDING',
  reason          text,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_refunds_tx ON fees.refunds (transaction_id);

-- ---------------------------------------------------------------------------
-- fees.revenue_assurance + fees.audits
-- ---------------------------------------------------------------------------
CREATE TABLE fees.revenue_assurance (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id  uuid REFERENCES orders.transactions(id) ON DELETE SET NULL,
  status          fees.audit_status NOT NULL DEFAULT 'PENDING',
  finding         text,
  amount_at_risk  numeric(14,2),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE fees.audits (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope           text NOT NULL,
  sample_size     integer,
  status          fees.audit_status NOT NULL DEFAULT 'PENDING',
  findings        jsonb DEFAULT '{}'::jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);

COMMIT;

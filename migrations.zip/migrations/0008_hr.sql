-- ============================================================================
-- Migration 0008: Human Resources
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- hr.staff
-- ---------------------------------------------------------------------------
CREATE TABLE hr.staff (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name       text NOT NULL,
  email           citext NOT NULL UNIQUE,
  phone           text,
  role            text NOT NULL,
  department      text NOT NULL,
  national_id     text,
  start_date      date NOT NULL,
  status          text NOT NULL DEFAULT 'ACTIVE'
                  CHECK (status IN ('ACTIVE','ON_LEAVE','SUSPENDED','EXITED')),
  manager_id      uuid REFERENCES hr.staff(id) ON DELETE SET NULL,
  salary          numeric(14,2) CHECK (salary >= 0),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_staff_department ON hr.staff (department);
CREATE INDEX idx_staff_status     ON hr.staff (status);
CREATE INDEX idx_staff_manager    ON hr.staff (manager_id);

-- ---------------------------------------------------------------------------
-- hr.leave_requests
-- ---------------------------------------------------------------------------
CREATE TABLE hr.leave_requests (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id      uuid NOT NULL REFERENCES hr.staff(id) ON DELETE CASCADE,
  leave_type    text NOT NULL CHECK (leave_type IN ('Annual','Sick','Maternity','Paternity','Unpaid','Compassionate')),
  starts_on     date NOT NULL,
  ends_on       date NOT NULL,
  days          integer GENERATED ALWAYS AS (ends_on - starts_on + 1) STORED,
  reason        text,
  status        hr.leave_status NOT NULL DEFAULT 'PENDING',
  reviewed_by   uuid REFERENCES hr.staff(id) ON DELETE SET NULL,
  reviewed_at   timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT chk_leave_dates CHECK (ends_on >= starts_on)
);

CREATE INDEX idx_leave_staff  ON hr.leave_requests (staff_id);
CREATE INDEX idx_leave_status ON hr.leave_requests (status);

-- ---------------------------------------------------------------------------
-- hr.vacancies & candidates
-- ---------------------------------------------------------------------------
CREATE TABLE hr.vacancies (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title           text NOT NULL,
  department      text NOT NULL,
  description     text,
  status          text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED','ON_HOLD')),
  posted_at       timestamptz NOT NULL DEFAULT now(),
  closes_at       timestamptz
);

CREATE TABLE hr.candidates (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vacancy_id    uuid NOT NULL REFERENCES hr.vacancies(id) ON DELETE CASCADE,
  full_name     text NOT NULL,
  email         citext NOT NULL,
  phone         text,
  cv_url        text,
  stage         text NOT NULL DEFAULT 'APPLIED'
                CHECK (stage IN ('APPLIED','SCREENING','INTERVIEW','OFFER','HIRED','REJECTED')),
  notes         text,
  applied_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_candidates_vacancy ON hr.candidates (vacancy_id);
CREATE INDEX idx_candidates_stage   ON hr.candidates (stage);

-- ---------------------------------------------------------------------------
-- hr.performance_reviews
-- ---------------------------------------------------------------------------
CREATE TABLE hr.performance_reviews (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id      uuid NOT NULL REFERENCES hr.staff(id) ON DELETE CASCADE,
  reviewer_id   uuid REFERENCES hr.staff(id) ON DELETE SET NULL,
  period        text NOT NULL,       -- e.g. 'Q1 2025'
  score         numeric(5,2) NOT NULL CHECK (score BETWEEN 0 AND 100),
  comments      text,
  reviewed_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_perf_reviews_staff ON hr.performance_reviews (staff_id);

-- ---------------------------------------------------------------------------
-- hr.disciplinary_cases
-- ---------------------------------------------------------------------------
CREATE TABLE hr.disciplinary_cases (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id      uuid NOT NULL REFERENCES hr.staff(id) ON DELETE CASCADE,
  incident_date date NOT NULL,
  description   text NOT NULL,
  action_taken  text,
  outcome       text,
  status        text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED')),
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_disciplinary_staff ON hr.disciplinary_cases (staff_id);

-- ---------------------------------------------------------------------------
-- hr.rewards
-- ---------------------------------------------------------------------------
CREATE TABLE hr.rewards (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id    uuid NOT NULL REFERENCES hr.staff(id) ON DELETE CASCADE,
  type        text NOT NULL CHECK (type IN ('BONUS','RECOGNITION','PROMOTION','OTHER')),
  amount      numeric(14,2) CHECK (amount >= 0),
  reason      text,
  awarded_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_rewards_staff ON hr.rewards (staff_id);

-- ---------------------------------------------------------------------------
-- hr.separations
-- ---------------------------------------------------------------------------
CREATE TABLE hr.separations (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id        uuid NOT NULL REFERENCES hr.staff(id) ON DELETE CASCADE,
  reason          text NOT NULL CHECK (reason IN ('RESIGNATION','TERMINATION','REDUNDANCY','RETIREMENT','OTHER')),
  effective_date  date NOT NULL,
  handover_notes  text,
  clearance_done  boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX uq_separations_staff ON hr.separations (staff_id);

-- ---------------------------------------------------------------------------
-- hr.succession_plans
-- ---------------------------------------------------------------------------
CREATE TABLE hr.succession_plans (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role            text NOT NULL,
  incumbent_id    uuid REFERENCES hr.staff(id) ON DELETE SET NULL,
  successor_id    uuid REFERENCES hr.staff(id) ON DELETE SET NULL,
  readiness       text NOT NULL DEFAULT 'NOT_READY' CHECK (readiness IN ('READY','ALMOST_READY','NOT_READY')),
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now()
);

COMMIT;

-- ============================================================================
-- Migration 0009: Business Intelligence & Platform / System
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- bi.kpi_snapshots  (daily materialized KPI captures)
-- ---------------------------------------------------------------------------
CREATE TABLE bi.kpi_snapshots (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_date    date NOT NULL,
  metric_key       text NOT NULL,
  metric_value     numeric(20,4) NOT NULL,
  dimension        text,        -- optional slice e.g. "merchant_id", "category"
  dimension_value  text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (snapshot_date, metric_key, dimension, dimension_value)
);

CREATE INDEX idx_kpi_snapshots_date   ON bi.kpi_snapshots (snapshot_date DESC);
CREATE INDEX idx_kpi_snapshots_metric ON bi.kpi_snapshots (metric_key);

-- ---------------------------------------------------------------------------
-- bi.saved_reports
-- ---------------------------------------------------------------------------
CREATE TABLE bi.saved_reports (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name            text NOT NULL,
  description     text,
  security_level  bi.security_level NOT NULL DEFAULT 'INTERNAL',
  created_by      text NOT NULL,
  config          jsonb NOT NULL DEFAULT '{}'::jsonb,  -- columns, filters, viz_type, etc.
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_saved_reports_security ON bi.saved_reports (security_level);

-- ---------------------------------------------------------------------------
-- bi.scheduled_reports
-- ---------------------------------------------------------------------------
CREATE TABLE bi.scheduled_reports (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  saved_report_id uuid NOT NULL REFERENCES bi.saved_reports(id) ON DELETE CASCADE,
  frequency       bi.frequency NOT NULL DEFAULT 'Monthly',
  recipients      text[] NOT NULL DEFAULT '{}',
  next_run_at     timestamptz,
  last_run_at     timestamptz,
  is_active       boolean NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_scheduled_reports_next_run ON bi.scheduled_reports (next_run_at) WHERE is_active = true;

-- ---------------------------------------------------------------------------
-- bi.export_requests
-- ---------------------------------------------------------------------------
CREATE TABLE bi.export_requests (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  saved_report_id uuid REFERENCES bi.saved_reports(id) ON DELETE SET NULL,
  requested_by    text NOT NULL,
  format          bi.export_format NOT NULL DEFAULT 'Excel',
  status          text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','PROCESSING','READY','FAILED')),
  file_url        text,
  requested_at    timestamptz NOT NULL DEFAULT now(),
  completed_at    timestamptz
);

CREATE INDEX idx_export_requests_status ON bi.export_requests (status);

-- ---------------------------------------------------------------------------
-- bi.audit_logs  (BI-layer action audit)
-- ---------------------------------------------------------------------------
CREATE TABLE bi.audit_logs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor       text NOT NULL,
  action      text NOT NULL,
  target      text,
  target_id   uuid,
  metadata    jsonb DEFAULT '{}'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_bi_audit_logs_actor  ON bi.audit_logs (actor);
CREATE INDEX idx_bi_audit_logs_action ON bi.audit_logs (action);
CREATE INDEX idx_bi_audit_logs_time   ON bi.audit_logs (created_at DESC);

-- ============================================================================
-- System / Platform
-- ============================================================================

-- ---------------------------------------------------------------------------
-- sys.admin_logs  (polymorphic platform-wide audit trail)
-- ---------------------------------------------------------------------------
CREATE TABLE sys.admin_logs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor           text NOT NULL,          -- staff email or 'SYSTEM'
  role            text,
  action          text NOT NULL,
  entity          text,                   -- e.g. 'merchant', 'transaction'
  entity_id       uuid,
  previous_value  jsonb,
  new_value       jsonb,
  ip_address      inet,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_admin_logs_actor     ON sys.admin_logs (actor);
CREATE INDEX idx_admin_logs_entity    ON sys.admin_logs (entity, entity_id);
CREATE INDEX idx_admin_logs_created   ON sys.admin_logs (created_at DESC);

-- ---------------------------------------------------------------------------
-- sys.notifications
-- ---------------------------------------------------------------------------
CREATE TABLE sys.notifications (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient     text NOT NULL,
  channel       text NOT NULL DEFAULT 'SMS' CHECK (channel IN ('SMS','EMAIL','PUSH','IN_APP')),
  subject       text,
  body          text NOT NULL,
  sent          boolean NOT NULL DEFAULT false,
  sent_at       timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_notifications_recipient ON sys.notifications (recipient);
CREATE INDEX idx_notifications_sent      ON sys.notifications (sent);

-- ---------------------------------------------------------------------------
-- sys.simulated_sms  (test / sandbox SMS log)
-- ---------------------------------------------------------------------------
CREATE TABLE sys.simulated_sms (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  to_phone        text NOT NULL,
  from_sender_id  text NOT NULL DEFAULT 'SafeBuy',
  message         text NOT NULL,
  transaction_id  uuid REFERENCES orders.transactions(id) ON DELETE SET NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_simulated_sms_phone ON sys.simulated_sms (to_phone);
CREATE INDEX idx_simulated_sms_tx    ON sys.simulated_sms (transaction_id);

COMMIT;

-- ============================================================================
-- Migration 0010: Views
-- ============================================================================

BEGIN;

-- ---------------------------------------------------------------------------
-- orders.v_transaction_summary
-- Full order picture — joined to merchant, delivery, fees, insurance, risk
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW orders.v_transaction_summary AS
SELECT
  t.id,
  t.status,
  t.social_platform,
  t.buyer_phone,
  t.seller_handle,
  t.amount,
  t.fee,
  t.shipping_fee,
  t.total_amount,
  t.quantity,
  t.risk_score,
  t.buyer_trust_score,
  t.seller_trust_score,
  t.cart_enabled,
  t.created_at,
  -- Merchant
  m.business_name                      AS merchant_name,
  m.onboarding_step                    AS merchant_status,
  -- Product
  p.title                              AS product_title,
  p.category                           AS product_category,
  p.verification_status                AS product_verification_status,
  -- Delivery
  da.delivery_status,
  da.delivery_pin_entered,
  da.picker_inspected,
  dp.name                              AS delivery_partner_name,
  dp.type                              AS delivery_partner_type,
  -- Insurance
  ip.policy_kind                       AS insurance_kind,
  ip.option_kind                       AS insurance_option,
  ip.premium                           AS insurance_premium,
  -- Fee ledger
  fl.merchant_success_fee,
  fl.escrow_fee,
  fl.platform_revenue,
  -- Security
  sc.overall_risk                      AS risk_score_detail,
  sc.sim_swap_risk
FROM orders.transactions t
LEFT JOIN merchant.merchants         m   ON m.id   = t.merchant_id
LEFT JOIN catalog.products           p   ON p.id   = t.product_id
LEFT JOIN orders.delivery_assignment da  ON da.transaction_id = t.id
LEFT JOIN delivery.partners          dp  ON dp.id  = da.delivery_partner_id
LEFT JOIN insurance.policies         ip  ON ip.transaction_id = t.id
LEFT JOIN payments.fee_ledger        fl  ON fl.transaction_id = t.id
LEFT JOIN orders.security_scorecards sc  ON sc.transaction_id = t.id;

COMMENT ON VIEW orders.v_transaction_summary IS
  'Denormalised read-model for the escrow dashboard and BI layer.';

-- ---------------------------------------------------------------------------
-- merchant.v_merchant_health
-- KPIs per merchant: volume, open orders, disputes, settlement debt
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW merchant.v_merchant_health AS
SELECT
  m.id,
  m.business_name,
  m.seller_handle,
  m.onboarding_step,
  m.trust_rating,
  COUNT(t.id)                                                    AS total_orders,
  COUNT(t.id) FILTER (WHERE t.status = 'ESCROW_HELD')           AS orders_in_escrow,
  COUNT(t.id) FILTER (WHERE t.status = 'DISPUTED')              AS disputed_orders,
  COUNT(t.id) FILTER (WHERE t.status = 'FUNDS_RELEASED')        AS completed_orders,
  COALESCE(SUM(t.amount) FILTER (WHERE t.status != 'REFUNDED'), 0) AS gross_volume,
  COALESCE(SUM(s.amount) FILTER (WHERE s.status = 'PENDING'),   0) AS pending_settlement
FROM merchant.merchants m
LEFT JOIN orders.transactions t ON t.merchant_id = m.id
LEFT JOIN fees.settlements    s ON s.merchant_id = m.id
GROUP BY m.id, m.business_name, m.seller_handle, m.onboarding_step, m.trust_rating;

COMMENT ON VIEW merchant.v_merchant_health IS
  'Merchant-level health metrics used by the CRM and admin dashboard.';

-- ---------------------------------------------------------------------------
-- fees.v_revenue_summary
-- Daily revenue roll-up across all fee components
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW fees.v_revenue_summary AS
SELECT
  date_trunc('day', t.created_at)  AS day,
  COUNT(t.id)                       AS transactions,
  COALESCE(SUM(fl.merchant_success_fee),  0) AS total_merchant_fees,
  COALESCE(SUM(fl.escrow_fee),            0) AS total_escrow_fees,
  COALESCE(SUM(fl.insurance_fee),         0) AS total_insurance_fees,
  COALESCE(SUM(fl.logistics_commission),  0) AS total_logistics_commission,
  COALESCE(SUM(fl.platform_revenue),      0) AS total_platform_revenue,
  COALESCE(SUM(t.amount),                 0) AS total_gmv
FROM orders.transactions t
LEFT JOIN payments.fee_ledger fl ON fl.transaction_id = t.id
WHERE t.status NOT IN ('REFUNDED')
GROUP BY date_trunc('day', t.created_at)
ORDER BY 1 DESC;

COMMENT ON VIEW fees.v_revenue_summary IS
  'Daily GMV and fee revenue roll-up for the BI revenue report.';

-- ---------------------------------------------------------------------------
-- delivery.v_partner_leaderboard
-- Partner performance league table
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW delivery.v_partner_leaderboard AS
SELECT
  dp.id,
  dp.name,
  dp.type,
  dp.trust_score,
  dp.completed_deliveries,
  dp.on_time_rate,
  dp.dispute_rate,
  dp.feedback_score,
  dp.availability,
  COUNT(db.id)                                   AS total_bids,
  COUNT(db.id) FILTER (WHERE db.accepted = true) AS accepted_bids
FROM delivery.partners dp
LEFT JOIN delivery.bids db ON db.partner_id = dp.id
GROUP BY dp.id, dp.name, dp.type, dp.trust_score, dp.completed_deliveries,
         dp.on_time_rate, dp.dispute_rate, dp.feedback_score, dp.availability
ORDER BY dp.trust_score DESC;

-- ---------------------------------------------------------------------------
-- support.v_open_tickets_with_context
-- Open tickets enriched with transaction and merchant context
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW support.v_open_tickets_with_context AS
SELECT
  tk.id                    AS ticket_id,
  tk.customer,
  tk.category,
  tk.urgency,
  tk.assigned_to,
  tk.created_at,
  t.status                 AS transaction_status,
  t.amount,
  t.buyer_phone,
  t.seller_handle,
  m.business_name          AS merchant_name,
  td.recommendation        AS last_recommendation,
  td.outcome               AS last_outcome
FROM support.tickets tk
LEFT JOIN orders.transactions      t   ON t.id  = tk.transaction_id
LEFT JOIN merchant.merchants       m   ON m.id  = t.merchant_id
LEFT JOIN LATERAL (
  SELECT recommendation, outcome
  FROM   support.ticket_decisions
  WHERE  ticket_id = tk.id
  ORDER  BY decided_at DESC
  LIMIT  1
) td ON true
WHERE tk.status = 'OPEN';

-- ---------------------------------------------------------------------------
-- bi.v_platform_kpis  (live snapshot — used by BI overview cards)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW bi.v_platform_kpis AS
SELECT
  (SELECT COUNT(*)          FROM merchant.merchants WHERE onboarding_step = 'VERIFIED')            AS verified_merchants,
  (SELECT COUNT(*)          FROM orders.transactions WHERE status = 'ESCROW_HELD')                 AS orders_in_escrow,
  (SELECT COALESCE(SUM(amount),0) FROM orders.transactions WHERE status != 'REFUNDED')             AS total_gmv,
  (SELECT COALESCE(SUM(total_escrow_held),0) FROM escrow.wallets)                                  AS escrow_held,
  (SELECT COUNT(*)          FROM orders.transactions WHERE status = 'DISPUTED')                    AS active_disputes,
  (SELECT COUNT(*)          FROM delivery.partners   WHERE availability = 'ONLINE')                AS online_couriers,
  (SELECT COUNT(*)          FROM support.tickets     WHERE status = 'OPEN')                        AS open_tickets,
  (SELECT COALESCE(SUM(amount),0) FROM fees.settlements WHERE status = 'PENDING')                  AS pending_settlements,
  now()                                                                                             AS generated_at;

COMMIT;

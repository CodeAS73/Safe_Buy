-- ============================================================================
-- Migration 0011: Triggers
-- ============================================================================

BEGIN;

-- ============================================================================
-- HELPER: generic updated_at stamper
-- ============================================================================
CREATE OR REPLACE FUNCTION sys.set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Apply updated_at to every table that has the column
DO $$
DECLARE
  tbl record;
BEGIN
  FOR tbl IN
    SELECT table_schema, table_name
    FROM   information_schema.columns
    WHERE  column_name = 'updated_at'
      AND  table_schema IN ('merchant','catalog','orders','escrow','payments',
                            'delivery','insurance','support','fees','hr','bi','sys')
  LOOP
    EXECUTE format(
      'CREATE TRIGGER trg_updated_at
       BEFORE UPDATE ON %I.%I
       FOR EACH ROW EXECUTE FUNCTION sys.set_updated_at()',
      tbl.table_schema, tbl.table_name
    );
  END LOOP;
END;
$$;

-- ============================================================================
-- 1. Auto-append a TimelineEvent when transaction.status changes
-- ============================================================================
CREATE OR REPLACE FUNCTION orders.fn_transaction_status_timeline()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  title_map jsonb := '{
    "PENDING_DEPOSIT":  "Payment Pending",
    "ESCROW_HELD":      "Funds Held in Escrow",
    "ITEMS_SHIPPED":    "Items Shipped",
    "FUNDS_RELEASED":   "Funds Released to Seller",
    "DISPUTED":         "Dispute Opened",
    "REFUNDED":         "Buyer Refunded"
  }'::jsonb;
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO orders.timeline_events (transaction_id, status, title, actor)
    VALUES (
      NEW.id,
      NEW.status,
      COALESCE(title_map ->> NEW.status, NEW.status),
      'SYSTEM'
    );
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_transaction_status_timeline
AFTER UPDATE OF status ON orders.transactions
FOR EACH ROW EXECUTE FUNCTION orders.fn_transaction_status_timeline();

-- ============================================================================
-- 2. Append initial TimelineEvent on INSERT
-- ============================================================================
CREATE OR REPLACE FUNCTION orders.fn_transaction_created_event()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO orders.timeline_events (transaction_id, status, title, actor)
  VALUES (NEW.id, 'PENDING_DEPOSIT', 'Order Created — Awaiting Payment', 'SYSTEM');
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_transaction_created_event
AFTER INSERT ON orders.transactions
FOR EACH ROW EXECUTE FUNCTION orders.fn_transaction_created_event();

-- ============================================================================
-- 3. Update escrow.wallets when a ledger_entry is written
--    DEPOSIT  → +total_escrow_held
--    RELEASE  → -total_escrow_held, +total_settled
--    REFUND   → -total_escrow_held
--    FEE      → +total_fees_collected
-- ============================================================================
CREATE OR REPLACE FUNCTION escrow.fn_update_wallet_balance()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  UPDATE escrow.wallets SET
    total_escrow_held    = total_escrow_held
                         + CASE NEW.entry_type
                             WHEN 'DEPOSIT' THEN  NEW.amount
                             WHEN 'RELEASE' THEN -NEW.amount
                             WHEN 'REFUND'  THEN -NEW.amount
                             ELSE 0
                           END,
    total_fees_collected = total_fees_collected
                         + CASE NEW.entry_type WHEN 'FEE' THEN NEW.amount ELSE 0 END,
    total_settled        = total_settled
                         + CASE NEW.entry_type WHEN 'RELEASE' THEN NEW.amount ELSE 0 END,
    updated_at           = now()
  WHERE id = NEW.wallet_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_wallet_balance_on_ledger
AFTER INSERT ON escrow.ledger_entries
FOR EACH ROW EXECUTE FUNCTION escrow.fn_update_wallet_balance();

-- ============================================================================
-- 4. Merchant volume + trust_rating recalc on transaction FUNDS_RELEASED
-- ============================================================================
CREATE OR REPLACE FUNCTION merchant.fn_update_merchant_stats()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'FUNDS_RELEASED' AND OLD.status IS DISTINCT FROM 'FUNDS_RELEASED' THEN
    UPDATE merchant.merchants SET
      volume_ksh   = volume_ksh + NEW.amount,
      trust_rating = LEAST(100, trust_rating + 0.5),   -- award 0.5 pts per clean order
      updated_at   = now()
    WHERE id = NEW.merchant_id;
  END IF;

  IF NEW.status = 'DISPUTED' AND OLD.status IS DISTINCT FROM 'DISPUTED' THEN
    UPDATE merchant.merchants SET
      trust_rating = GREATEST(0, trust_rating - 2),    -- penalise 2 pts per dispute
      updated_at   = now()
    WHERE id = NEW.merchant_id;
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_merchant_stats_on_tx_status
AFTER UPDATE OF status ON orders.transactions
FOR EACH ROW EXECUTE FUNCTION merchant.fn_update_merchant_stats();

-- ============================================================================
-- 5. Delivery partner stats recalc when delivery_assignment status changes
-- ============================================================================
CREATE OR REPLACE FUNCTION delivery.fn_update_partner_stats()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.delivery_status = 'DELIVERED'
     AND (OLD.delivery_status IS DISTINCT FROM 'DELIVERED')
     AND NEW.delivery_partner_id IS NOT NULL
  THEN
    UPDATE delivery.partners SET
      completed_deliveries = completed_deliveries + 1,
      updated_at           = now()
    WHERE id = NEW.delivery_partner_id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_partner_stats_on_delivery
AFTER UPDATE OF delivery_status ON orders.delivery_assignment
FOR EACH ROW EXECUTE FUNCTION delivery.fn_update_partner_stats();

-- ============================================================================
-- 6. Write a sys.admin_log row whenever a merchant's fee plan is changed
-- ============================================================================
CREATE OR REPLACE FUNCTION merchant.fn_log_fee_plan_change()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.default_fee_plan IS DISTINCT FROM OLD.default_fee_plan THEN
    INSERT INTO sys.admin_logs (actor, action, entity, entity_id, previous_value, new_value)
    VALUES (
      COALESCE(NEW.fee_override_approved_by, 'SYSTEM'),
      'FEE_PLAN_CHANGED',
      'merchant',
      NEW.id,
      jsonb_build_object('fee_plan', OLD.default_fee_plan),
      jsonb_build_object('fee_plan', NEW.default_fee_plan)
    );
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_log_fee_plan_change
AFTER UPDATE OF default_fee_plan ON merchant.merchants
FOR EACH ROW EXECUTE FUNCTION merchant.fn_log_fee_plan_change();

-- ============================================================================
-- 7. Prevent a Transaction from being moved backward in its status lifecycle
-- ============================================================================
CREATE OR REPLACE FUNCTION orders.fn_enforce_status_forward()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  order_seq text[] := ARRAY[
    'PENDING_DEPOSIT','ESCROW_HELD','ITEMS_SHIPPED','FUNDS_RELEASED'
  ];
  old_pos int;
  new_pos int;
BEGIN
  old_pos := array_position(order_seq, OLD.status::text);
  new_pos := array_position(order_seq, NEW.status::text);

  -- Allow any transition to DISPUTED or REFUNDED from any state
  IF NEW.status IN ('DISPUTED','REFUNDED') THEN
    RETURN NEW;
  END IF;

  -- If both statuses are in the main flow, require forward movement
  IF old_pos IS NOT NULL AND new_pos IS NOT NULL AND new_pos < old_pos THEN
    RAISE EXCEPTION
      'Invalid status transition: % → % is not allowed (backward movement)',
      OLD.status, NEW.status;
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_enforce_status_forward
BEFORE UPDATE OF status ON orders.transactions
FOR EACH ROW EXECUTE FUNCTION orders.fn_enforce_status_forward();

-- ============================================================================
-- 8. Auto-seed an InsurancePolicy row when a Transaction is created
-- ============================================================================
CREATE OR REPLACE FUNCTION insurance.fn_seed_policy_on_order()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO insurance.policies (transaction_id, policy_kind, option_kind, paid_by, structure)
  VALUES (NEW.id, 'NONE', 'NONE', 'NONE', 'ORDER')
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_seed_insurance_on_order
AFTER INSERT ON orders.transactions
FOR EACH ROW EXECUTE FUNCTION insurance.fn_seed_policy_on_order();

-- ============================================================================
-- 9. Seed a fee_ledger row on INSERT into transactions
-- ============================================================================
CREATE OR REPLACE FUNCTION payments.fn_seed_fee_ledger()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO payments.fee_ledger (transaction_id)
  VALUES (NEW.id)
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_seed_fee_ledger_on_order
AFTER INSERT ON orders.transactions
FOR EACH ROW EXECUTE FUNCTION payments.fn_seed_fee_ledger();

COMMIT;

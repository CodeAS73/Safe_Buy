#!/usr/bin/env bash
# =============================================================================
# run_migrations.sh — Safe Buy database migration runner
#
# Usage:
#   DATABASE_URL=postgres://user:pass@host/db ./run_migrations.sh
#   ./run_migrations.sh --dry-run          (print files without executing)
#   ./run_migrations.sh --from 0005        (run only 0005 and above)
# =============================================================================

set -euo pipefail

MIGRATIONS_DIR="$(cd "$(dirname "$0")" && pwd)"
DRY_RUN=false
FROM_PREFIX="0000"

for arg in "$@"; do
  case $arg in
    --dry-run)     DRY_RUN=true ;;
    --from=*)      FROM_PREFIX="${arg#--from=}" ;;
  esac
done

if [[ -z "${DATABASE_URL:-}" ]]; then
  echo "ERROR: DATABASE_URL is not set." >&2
  exit 1
fi

echo "==========================================="
echo " Safe Buy — Database Migration Runner"
echo "==========================================="
echo " Target: $DATABASE_URL"
echo " Dry run: $DRY_RUN"
echo " From:    $FROM_PREFIX"
echo "==========================================="

# Ensure migrations tracking table exists
psql "$DATABASE_URL" -q -c "
  CREATE TABLE IF NOT EXISTS public.schema_migrations (
    version     text PRIMARY KEY,
    applied_at  timestamptz NOT NULL DEFAULT now()
  );
"

for file in "$MIGRATIONS_DIR"/[0-9]*.sql; do
  version=$(basename "$file" .sql)

  # Skip files before --from prefix
  if [[ "$version" < "$FROM_PREFIX" ]]; then
    echo "SKIP  (before --from): $version"
    continue
  fi

  # Check if already applied
  already=$(psql "$DATABASE_URL" -t -c \
    "SELECT count(*) FROM public.schema_migrations WHERE version = '$version';" | tr -d ' ')

  if [[ "$already" -gt 0 ]]; then
    echo "SKIP  (already applied): $version"
    continue
  fi

  echo ""
  echo "▶  Applying: $version"

  if $DRY_RUN; then
    echo "   [dry-run] would execute $file"
  else
    psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$file"
    psql "$DATABASE_URL" -q -c \
      "INSERT INTO public.schema_migrations (version) VALUES ('$version');"
    echo "✔  Applied:  $version"
  fi
done

echo ""
echo "==========================================="
echo " All migrations complete."
echo "==========================================="

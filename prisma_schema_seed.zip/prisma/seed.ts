// =============================================================================
// prisma/seed.ts — Safe Buy Seed Data (Kenyan market, M-Pesa context)
// Run: npx prisma db seed
// =============================================================================

import { PrismaClient, Prisma } from "@prisma/client";

const prisma = new PrismaClient();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const ksh = (v: number): Prisma.Decimal => new Prisma.Decimal(v);
const pct = (v: number): Prisma.Decimal => new Prisma.Decimal(v);
const uuid = () => crypto.randomUUID();

// ---------------------------------------------------------------------------
// 1. Escrow Wallet (singleton)
// ---------------------------------------------------------------------------
async function seedWallet() {
  return prisma.escrowWallet.upsert({
    where: { currency: "Ksh" },
    create: {
      currency: "Ksh",
      totalEscrowHeld: ksh(0),
      totalFeesCollected: ksh(0),
      totalSettled: ksh(0),
      reservePool: ksh(0),
    },
    update: {},
  });
}

// ---------------------------------------------------------------------------
// 2. Fee Plans
// ---------------------------------------------------------------------------
async function seedFeePlans() {
  const plans = [
    {
      name: "Standard Merchant Plan",
      kind: "DEFAULT" as const,
      rateConfig: {
        merchantSuccessFee: "3.5%",
        escrowFee: "1%",
        communicationFee: "KES 5",
        insuranceFee: "0.5%",
        logisticsCommission: "8%",
      },
    },
    {
      name: "Growth Partner Plan",
      kind: "CUSTOM" as const,
      rateConfig: {
        merchantSuccessFee: "2.5%",
        escrowFee: "0.75%",
        communicationFee: "KES 3",
        insuranceFee: "0.4%",
        logisticsCommission: "6%",
      },
    },
    {
      name: "Q3 Festive Campaign",
      kind: "CAMPAIGN" as const,
      rateConfig: {
        merchantSuccessFee: "2%",
        escrowFee: "0.5%",
        communicationFee: "KES 0",
        insuranceFee: "0.3%",
        logisticsCommission: "5%",
        note: "Active Aug–Oct 2025",
      },
    },
    {
      name: "Enterprise Suite",
      kind: "ENTERPRISE" as const,
      rateConfig: {
        merchantSuccessFee: "1.8%",
        escrowFee: "0.5%",
        communicationFee: "KES 0",
        insuranceFee: "0.2%",
        logisticsCommission: "4%",
        dedicatedAccountManager: true,
      },
    },
  ] satisfies { name: string; kind: "DEFAULT" | "CUSTOM" | "CAMPAIGN" | "ENTERPRISE"; rateConfig: object }[];

  const created: Record<string, string> = {};
  for (const plan of plans) {
    const row = await prisma.feePlan.create({ data: plan });
    created[plan.kind] = row.id;
  }
  return created;
}

// ---------------------------------------------------------------------------
// 3. PSP Configs
// ---------------------------------------------------------------------------
async function seedPspConfigs() {
  const configs = [
    { provider: "Safaricom", network: "mpesa" as const, config: { shortcode: "522522", env: "sandbox" } },
    { provider: "Airtel Africa", network: "airtel" as const, config: { merchantId: "AIRTEL_KE_001", env: "sandbox" } },
    { provider: "T-Cash (Telkom)", network: "tcash" as const, config: { merchantId: "TCASH_KE_001", env: "sandbox" } },
  ];
  for (const c of configs) {
    await prisma.pspConfig.upsert({
      where: { provider_network: { provider: c.provider, network: c.network } },
      create: c,
      update: {},
    });
  }
}

// ---------------------------------------------------------------------------
// 4. Auditors
// ---------------------------------------------------------------------------
async function seedAuditors() {
  const auditors = [
    { name: "James Odhiambo",  phone: "+254711234001", email: "james.o@safebuy.africa" },
    { name: "Wanjiru Muthoni", phone: "+254722234002", email: "wanjiru.m@safebuy.africa" },
    { name: "Kevin Otieno",    phone: "+254733234003", email: "kevin.o@safebuy.africa" },
  ];
  const ids: string[] = [];
  for (const a of auditors) {
    const row = await prisma.auditor.create({ data: a });
    ids.push(row.id);
  }
  return ids;
}

// ---------------------------------------------------------------------------
// 5. Merchants
// ---------------------------------------------------------------------------
async function seedMerchants(feePlanIds: Record<string, string>) {
  const rows = [
    {
      businessName: "Nairobi Tech Hub",
      sellerHandle: "@nairobitekh",
      phone: "+254712345001",
      email: "info@nairobitekh.co.ke",
      onboardingStep: "VERIFIED" as const,
      verifiedAt: new Date("2025-01-15"),
      volumeKsh: ksh(4_850_000),
      trustRating: pct(94),
      defaultFeePlan: "DEFAULT" as const,
      customFeePlanId: feePlanIds["CUSTOM"],
    },
    {
      businessName: "Mama Mboga Fresh",
      sellerHandle: "@mamamboga",
      phone: "+254722345002",
      email: "orders@mamamboga.co.ke",
      onboardingStep: "VERIFIED" as const,
      verifiedAt: new Date("2025-03-02"),
      volumeKsh: ksh(980_000),
      trustRating: pct(88),
      defaultFeePlan: "DEFAULT" as const,
    },
    {
      businessName: "Safari Motors KE",
      sellerHandle: "@safarimotors",
      phone: "+254733345003",
      email: "sales@safarimotors.co.ke",
      onboardingStep: "VERIFIED" as const,
      verifiedAt: new Date("2025-02-20"),
      volumeKsh: ksh(12_300_000),
      trustRating: pct(97),
      defaultFeePlan: "ENTERPRISE" as const,
      enterpriseFeePlanId: feePlanIds["ENTERPRISE"],
    },
    {
      businessName: "Jua Kali Crafts",
      sellerHandle: "@juakalicrafts",
      phone: "+254744345004",
      email: "hello@juakali.co.ke",
      onboardingStep: "TILL_LINKED" as const,
      volumeKsh: ksh(0),
      trustRating: pct(0),
      defaultFeePlan: "DEFAULT" as const,
    },
    {
      businessName: "Westlands Gadgets",
      sellerHandle: "@westgadgets",
      phone: "+254755345005",
      email: "westgadgets@gmail.com",
      onboardingStep: "KYC" as const,
      volumeKsh: ksh(0),
      trustRating: pct(0),
      defaultFeePlan: "DEFAULT" as const,
    },
  ];

  const created: string[] = [];
  for (const m of rows) {
    const row = await prisma.merchant.create({ data: m });
    created.push(row.id);
  }
  return created;
}

// ---------------------------------------------------------------------------
// 6. Products
// ---------------------------------------------------------------------------
async function seedProducts(merchantIds: string[], auditorIds: string[]) {
  const rows = [
    {
      merchantId: merchantIds[0],
      title: "Samsung Galaxy S24 Ultra (256GB, Titanium)",
      category: "Electronics_Gadgets" as const,
      price: ksh(149_999),
      description: "Brand new sealed. Official warranty. KE version.",
      sellerHandle: "@nairobitekh",
      sellerPhone: "+254712345001",
      verificationStatus: "VERIFIED" as const,
      verificationTier: "PREMIUM" as const,
      verificationFee: ksh(2_500),
      auditorId: auditorIds[0],
      bulkPlanSubscribed: "GROWTH" as const,
      isFeatured: true,
      verifiedAt: new Date("2025-05-01"),
      expiresAt: new Date("2026-05-01"),
    },
    {
      merchantId: merchantIds[0],
      title: "Apple MacBook Air M3 (13\", 8GB/256GB)",
      category: "Electronics_Gadgets" as const,
      price: ksh(179_000),
      description: "Sealed box. Midnight colour. Education receipt included.",
      sellerHandle: "@nairobitekh",
      sellerPhone: "+254712345001",
      verificationStatus: "VERIFIED" as const,
      verificationTier: "PRIORITY" as const,
      verificationFee: ksh(2_000),
      auditorId: auditorIds[1],
      bulkPlanSubscribed: "GROWTH" as const,
      isFeatured: true,
      verifiedAt: new Date("2025-04-15"),
      expiresAt: new Date("2026-04-15"),
    },
    {
      merchantId: merchantIds[2],
      title: "Toyota Land Cruiser V8 2022 (70 Series)",
      category: "Vehicles_Motors" as const,
      price: ksh(12_500_000),
      description: "Single owner. Service history. Clean logbook. Nairobi reg.",
      sellerHandle: "@safarimotors",
      sellerPhone: "+254733345003",
      verificationStatus: "VERIFIED" as const,
      verificationTier: "PREMIUM" as const,
      verificationFee: ksh(15_000),
      auditorId: auditorIds[2],
      bulkPlanSubscribed: "ENTERPRISE" as const,
      isFeatured: true,
      verifiedAt: new Date("2025-05-10"),
      expiresAt: new Date("2025-11-10"),
    },
    {
      merchantId: merchantIds[1],
      title: "Organic Avocado Hass (1kg box)",
      category: "Other_Products" as const,
      price: ksh(350),
      description: "Farm-fresh from Muranga. Same-day delivery Nairobi.",
      sellerHandle: "@mamamboga",
      sellerPhone: "+254722345002",
      verificationStatus: "UNVERIFIED" as const,
      bulkPlanSubscribed: "NONE" as const,
      isFeatured: false,
    },
    {
      merchantId: merchantIds[3],
      title: "Handwoven Sisal Basket (Medium)",
      category: "Furniture_Living" as const,
      price: ksh(1_800),
      description: "Authentic Kenyan craft. Fair trade certified.",
      sellerHandle: "@juakalicrafts",
      sellerPhone: "+254744345004",
      verificationStatus: "AUDITOR_ASSIGNED" as const,
      verificationTier: "STANDARD" as const,
      verificationFee: ksh(800),
      auditorId: auditorIds[0],
      bulkPlanSubscribed: "NONE" as const,
      isFeatured: false,
    },
  ];

  const ids: string[] = [];
  for (const p of rows) {
    const row = await prisma.product.create({ data: p });
    ids.push(row.id);
  }
  return ids;
}

// ---------------------------------------------------------------------------
// 7. Delivery Partners
// ---------------------------------------------------------------------------
async function seedDeliveryPartners() {
  const rows = [
    {
      name: "Brian Kipkoech",
      phone: "+254700111001",
      type: "RIDER" as const,
      isVerified: true,
      trustScore: pct(96),
      completedDeliveries: 412,
      onTimeRate: pct(97),
      disputeRate: pct(1),
      feedbackScore: pct(4.9),
      availability: "ONLINE" as const,
      vehicleDetails: "Bajaj Boxer 150cc · KDD 123A",
      aiRiskScore: pct(4),
    },
    {
      name: "Aisha Wanjiku",
      phone: "+254700111002",
      type: "DRIVER" as const,
      isVerified: true,
      trustScore: pct(91),
      completedDeliveries: 208,
      onTimeRate: pct(94),
      disputeRate: pct(2),
      feedbackScore: pct(4.7),
      availability: "ONLINE" as const,
      vehicleDetails: "Toyota Probox · KBZ 456B",
      aiRiskScore: pct(8),
    },
    {
      name: "Mwenda Logistics Ltd",
      phone: "+254700111003",
      type: "COURIER" as const,
      isVerified: true,
      trustScore: pct(88),
      completedDeliveries: 1_042,
      onTimeRate: pct(92),
      disputeRate: pct(3),
      feedbackScore: pct(4.5),
      availability: "ONLINE" as const,
      vehicleDetails: "3-tonne Isuzu NPR · KCX 789C",
      aiRiskScore: pct(12),
    },
    {
      name: "Linet Adhiambo",
      phone: "+254700111004",
      type: "PICKER" as const,
      isVerified: true,
      trustScore: pct(99),
      completedDeliveries: 67,
      onTimeRate: pct(100),
      disputeRate: pct(0),
      feedbackScore: pct(5.0),
      availability: "BUSY" as const,
      aiRiskScore: pct(1),
    },
  ];

  const ids: string[] = [];
  for (const p of rows) {
    const row = await prisma.deliveryPartner.create({ data: p });
    ids.push(row.id);
  }
  return ids;
}

// ---------------------------------------------------------------------------
// 8. Transactions + child records
// ---------------------------------------------------------------------------
async function seedTransactions(
  merchantIds: string[],
  productIds: string[],
  partnerIds: string[]
) {
  // --- Tx 1: Completed phone sale ---
  const tx1 = await prisma.transaction.create({
    data: {
      merchantId: merchantIds[0],
      productId: productIds[0],
      buyerPhone: "+254722000001",
      buyerName: "Grace Akinyi",
      buyerEmail: "grace.akinyi@gmail.com",
      buyerAccountType: "REGISTERED",
      sellerPhone: "+254712345001",
      sellerHandle: "@nairobitekh",
      socialPlatform: "WhatsApp",
      amount: ksh(149_999),
      fee: ksh(5_250),
      platformFee: ksh(1_500),
      quantity: 1,
      description: "Samsung Galaxy S24 Ultra",
      status: "FUNDS_RELEASED",
      shippingMethod: "Courier",
      shippingFee: ksh(400),
      totalAmount: ksh(155_649),
      countdownHours: 0,
      riskScore: pct(8),
      buyerTrustScore: pct(82),
      sellerTrustScore: pct(94),
      escrowModel: "model_1",
    },
  });

  // Timeline for tx1
  const tx1Events = [
    { status: "PENDING_DEPOSIT",  title: "Order Created — Awaiting Payment",  actor: "SYSTEM"  as const },
    { status: "ESCROW_HELD",      title: "Payment Confirmed via M-Pesa",       actor: "SYSTEM"  as const },
    { status: "ITEMS_SHIPPED",    title: "Seller Dispatched via Brian (Rider)", actor: "SELLER" as const },
    { status: "FUNDS_RELEASED",   title: "Buyer Confirmed Receipt",            actor: "BUYER"  as const },
  ];
  for (const ev of tx1Events) {
    await prisma.timelineEvent.create({ data: { transactionId: tx1.id, ...ev } });
  }

  // Payment attempt for tx1
  await prisma.paymentAttempt.create({
    data: {
      transactionId: tx1.id,
      network: "mpesa",
      amount: ksh(155_649),
      status: "SUCCESS",
      mpesaCode: "QHJ7K2LMNP",
      resolvedAt: new Date(),
    },
  });

  // Delivery assignment tx1
  await prisma.deliveryAssignment.create({
    data: {
      transactionId: tx1.id,
      deliveryPartnerId: partnerIds[0],
      deliveryPin: "4829",
      deliveryPinEntered: true,
      deliveryStatus: "DELIVERED",
      pickerInspected: true,
      pickerReport: "Device in perfect sealed condition. IMEI verified.",
      pickerFee: ksh(300),
    },
  });

  // Delivery milestones tx1
  for (const st of ["PICKED_UP", "IN_TRANSIT", "ARRIVED", "DELIVERED"] as const) {
    await prisma.deliveryMilestone.create({
      data: { transactionId: tx1.id, partnerId: partnerIds[0], status: st },
    });
  }

  // Insurance tx1
  await prisma.insurancePolicy.upsert({
    where:  { transactionId: tx1.id },
    create: { transactionId: tx1.id, policyKind: "BUYER_CHOOSES", optionKind: "ENHANCED", premium: ksh(750), paidBy: "BUYER", structure: "ORDER" },
    update: {},
  });

  // Fee ledger tx1
  await prisma.feeLedger.upsert({
    where:  { transactionId: tx1.id },
    create: {
      transactionId: tx1.id,
      merchantSuccessFee: ksh(5_250),
      escrowFee: ksh(1_500),
      communicationFee: ksh(5),
      insuranceFee: ksh(750),
      logisticsCommission: ksh(32),
      courierRevenue: ksh(368),
      platformRevenue: ksh(3_245),
      escrowFeePaidBy: "BUYER",
      merchantSuccessFeeRate: "3.5%",
      escrowFeeRateApplied: "1%",
    },
    update: {},
  });

  // Settlement tx1
  await prisma.settlement.create({
    data: {
      merchantId: merchantIds[0],
      transactionId: tx1.id,
      amount: ksh(144_749),
      status: "SETTLED",
      scheduledFor: new Date("2025-06-02"),
      settledAt: new Date("2025-06-02"),
    },
  });

  // --- Tx 2: Active escrow (Land Cruiser sale) ---
  const tx2 = await prisma.transaction.create({
    data: {
      merchantId: merchantIds[2],
      productId: productIds[2],
      buyerPhone: "+254733000002",
      buyerName: "Dominic Mwangi",
      buyerEmail: "dominic.mwangi@gmail.com",
      buyerAccountType: "REGISTERED",
      buyerNationalId: "32891047",
      sellerPhone: "+254733345003",
      sellerHandle: "@safarimotors",
      socialPlatform: "Instagram",
      amount: ksh(12_500_000),
      fee: ksh(225_000),
      platformFee: ksh(62_500),
      quantity: 1,
      description: "Toyota Land Cruiser V8 2022",
      status: "ESCROW_HELD",
      shippingMethod: "Pickup",
      shippingFee: ksh(0),
      totalAmount: ksh(12_725_000),
      countdownHours: 72,
      riskScore: pct(15),
      buyerTrustScore: pct(75),
      sellerTrustScore: pct(97),
      escrowModel: "model_1",
      cartEnabled: false,
    },
  });

  await prisma.shippingDetails.create({
    data: {
      transactionId: tx2.id,
      county: "Nairobi",
      town: "Westlands",
      address: "Safari Motors Showroom, Waiyaki Way",
      contactPerson: "Dominic Mwangi",
      phone: "+254733000002",
      pickupLocation: "Safari Motors Westlands",
      pickupDate: new Date("2025-07-05"),
    },
  });

  await prisma.insurancePolicy.upsert({
    where:  { transactionId: tx2.id },
    create: { transactionId: tx2.id, policyKind: "MANDATORY", optionKind: "ENHANCED", premium: ksh(62_500), paidBy: "SHARED", structure: "ORDER" },
    update: {},
  });

  await prisma.securityScorecard.create({
    data: {
      transactionId: tx2.id,
      velocityLimitPassed: true,
      deviceFingerprintScore: 88,
      simSwapRisk: "LOW",
      ipLocationMatch: true,
      overallRisk: 15,
    },
  });

  // --- Tx 3: Disputed avocado order ---
  const tx3 = await prisma.transaction.create({
    data: {
      merchantId: merchantIds[1],
      productId: productIds[3],
      buyerPhone: "+254744000003",
      buyerName: "Fatuma Hassan",
      sellerPhone: "+254722345002",
      sellerHandle: "@mamamboga",
      socialPlatform: "Facebook",
      amount: ksh(3_500),
      fee: ksh(122),
      platformFee: ksh(35),
      quantity: 10,
      description: "Organic Avocado Hass 10×1kg",
      status: "DISPUTED",
      shippingMethod: "Seller_Delivery",
      shippingFee: ksh(200),
      totalAmount: ksh(3_857),
      countdownHours: 0,
      riskScore: pct(62),
      buyerTrustScore: pct(55),
      sellerTrustScore: pct(88),
    },
  });

  await prisma.ticket.create({
    data: {
      transactionId: tx3.id,
      customer: "Fatuma Hassan",
      category: "Item Not as Described",
      urgency: "High",
      status: "OPEN",
      assignedTo: "crm@safebuy.africa",
      message: "Received 4 rotten avocados out of 10. Seller refuses refund.",
    },
  });

  await prisma.insuranceClaim.create({
    data: {
      transactionId: tx3.id,
      type: "DAMAGE",
      status: "UNDER_REVIEW",
      evidenceNotes: "Photos of 4 rotten avocados submitted via WhatsApp.",
    },
  });

  // --- Tx 4: Pending deposit (MacBook) ---
  const tx4 = await prisma.transaction.create({
    data: {
      merchantId: merchantIds[0],
      productId: productIds[1],
      buyerPhone: "+254755000004",
      buyerName: "Kevin Gitau",
      sellerPhone: "+254712345001",
      sellerHandle: "@nairobitekh",
      socialPlatform: "TikTok",
      amount: ksh(179_000),
      fee: ksh(6_265),
      platformFee: ksh(1_790),
      quantity: 1,
      description: "Apple MacBook Air M3",
      status: "PENDING_DEPOSIT",
      shippingMethod: "Courier",
      shippingFee: ksh(500),
      totalAmount: ksh(185_765),
      countdownHours: 24,
      riskScore: pct(22),
      buyerTrustScore: pct(60),
      sellerTrustScore: pct(94),
    },
  });

  await prisma.deliveryBid.createMany({
    data: [
      { transactionId: tx4.id, partnerId: partnerIds[0], bidAmount: ksh(500), estimatedHours: 2,   accepted: true  },
      { transactionId: tx4.id, partnerId: partnerIds[1], bidAmount: ksh(650), estimatedHours: 2.5, accepted: false },
    ],
  });

  return [tx1.id, tx2.id, tx3.id, tx4.id];
}

// ---------------------------------------------------------------------------
// 9. HR: Staff, leaves, vacancies
// ---------------------------------------------------------------------------
async function seedHr() {
  // Manager first
  const ceo = await prisma.staff.create({
    data: {
      fullName: "Amina Osei",
      email: "amina.osei@safebuy.africa",
      phone: "+254700900001",
      role: "Chief Executive Officer",
      department: "Executive",
      startDate: new Date("2023-01-10"),
      status: "ACTIVE",
      salary: ksh(450_000),
    },
  });

  const staffRows = [
    { fullName: "Daniel Kariuki",   email: "daniel.k@safebuy.africa",  phone: "+254700900002", role: "Head of Engineering",    department: "Technology",   salary: 320_000 },
    { fullName: "Seline Nyambura", email: "seline.n@safebuy.africa",  phone: "+254700900003", role: "Senior CRM Manager",     department: "Operations",   salary: 180_000 },
    { fullName: "Abdullahi Yusuf", email: "abdullahi.y@safebuy.africa",phone: "+254700900004", role: "Finance Lead",           department: "Finance",      salary: 220_000 },
    { fullName: "Joy Wambua",      email: "joy.w@safebuy.africa",     phone: "+254700900005", role: "Field Operations Officer",department: "Operations",   salary: 95_000  },
    { fullName: "Pius Otieno",     email: "pius.o@safebuy.africa",    phone: "+254700900006", role: "Backend Engineer",       department: "Technology",   salary: 150_000  },
  ] as const;

  const staffIds: string[] = [];
  for (const s of staffRows) {
    const row = await prisma.staff.create({
      data: { ...s, managerId: ceo.id, startDate: new Date("2023-06-01"), status: "ACTIVE", salary: ksh(s.salary) },
    });
    staffIds.push(row.id);
  }

  // Leave request
  await prisma.leaveRequest.create({
    data: {
      staffId: staffIds[4],         // Pius
      leaveType: "Annual",
      startsOn: new Date("2025-08-04"),
      endsOn:   new Date("2025-08-15"),
      reason:   "Family holiday in Mombasa",
      status:   "APPROVED",
      reviewedBy: staffIds[0],      // Daniel
      reviewedAt: new Date("2025-07-20"),
    },
  });

  // Vacancy
  await prisma.vacancy.create({
    data: {
      title:      "Mobile Engineer (React Native)",
      department: "Technology",
      description:"Build and maintain the SafeBuy buyer mobile app.",
      status:     "OPEN",
      closesAt:   new Date("2025-08-31"),
      candidates: {
        create: [
          { fullName: "Nadia Kamau",   email: "nadia.k@gmail.com",   stage: "INTERVIEW", notes: "Strong RN experience, 4 yrs" },
          { fullName: "Eric Mutua",    email: "eric.m@gmail.com",    stage: "SCREENING", notes: "Junior, promising portfolio"  },
        ],
      },
    },
  });

  // Performance review
  await prisma.performanceReview.create({
    data: {
      staffId:    staffIds[5 - 1], // Pius
      reviewerId: staffIds[0],     // Daniel
      period:     "Q1 2025",
      score:      pct(88),
      comments:   "Excellent delivery of escrow API refactor. Needs more documentation discipline.",
    },
  });
}

// ---------------------------------------------------------------------------
// 10. BI: Saved report + KPI snapshots
// ---------------------------------------------------------------------------
async function seedBi() {
  const report = await prisma.savedReport.create({
    data: {
      name: "Weekly GMV & Fee Report",
      description: "Top-line transaction volume and platform revenue, weekly grain.",
      securityLevel: "INTERNAL",
      createdBy: "amina.osei@safebuy.africa",
      config: {
        metrics: ["total_gmv", "platform_revenue", "merchant_success_fee", "escrow_fee"],
        groupBy: "week",
        vizType: "line",
      },
    },
  });

  await prisma.scheduledReport.create({
    data: {
      savedReportId: report.id,
      frequency: "Weekly",
      recipients: ["amina.osei@safebuy.africa", "abdullahi.y@safebuy.africa"],
      nextRunAt: new Date("2025-07-07T08:00:00Z"),
      isActive: true,
    },
  });

  // KPI snapshots (last 5 days)
  const metrics = [
    { key: "total_gmv",          values: [3_200_000, 4_100_000, 2_800_000, 5_500_000, 3_900_000] },
    { key: "platform_revenue",   values: [112_000,   143_500,    98_000,   192_500,  136_500]    },
    { key: "active_disputes",    values: [3, 5, 4, 2, 4]                                         },
    { key: "verified_merchants", values: [41, 41, 42, 42, 43]                                    },
  ];

  const today = new Date();
  for (let i = 4; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateKey = d.toISOString().split("T")[0];

    for (const { key, values } of metrics) {
      await prisma.kpiSnapshot.upsert({
        where: {
          snapshotDate_metricKey_dimension_dimensionValue: {
            snapshotDate: new Date(dateKey),
            metricKey:    key,
            dimension:    "platform",
            dimensionValue: "all",
          },
        },
        create: {
          snapshotDate:   new Date(dateKey),
          metricKey:      key,
          metricValue:    ksh(values[4 - i]),
          dimension:      "platform",
          dimensionValue: "all",
        },
        update: {},
      });
    }
  }
}

// ---------------------------------------------------------------------------
// 11. Sys: Admin logs
// ---------------------------------------------------------------------------
async function seedAdminLogs(merchantIds: string[]) {
  await prisma.adminLog.createMany({
    data: [
      {
        actor:    "amina.osei@safebuy.africa",
        role:     "CEO",
        action:   "MERCHANT_VERIFIED",
        entity:   "merchant",
        entityId: merchantIds[0],
        newValue: { onboardingStep: "VERIFIED" },
      },
      {
        actor:    "abdullahi.y@safebuy.africa",
        role:     "Finance Lead",
        action:   "FEE_PLAN_CHANGED",
        entity:   "merchant",
        entityId: merchantIds[0],
        previousValue: { feePlan: "DEFAULT" },
        newValue:      { feePlan: "CUSTOM"  },
      },
      {
        actor:   "SYSTEM",
        action:  "DISPUTE_AUTO_FLAGGED",
        entity:  "transaction",
        newValue: { reason: "Risk score exceeded threshold of 60" },
      },
    ],
  });
}

// ---------------------------------------------------------------------------
// MAIN
// ---------------------------------------------------------------------------
async function main() {
  console.log("🌱  Seeding Safe Buy database…\n");

  console.log("  ➜  Escrow wallet");
  await seedWallet();

  console.log("  ➜  Fee plans");
  const feePlanIds = await seedFeePlans();

  console.log("  ➜  PSP configs");
  await seedPspConfigs();

  console.log("  ➜  Auditors");
  const auditorIds = await seedAuditors();

  console.log("  ➜  Merchants");
  const merchantIds = await seedMerchants(feePlanIds);

  console.log("  ➜  Products");
  const productIds = await seedProducts(merchantIds, auditorIds);

  console.log("  ➜  Delivery partners");
  const partnerIds = await seedDeliveryPartners();

  console.log("  ➜  Transactions + child records");
  await seedTransactions(merchantIds, productIds, partnerIds);

  console.log("  ➜  HR");
  await seedHr();

  console.log("  ➜  BI reports & KPI snapshots");
  await seedBi();

  console.log("  ➜  Admin logs");
  await seedAdminLogs(merchantIds);

  console.log("\n✅  Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());

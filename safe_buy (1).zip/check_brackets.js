const fs = require('fs');

const code = fs.readFileSync('src/components/AdminPortal.tsx', 'utf8');
const lines = code.split('\n');

let stack = [];
let insideComment = false;
let insideString = null; // ' or " or `

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  for (let j = 0; j < line.length; j++) {
    const char = line[j];
    const prev = j > 0 ? line[j-1] : '';
    const next = j < line.length - 1 ? line[j+1] : '';

    // Handle block comments
    if (insideComment) {
      if (char === '/' && prev === '*') {
        insideComment = false;
      }
      continue;
    }
    if (char === '/' && next === '*') {
      insideComment = true;
      j++;
      continue;
    }

    // Handle line comments
    if (char === '/' && next === '/') {
      break; // skip rest of line
    }

    // Handle strings
    if (insideString) {
      if (char === insideString && prev !== '\\') {
        insideString = null;
      }
      continue;
    }
    if ((char === "'" || char === '"' || char === '`') && prev !== '\\') {
      insideString = char;
      continue;
    }

    // Track brackets
    if (char === '(' || char === '{' || char === '[') {
      stack.push({ char, line: i + 1, col: j + 1 });
    } else if (char === ')' || char === '}' || char === ']') {
      if (stack.length === 0) {
        console.log(`Unmatched closing ${char} at line ${i + 1}, col ${j + 1}`);
      } else {
        const top = stack[stack.length - 1];
        if (
          (char === ')' && top.char === '(') ||
          (char === '}' && top.char === '{') ||
          (char === ']' && top.char === '[')
        ) {
          stack.pop();
        } else {
          console.log(`Mismatch: opened ${top.char} at line ${top.line}, col ${top.col} but closed with ${char} at line ${i + 1}, col ${j + 1}`);
          stack.pop(); // pop to recover
        }
      }
    }
  }
}

if (stack.length > 0) {
  console.log(`Remaining unclosed brackets in stack: ${stack.length}`);
  // show first 10
  stack.slice(0, 10).forEach(b => {
    console.log(`Unclosed ${b.char} opened at line ${b.line}, col ${b.col}`);
  });
} else {
  console.log("All parentheses, curly braces, and square brackets are perfectly balanced!");
}

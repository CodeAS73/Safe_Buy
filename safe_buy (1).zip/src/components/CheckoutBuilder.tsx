import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Instagram, 
  Send, 
  Link as LinkIcon, 
  Sparkles, 
  Smartphone, 
  CheckCircle, 
  HelpCircle, 
  Lock, 
  ShieldCheck, 
  ChevronRight, 
  FileText,
  Clock,
  QrCode,
  Share2,
  Copy,
  Check,
  MessageCircle,
  Facebook,
  Image as ImageIcon,
  AlertTriangle,
  UserCheck,
  Building,
  ArrowRight,
  TrendingUp,
  RotateCcw,
  Zap,
  Truck,
  MapPin,
  Calendar,
  Code,
  Globe,
  Plus,
  Minus,
  Briefcase,
  ShoppingCart,
  Trash2
} from 'lucide-react';
import { Transaction } from '../types';

const BASE_COURIERS = [
  {
    id: 'DP-001',
    name: 'Express Rider Kenya',
    phone: '254711223344',
    type: 'RIDER',
    avatar: '🏍️',
    isVerified: true,
    trustScore: 98,
    rating: 4.8,
    completedDeliveries: 342,
    availability: 'ONLINE',
    vehicleDetails: 'Motorcycle',
    vehicleType: 'Motorcycle',
    company: 'Express Rider Kenya',
    baseFee: 300,
    perKm: 0,
    timeText: '2 Hours',
    totalMins: 120
  },
  {
    id: 'DP-002',
    name: 'Swift Courier',
    phone: '254722334455',
    type: 'COURIER',
    avatar: '⚡',
    isVerified: true,
    trustScore: 99,
    rating: 4.9,
    completedDeliveries: 120,
    availability: 'ONLINE',
    vehicleDetails: 'Motorcycle / Sedan',
    vehicleType: 'Motorcycle',
    company: 'Swift Courier',
    baseFee: 350,
    perKm: 0,
    timeText: 'Same Day',
    totalMins: 480
  },
  {
    id: 'DP-003',
    name: 'Metro Logistics',
    phone: '254733445566',
    type: 'COURIER',
    avatar: '🚚',
    isVerified: true,
    trustScore: 97,
    rating: 4.7,
    completedDeliveries: 88,
    availability: 'ONLINE',
    vehicleDetails: 'Motorcycle',
    vehicleType: 'Motorcycle',
    company: 'Metro Logistics',
    baseFee: 280,
    perKm: 0,
    timeText: '4 Hours',
    totalMins: 240
  }
];

interface CheckoutBuilderProps {
  onTransactionCreated: (newTx: Transaction) => void;
}

export default function CheckoutBuilder({ onTransactionCreated }: CheckoutBuilderProps) {
  // Vendor Form/Config States (Left Side)
  const [socialUrl, setSocialUrl] = useState('https://www.instagram.com/p/C7W2be_sy1g/');
  const [itemName, setItemName] = useState('Classic Oversized Leather Bomber');
  const [price, setPrice] = useState('4800');
  const [stock, setStock] = useState('15');
  const [sellerHandle, setSellerHandle] = useState('@trendy_thrifts_ke');
  const [sellerPhone, setSellerPhone] = useState('254798765432');
  const [platform, setPlatform] = useState<'WhatsApp' | 'Instagram' | 'TikTok' | 'Facebook' | 'Telegram'>('Instagram');
  const [daysToDeliver, setDaysToDeliver] = useState(2);
  const [description, setDescription] = useState('Vintage premium heavy leather aviator jacket. Oversized fit, minimal wear, and authenticated hardware.');

  // Seller delivery rates configuration
  const [courierFee, setCourierFee] = useState('300');
  const [pickupFee, setPickupFee] = useState('0');
  const [sellerDeliveryFee, setSellerDeliveryFee] = useState('150');

  // Shipping Insurance states
  const [insurancePolicy, setInsurancePolicy] = useState<'NONE' | 'BUYER_CHOOSES' | 'SELLER_COVERS' | 'MANDATORY' | 'SHARED'>('BUYER_CHOOSES');
  const [selectedInsuranceOption, setSelectedInsuranceOption] = useState<'NONE' | 'BASIC' | 'ENHANCED'>('BASIC');

  // Interactive Embed Tab State
  const [formTab, setFormTab] = useState<'configure' | 'embeds'>('configure');

  // Product Inspection Program States
  const [productCategory, setProductCategory] = useState<'Apparel & Fashion' | 'Electronics & Gadgets' | 'Vehicles & Motors' | 'Machinery & Tools' | 'Furniture & Living' | 'Other Products'>('Electronics & Gadgets');
  const [verificationStatus, setVerificationStatus] = useState<'UNVERIFIED' | 'AUDITOR_ASSIGNED' | 'INSPECTION_COMPLETED' | 'VERIFIED' | 'EXPIRED'>('UNVERIFIED');
  const [verificationTier, setVerificationTier] = useState<'STANDARD' | 'PRIORITY' | 'PREMIUM'>('STANDARD');
  const [verificationFee, setVerificationFee] = useState<number>(450);
  const [selectedAuditorId, setSelectedAuditorId] = useState<string>('DP-003');
  const [verificationReport, setVerificationReport] = useState<any>(null);
  const [verificationAt, setVerificationAt] = useState<string>('');
  const [verificationExpiresAt, setVerificationExpiresAt] = useState<string>('');
  const [showMpesaPrompt, setShowMpesaPrompt] = useState(false);
  const [mpesaPaymentNumber, setMpesaPaymentNumber] = useState('0712345678');
  const [isVerifyingPayment, setIsVerifyingPayment] = useState(false);
  const [bulkPlanSubscribed, setBulkPlanSubscribed] = useState<'NONE' | 'BASIC' | 'GROWTH' | 'ENTERPRISE'>('NONE');
  const [showBulkPlanSuccess, setShowBulkPlanSuccess] = useState(false);

  // Form Condition Audit
  const [auditCondition, setAuditCondition] = useState<'Excellent' | 'Good' | 'Fair' | 'Poor'>('Excellent');
  const [auditSerial, setAuditSerial] = useState('X894-AUDIT-KE');
  const [auditFunctional, setAuditFunctional] = useState(true);
  const [auditNotes, setAuditNotes] = useState('Physically verified pre-sale product on premise. Tested buttons, chassis condition, and serial number. Everything operates properly without standard faults.');

  const CATEGORY_DETAILS: Record<string, { standard: number, priority: number, premium: number, validity: number }> = {
    'Apparel & Fashion': { standard: 300, priority: 500, premium: 800, validity: 30 },
    'Electronics & Gadgets': { standard: 500, priority: 750, premium: 1000, validity: 30 },
    'Vehicles & Motors': { standard: 1200, priority: 1500, premium: 2000, validity: 14 },
    'Machinery & Tools': { standard: 500, priority: 850, premium: 1500, validity: 30 },
    'Furniture & Living': { standard: 400, priority: 800, premium: 1100, validity: 60 },
    'Other Products': { standard: 300, priority: 500, premium: 800, validity: 30 }
  };

  // --- Smart Escrow Widget Configurator States ---
  const [embedOption, setEmbedOption] = useState<'A' | 'B' | 'C' | 'D'>('B'); // Option A: Buy Now Widget, Option B: Smart Cart Widget, Option C: Storefront Widget, Option D: Floating Buy Safely Widget
  const [thumbnailSource, setThumbnailSource] = useState<'UPLOAD' | 'WEBSITE' | 'SOCIAL'>('UPLOAD'); // Method 1, Method 2, Method 3
  const [websiteUrl, setWebsiteUrl] = useState('https://shop.trendy-thrifts.co.ke/classic-leather-bomber-jacket');
  const [socialUrlWidget, setSocialUrlWidget] = useState('https://www.instagram.com/p/C7W2be_sy1g/');
  const [isExtractingWeb, setIsExtractingWeb] = useState(false);
  const [isExtractingSocial, setIsExtractingSocial] = useState(false);
  const [additionalImages, setAdditionalImages] = useState<string[]>([]);
  const [socialSpecificBehavior, setSocialSpecificBehavior] = useState<'whatsapp' | 'instagram' | 'facebook' | 'website'>('website');
  
  // New Smart Cart & Multi-Product States
  const [widgetCart, setWidgetCart] = useState<Array<{
    product: {
      id: string;
      title: string;
      price: number;
      image: string;
      sellerHandle: string;
      category: string;
    };
    quantity: number;
    insured: boolean;
  }>>([]);
  
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile' | 'popup' | 'cart'>('desktop');
  const [cartConflictPromptOpen, setCartConflictPromptOpen] = useState(false);
  const [pendingConflictItem, setPendingConflictItem] = useState<any>(null);
  
  // Widget Checkout Popup State
  const [isWidgetCheckoutOpen, setIsWidgetCheckoutOpen] = useState(false);
  const [widgetQuantity, setWidgetQuantity] = useState(1);
  const [feeConfig, setFeeConfig] = useState<any>(null);

  useEffect(() => {
    fetch('/api/fees/config')
      .then(res => res.json())
      .then(data => {
        setFeeConfig(data);
      })
      .catch(err => console.error("Error loading fee configuration:", err));
  }, []);

  const getDynamicProtectionFee = (subtotal: number, handle: string) => {
    if (!feeConfig) {
      return Math.max(Math.round(subtotal * 0.01), 25);
    }

    const activePsp = feeConfig.pspBankConfigs?.find((p: any) => p.status === 'ACTIVE') || feeConfig.pspBankConfigs?.[0];
    if (!activePsp) {
      return Math.max(Math.round(subtotal * 0.01), 25);
    }

    const rate = activePsp.escrowRate / 100;
    let calculatedEscrowFee = Math.round(subtotal * rate) + activePsp.flatAmount;
    
    if (calculatedEscrowFee < activePsp.minimumFee) {
      calculatedEscrowFee = activePsp.minimumFee;
    } else if (calculatedEscrowFee > activePsp.maximumFee) {
      calculatedEscrowFee = activePsp.maximumFee;
    }

    const ownership = activePsp.ownershipModel;
    if (ownership === 'BUYER_PAYS') {
      return calculatedEscrowFee;
    } else if (ownership === 'SELLER_PAYS' || ownership === 'MERCHANT_SPONSORED') {
      return 0;
    } else if (ownership === 'SHARED') {
      return Math.round(calculatedEscrowFee * 0.5);
    } else if (ownership === 'PROMOTIONAL_WAIVER') {
      return 0;
    }

    return calculatedEscrowFee;
  };

  const [widgetDeliveryMethod, setWidgetDeliveryMethod] = useState<'Courier' | 'Rider' | 'Pickup'>('Courier');
  const [widgetInsurance, setWidgetInsurance] = useState(true);
  const [widgetBuyerPhone, setWidgetBuyerPhone] = useState('0712345678');
  const [widgetBuyerName, setWidgetBuyerName] = useState('John Kamau');
  const [widgetRecipientAddress, setWidgetRecipientAddress] = useState('Muringa Road, Kilimani, Nairobi');
  
  // Widget Checkout Payment Step (Follows: Cart -> Recipient -> Delivery -> Insurance -> Breakdown -> Payment)
  const [widgetStep, setWidgetStep] = useState<'cart' | 'recipient' | 'delivery' | 'insurance' | 'breakdown' | 'stk' | 'success'>('cart');
  const [isProcessingWidgetCheckout, setIsProcessingWidgetCheckout] = useState(false);
  const [widgetMpesaPin, setWidgetMpesaPin] = useState('');

  const handleAddToCart = (prod: any) => {
    const otherMerchantItem = widgetCart.find(item => item.product.sellerHandle !== prod.sellerHandle);
    if (otherMerchantItem) {
      setPendingConflictItem(prod);
      setCartConflictPromptOpen(true);
      return;
    }
    
    const existing = widgetCart.find(item => item.product.id === prod.id);
    if (existing) {
      setWidgetCart(widgetCart.map(item => 
        item.product.id === prod.id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setWidgetCart([...widgetCart, { product: prod, quantity: 1, insured: true }]);
    }
  };

  const handleBuyNow = (prod: any) => {
    setWidgetCart([{ product: prod, quantity: 1, insured: true }]);
    setIsWidgetCheckoutOpen(true);
    setWidgetStep('cart');
  };

  // Image Upload State
  const [uploadedImageBase64, setUploadedImageBase64] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Extraction Progress State
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractionAlert, setExtractionAlert] = useState<{ type: 'success' | 'warn' | 'error', text: string } | null>(null);
  const [scamRisk, setScamRisk] = useState<number | null>(null);
  const [scamComments, setScamComments] = useState<string>('');

  // PAE Specific Workspace States
  const [importMethod, setImportMethod] = useState<'url' | 'screenshot' | 'image' | 'video' | 'whatsapp' | 'manual'>('url');
  const [paeDetails, setPaeDetails] = useState<any>({
    confidenceScore: 85,
    confidenceLevel: 'MEDIUM',
    highlightedFields: ['category'],
    originalPriceText: 'Ksh 4,800',
    layersApplied: ['Layer 1: Open Graph Metadata', 'Layer 2: Caption & Description Analysis', 'Layer 7: Manual Confirmation'],
    primaryLayerUsed: 'Layer 2: Caption Analysis',
    confidenceReason: 'Price matches caption tags. Category inferred with 85% confidence score.',
    suggestions: {
      productTitle: [
        'Classic Vintage Oversized Leather Bomber',
        'Thrift Premium Heavy Aviator Jacket',
        'Double-zipper Distressed Cowstride Bomber'
      ],
      category: ['Apparel & Fashion', 'Other Products'],
      tags: ['EscrowProtected', 'NairobiFashion', 'ThriftOriginals', 'VintageGradeA'],
      description: '✨ Vintage premium heavy leather aviator jacket. Fitted with oversized shoulders, robust brass zipper, and soft leather collar. Authentic hardware.'
    }
  });

  // Link status
  const [generatedLink, setGeneratedLink] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [copiedSnippetType, setCopiedSnippetType] = useState<string | null>(null);

  // --- Buyer Checkout Sandbox States (Right Side Phone Simulator) ---
  const [buyerQty, setBuyerQty] = useState(1);
  const [selectedShipping, setSelectedShipping] = useState<'Courier' | 'Pickup' | 'Seller Delivery'>('Courier');
  const [selectedCourierId, setSelectedCourierId] = useState<string>('DP-001');
  const [courierSort, setCourierSort] = useState<'recommended' | 'cheapest' | 'fastest' | 'highest_rated'>('recommended');
  const [phoneError, setPhoneError] = useState('');
  
  // Buyer profile integration flags
  const [buyerName, setBuyerName] = useState('James Kamau');
  const [buyerAccountType, setBuyerAccountType] = useState<'REGISTERED' | 'GUEST'>('GUEST');
  const [buyerNationalId, setBuyerNationalId] = useState('');
  
  // Alternative recipient details check
  const [isNotRecipient, setIsNotRecipient] = useState(false);
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientAddress, setRecipientAddress] = useState('');
  const [recipientRelationship, setRecipientRelationship] = useState('Friend');

  // Mobile Network details
  const [buyerPhoneInput, setBuyerPhoneInput] = useState('0712345678');
  const [buyerNetwork, setBuyerNetwork] = useState<'mpesa' | 'airtel' | 'tcash'>('mpesa');

  // Delivery details filled by guest buyer in checkout simulator
  const [county, setCounty] = useState('Nairobi');
  const [town, setTown] = useState('Kilimani');
  const [address, setAddress] = useState('Yaya Centre Apartments, Block C, Apt 4');
  const [contactPerson, setContactPerson] = useState('James Kamau');
  const [buyerContactPhone, setBuyerContactPhone] = useState('0712345678');

  const [pickupLocation, setPickupLocation] = useState('Nairobi CBD - Kimathi Street Coop Tower Ground Floor Shop');
  const [pickupDate, setPickupDate] = useState('2026-06-03');
  const [pickupContact, setPickupContact] = useState('Main Office Agent');

  const [deliveryArea, setDeliveryArea] = useState('Westlands & Parklands General Area');
  const [deliveryContactDetails, setDeliveryContactDetails] = useState('0722334455 (Boda Despatcher)');

  // Smartphone simulator checkout flow step
  const [phoneStep, setPhoneStep] = useState<'storefront' | 'cart' | 'checkout' | 'payment' | 'stk' | 'success'>('storefront');

  // Playground Multi-Product Shopping Cart
  const [playgroundCart, setPlaygroundCart] = useState<Array<{
    product: {
      id: string;
      title: string;
      price: number;
      image: string;
      sellerHandle: string;
      category: string;
      description: string;
      stock: number;
    };
    quantity: number;
    insured: boolean;
  }>>([]);

  const getPlaygroundProducts = () => {
    return [
      {
        id: 'PROD-001',
        title: itemName || 'Premium Leather Bomber Jacket',
        price: parseFloat(price) || 2500,
        image: uploadedImageBase64 || '',
        sellerHandle: sellerHandle || '@trendy_thrifts_ke',
        category: productCategory || 'Apparel & Fashion',
        description: description || 'Independently inspected high-grade hand-crafted genuine leather.',
        stock: parseInt(stock) || 5
      },
      {
        id: 'PROD-002',
        title: `${itemName || 'Bomber Jacket'} Pro Care Kit`,
        price: Math.max(450, Math.round((parseFloat(price) || 2500) * 0.15)),
        image: '',
        sellerHandle: sellerHandle || '@trendy_thrifts_ke',
        category: productCategory || 'Apparel & Fashion',
        description: 'Complete maintenance kit containing organic leather balm, microfibre cloths, and weather-proof coating spray.',
        stock: 12
      },
      {
        id: 'PROD-003',
        title: 'Premium Velvet Storage Hanger',
        price: Math.max(250, Math.round((parseFloat(price) || 2500) * 0.08)),
        image: '',
        sellerHandle: sellerHandle || '@trendy_thrifts_ke',
        category: productCategory || 'Apparel & Fashion',
        description: 'Heavy duty, non-slip velvet hanger designed specifically to maintain the shoulder shape of premium garments.',
        stock: 20
      }
    ];
  };

  const getPlaygroundSubtotal = () => {
    return playgroundCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  };

  const getPlaygroundProtectionFee = () => {
    const subtotal = getPlaygroundSubtotal();
    return subtotal > 0 ? getDynamicProtectionFee(subtotal, sellerHandle) : 0;
  };

  const getPlaygroundInsurancePremium = () => {
    if (insurancePolicy === 'NONE' || insurancePolicy === 'SELLER_COVERS' || selectedInsuranceOption === 'NONE') {
      return 0;
    }
    const subtotal = getPlaygroundSubtotal();
    const fullPremium = getInsurancePremium(subtotal, selectedInsuranceOption);
    if (insurancePolicy === 'SHARED') {
      return Math.round(fullPremium * 0.5);
    }
    return fullPremium;
  };

  const getPlaygroundShippingFee = () => {
    if (playgroundCart.length === 0) return 0;
    if (selectedShipping === 'Pickup') return parseFloat(pickupFee) || 0;
    if (selectedShipping === 'Seller Delivery') return parseFloat(sellerDeliveryFee) || 0;
    if (selectedShipping === 'Courier') {
      return getSelectedShippingFee();
    }
    return 0;
  };

  const getPlaygroundTotalAmount = () => {
    return getPlaygroundSubtotal() + getPlaygroundShippingFee() + getPlaygroundProtectionFee() + getPlaygroundInsurancePremium();
  };

  const handlePlaygroundSTKPayment = async () => {
    if (!validatePhone(buyerPhoneInput)) return;
    
    setPhoneStep('stk');
    
    // Simulate Daraja network STK response loop
    setTimeout(async () => {
      try {
        const subtotal = getPlaygroundSubtotal();
        const shipFee = getPlaygroundShippingFee();
        const insPrem = getPlaygroundInsurancePremium();
        const finalTotal = getPlaygroundTotalAmount();
        
        const descText = playgroundCart.map(item => `${item.product.title} (Qty: ${item.quantity})`).join(', ');

        const currentShippingDetails = selectedShipping === 'Courier' ? {
          county,
          town,
          address,
          contactPerson: isNotRecipient ? recipientName : buyerName,
          phone: isNotRecipient ? recipientPhone : buyerPhoneInput
        } : selectedShipping === 'Pickup' ? {
          pickupLocation,
          pickupDate,
          pickupContact
        } : {
          deliveryArea,
          deliveryContact: deliveryContactDetails
        };

        const selectedCourier = selectedShipping === 'Courier' ? getEnrichedCouriers().find(c => c.id === selectedCourierId) : null;

        const response = await fetch('/api/transactions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            buyerPhone: buyerPhoneInput,
            buyerEmail: buyerAccountType === 'REGISTERED' ? `${buyerName.toLowerCase().replace(/\s+/g, '')}@gmail.com` : '',
            buyerName,
            buyerAccountType,
            buyerNationalId: buyerAccountType === 'REGISTERED' ? buyerNationalId : '',
            isNotRecipient,
            recipientDetails: isNotRecipient ? {
              name: recipientName,
              phone: recipientPhone,
              address: `${county}, ${town}, ${address}`,
              relationship: recipientRelationship
            } : {
              name: buyerName,
              phone: buyerPhoneInput,
              address: selectedShipping === 'Courier' ? `${county}, ${town}, ${address}` : (selectedShipping === 'Pickup' ? pickupLocation : deliveryArea),
              relationship: 'Self'
            },
            sellerPhone,
            sellerHandle,
            socialPlatform: platform,
            amount: subtotal,
            description: descText,
            quantity: playgroundCart.reduce((sum, item) => sum + item.quantity, 0),
            shippingMethod: selectedShipping,
            shippingFee: shipFee,
            totalAmount: finalTotal,
            paymentNetwork: buyerNetwork,
            shippingDetails: currentShippingDetails,
            orderStatus: 'PAID_PENDING_FULFILLMENT',
            deliveryPartnerId: selectedCourier ? selectedCourier.id : undefined,
            deliveryPartnerName: selectedCourier ? selectedCourier.name : undefined,
            deliveryPartnerType: selectedCourier ? selectedCourier.type : undefined,
            deliveryStatus: selectedCourier ? 'COURIER_ASSIGNED' : undefined,
            deliveryPin: selectedCourier ? Math.floor(100000 + Math.random() * 900000).toString() : undefined,
            deliveryPinEntered: false,
            insurancePolicy,
            insuranceOption: selectedInsuranceOption,
            insurancePremium: insPrem,
            insurancePaidBy: insurancePolicy === 'SELLER_COVERS' ? 'SELLER' : (insurancePolicy === 'SHARED' ? 'SHARED' : (selectedInsuranceOption === 'NONE' ? 'NONE' : 'BUYER')),
            cartEnabled: true,
            items: playgroundCart.map(item => ({
              productId: item.product.id,
              title: item.product.title,
              price: item.product.price,
              quantity: item.quantity
            })),
            packages: [
              {
                id: `PKG-${Math.floor(1000 + Math.random() * 9000)}`,
                items: playgroundCart.map(item => item.product.id),
                carrier: selectedCourier ? selectedCourier.name : 'Safe Buy Dispatch',
                shippingFee: shipFee,
                status: 'PENDING'
              }
            ]
          })
        });

        if (!response.ok) throw new Error('STK push register failed');
        const newTx = await response.json();
        
        await fetch(`/api/transactions/${newTx.id}/deposit`, { method: 'POST' });
        
        setPhoneStep('success');
        onTransactionCreated(newTx);
        
      } catch (err) {
        console.error(err);
        setPhoneStep('checkout');
        alert('STK push network simulation timing overflowed. Please try again.');
      }
    }, 1500);
  };

  // Drag and drop event handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFileInput(e.dataTransfer.files[0]);
    }
  };

  const processFileInput = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setUploadedImageBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFileInput(e.target.files[0]);
    }
  };

  const clearImage = () => {
    setUploadedImageBase64(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const [activeProductId, setActiveProductId] = useState<string>('');

  const handleRegisterAndRequest = async (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      let prodId = activeProductId;
      if (!prodId) {
        const createRes = await fetch('/api/verified-products/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: itemName,
            category: productCategory,
            price: Number(price) || 2500,
            description: description,
            sellerHandle,
            sellerPhone
          })
        });
        if (createRes.ok) {
          const newProd = await createRes.json();
          if (newProd) {
            prodId = newProd.id;
            setActiveProductId(prodId);
          }
        }
      }

      setShowMpesaPrompt(true);
    } catch (err) {
      console.error('Failed to initiate product verification request:', err);
    }
  };

  const handleConfirmMpesaPayment = async () => {
    if (!mpesaPaymentNumber) {
      alert('Please enter a valid M-Pesa phone number.');
      return;
    }
    setIsVerifyingPayment(true);
    
    setTimeout(async () => {
      try {
        const feeAmount = CATEGORY_DETAILS[productCategory][verificationTier.toLowerCase() as 'standard' | 'priority' | 'premium'];
        
        const response = await fetch(`/api/verified-products/${activeProductId}/request`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tier: verificationTier,
            fee: feeAmount,
            auditorId: selectedAuditorId,
            auditorName: selectedAuditorId === 'DP-003' ? 'Picker Alex (Safety Inspector)' : 'Independent Trust Auditor'
          })
        });

        if (response.ok) {
          const updatedProd = await response.json();
          setVerificationStatus(updatedProd.verificationStatus);
          setVerificationTier(updatedProd.verificationTier);
          setVerificationFee(updatedProd.verificationFee);
          setVerificationReport(updatedProd.verificationReport);
        }
        
        setShowMpesaPrompt(false);
        setIsVerifyingPayment(false);
      } catch (err) {
        console.error('Error recording verification payment:', err);
        setIsVerifyingPayment(false);
      }
    }, 1500);
  };

  const handleAuditorInspectSubmit = async () => {
    try {
      const response = await fetch(`/api/verified-products/${activeProductId}/submit-report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          condition: auditCondition,
          functionalPass: auditFunctional,
          serialNumber: auditSerial,
          notes: auditNotes,
          outcome: auditFunctional ? 'Verified' : 'Verification Failed'
        })
      });

      if (response.ok) {
        const updatedProd = await response.json();
        setVerificationStatus(updatedProd.verificationStatus);
        setVerificationReport(updatedProd.verificationReport);
      }
    } catch (err) {
      console.error('Error submitting auditor inspection report:', err);
    }
  };

  const handleInstantSystemApprove = async () => {
    try {
      const response = await fetch(`/api/verified-products/${activeProductId}/approve`, {
        method: 'POST'
      });

      if (response.ok) {
        const updatedProd = await response.json();
        setVerificationStatus(updatedProd.verificationStatus);
        setVerificationAt(updatedProd.verifiedAt || '');
        setVerificationExpiresAt(updatedProd.expiresAt || '');
      }
    } catch (err) {
      console.error('Error approving product verification report:', err);
    }
  };

  const handleSubscribeBulkPlan = async (plan: 'BASIC' | 'GROWTH' | 'ENTERPRISE') => {
    try {
      const response = await fetch('/api/verified-products/subscribe-bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sellerHandle,
          planName: plan
        })
      });

      if (response.ok) {
        setBulkPlanSubscribed(plan);
        setShowBulkPlanSuccess(true);
        setTimeout(() => setShowBulkPlanSuccess(false), 3000);
      }
    } catch (err) {
      console.error('Error subscribing to bulk package:', err);
    }
  };

  // AI OCR and PAE details extractor call
  const handleAIExtract = async () => {
    if (importMethod === 'url' && !socialUrl) {
      setExtractionAlert({ type: 'error', text: 'Please paste a social post URL first.' });
      return;
    }
    if ((importMethod === 'screenshot' || importMethod === 'image' || importMethod === 'video' || importMethod === 'whatsapp') && !uploadedImageBase64) {
      setExtractionAlert({ type: 'error', text: 'Please select or upload a media file/screenshot first for visual parsing.' });
      return;
    }

    setIsExtracting(true);
    setExtractionAlert(null);

    try {
      const response = await fetch('/api/social-extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          socialUrl: importMethod === 'url' ? socialUrl : '',
          imageBase64: uploadedImageBase64 || '',
          importMethod: importMethod
        })
      });

      if (!response.ok) throw new Error('AI extraction pipeline timed out or encountered an error.');
      const data = await response.json();
      
      if (data.success && data.result) {
        const res = data.result;
        setPaeDetails(res);
        setItemName(res.productTitle || itemName);
        setPrice(String(res.price || price));
        setSellerHandle(res.sellerHandle || sellerHandle);
        setDescription(res.description || description);
        setDaysToDeliver(res.deliveryTimelineDays || daysToDeliver);
        setScamRisk(res.estimatedRisk || 5);
        setScamComments(res.duplicateScamRating || '');
        
        // Match discovery platform dynamically based on url / selection
        if (importMethod === 'url' && socialUrl) {
          if (socialUrl.includes('instagram.com')) setPlatform('Instagram');
          else if (socialUrl.includes('tiktok.com')) setPlatform('TikTok');
          else if (socialUrl.includes('facebook.com')) setPlatform('Facebook');
          else if (socialUrl.includes('t.me') || socialUrl.includes('telegram')) setPlatform('Telegram');
          else if (socialUrl.includes('whatsapp')) setPlatform('WhatsApp');
        } else if (importMethod === 'whatsapp') {
          setPlatform('WhatsApp');
        } else if (importMethod === 'video') {
          setPlatform('TikTok');
        }

        setExtractionAlert({
          type: res.confidenceLevel === 'LOW' ? 'warn' : 'success',
          text: `Success: Product draft compiled from ${res.primaryLayerUsed} at ${res.confidenceScore}% confidence.`
        });
      }
    } catch (e: any) {
      setExtractionAlert({ type: 'error', text: 'PAE Pipeline Failure: ' + e.message });
    } finally {
      setIsExtracting(false);
    }
  };

  // Helper to load sample files for immediate testing of fallback visual layers
  const handleLoadSample = (methodType: 'screenshot' | 'image' | 'video' | 'whatsapp') => {
    let mockImg = '';
    if (methodType === 'screenshot') {
      mockImg = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200" style="background:%23eceff1"><text x="20" y="50" font-family="sans-serif" font-weight="bold" font-size="14" fill="%2337474f">Instagram Post Screenshot</text><text x="20" y="80" font-family="sans-serif" font-size="12" fill="%23455a64">Handle: @trendy_thrifts_ke</text><text x="20" y="110" font-family="sans-serif" font-weight="bold" font-size="16" fill="%231b5e20">Price: KES 4,800</text></svg>';
    } else if (methodType === 'image') {
      mockImg = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200" style="background:%23e8eaf6"><text x="20" y="50" font-family="sans-serif" font-weight="bold" font-size="14" fill="%231a237e">Product Photo Asset</text><text x="20" y="100" font-family="sans-serif" font-size="12" fill="%23283593">Vintage Leather Jacket Details</text></svg>';
    } else if (methodType === 'video') {
      mockImg = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200" style="background:%23f3e5f5"><text x="20" y="50" font-family="sans-serif" font-weight="bold" font-size="14" fill="%234a148c">TikTok Frame Overlay Extraction</text><text x="20" y="80" font-family="sans-serif" font-size="12" fill="%236a1b9a">Maasai Sandals video snippet</text><text x="20" y="110" font-family="sans-serif" font-weight="bold" font-size="16" fill="%23311b92">Ksh 1,800</text></svg>';
    } else if (methodType === 'whatsapp') {
      mockImg = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200" style="background:%23e8f5e9"><text x="20" y="50" font-family="sans-serif" font-weight="bold" font-size="14" fill="%231b5e20">WhatsApp Catalog Snapshot</text><text x="20" y="80" font-family="sans-serif" font-size="12" fill="%232e7d32">Catalog Item: Glycolic Hydration Serum</text><text x="20" y="110" font-family="sans-serif" font-weight="bold" font-size="16" fill="%231b5e20">Ksh 2,999</text></svg>';
    }
    setUploadedImageBase64(mockImg);
  };

  // Courier list generation with dynamic distance, dynamic fee, and sorting
  const getEnrichedCouriers = () => {
    // Determine base distance multiplier based on town
    let distanceMultiplier = 1.0;
    const normalizedTown = (town || '').toLowerCase().trim();
    if (normalizedTown.includes('kilimani') || normalizedTown.includes('yaya')) {
      distanceMultiplier = 1.2;
    } else if (normalizedTown.includes('westlands')) {
      distanceMultiplier = 1.0;
    } else if (normalizedTown.includes('cbd') || normalizedTown.includes('town') || normalizedTown.includes('central')) {
      distanceMultiplier = 0.5;
    } else if (normalizedTown.includes('karen') || normalizedTown.includes('runda')) {
      distanceMultiplier = 2.8;
    } else if (normalizedTown.includes('imara') || normalizedTown.includes('mombasa')) {
      distanceMultiplier = 2.0;
    } else if (normalizedTown.length > 0) {
      distanceMultiplier = 1.5;
    }

    // 1. Filter couriers based on rules:
    //    - Active status = ONLINE
    //    - Verified identity = TRUE
    //    - Minimum rating threshold (rating > 3.5)
    //    - Within service radius (modeled dynamically)
    const filtered = BASE_COURIERS.filter(c => {
      const isOnline = c.availability === 'ONLINE';
      const isVerified = c.isVerified === true;
      const isGoodRating = c.rating > 3.5;
      return isOnline && isVerified && isGoodRating;
    });

    // 2. Enrich couriers with distance, pricing, and estimated time
    const enriched = filtered.map(c => {
      let baseDistance = 3.5;
      if (c.type === 'PICKER') baseDistance = 1.2;
      else if (c.type === 'RIDER') baseDistance = 2.8;
      else if (c.type === 'DRIVER') baseDistance = 4.2;
      else if (c.type === 'COURIER') baseDistance = 5.0;

      const finalDistance = Math.round((baseDistance * distanceMultiplier) * 10) / 10;
      
      // Delivery fee is calculated from base fee + distance rate
      const finalFee = Math.round(c.baseFee + (finalDistance * c.perKm));

      // Estimated speed factor in minutes per km
      let speedFactor = 5;
      if (c.type === 'RIDER') speedFactor = 4;
      else if (c.type === 'DRIVER') speedFactor = 6;
      else if (c.type === 'PICKER') speedFactor = 15;
      else if (c.type === 'COURIER') speedFactor = 8;
      
      const totalMins = c.totalMins !== undefined ? c.totalMins : Math.round(finalDistance * speedFactor + 10);
      const timeText = c.timeText || (totalMins < 60 ? `${totalMins} Mins` : `${Math.floor(totalMins / 60)}h ${totalMins % 60}m`);

      return {
        ...c,
        distance: finalDistance,
        fee: finalFee,
        timeText,
        totalMins
      };
    });

    // 3. Sort based on buyer preferences
    if (courierSort === 'cheapest') {
      return enriched.sort((a, b) => a.fee - b.fee);
    } else if (courierSort === 'fastest') {
      return enriched.sort((a, b) => a.totalMins - b.totalMins);
    } else if (courierSort === 'highest_rated') {
      return enriched.sort((a, b) => b.rating - a.rating);
    } else {
      // Default: Recommended (closest and highest rated)
      return enriched.sort((a, b) => (b.rating * 10 - b.distance) - (a.rating * 10 - a.distance));
    }
  };

  // Real-time Shipping cost calculations based on user config values
  const getSelectedShippingFee = () => {
    if (selectedShipping === 'Courier') {
      const enriched = getEnrichedCouriers();
      const selectedCourier = enriched.find(c => c.id === selectedCourierId);
      if (selectedCourier) return selectedCourier.fee;
      // return first one as fallback if selected ID was filtered out
      if (enriched.length > 0) return enriched[0].fee;
      return parseFloat(courierFee) || 0;
    }
    if (selectedShipping === 'Pickup') return parseFloat(pickupFee) || 0;
    if (selectedShipping === 'Seller Delivery') return parseFloat(sellerDeliveryFee) || 0;
    return 0;
  };

  const getSubtotal = () => {
    const unitPrice = parseFloat(price) || 0;
    return unitPrice * buyerQty;
  };

  const getInsurancePremium = (amount: number, option: 'NONE' | 'BASIC' | 'ENHANCED') => {
    if (option === 'NONE') return 0;
    
    // Choose rate based on amount tiers
    let rate = 0;
    if (amount <= 5000) rate = 0.015; // 1.5%
    else if (amount <= 20000) rate = 0.012; // 1.2%
    else if (amount <= 100005) rate = 0.010; // 1.0%
    else rate = 0.008; // 0.8%

    // Calculate premium
    let premium = amount * rate;
    
    // Apply Enhanced Cover loading fee (+25% premium and +Ksh 50 basic fee loading)
    if (option === 'ENHANCED') {
      premium = premium * 1.25 + 50;
    }

    // Minimum premium Ksh 40
    return Math.max(Math.round(premium), 40);
  };

  const getBuyerInsurancePremium = () => {
    if (insurancePolicy === 'NONE' || insurancePolicy === 'SELLER_COVERS' || selectedInsuranceOption === 'NONE') {
      return 0;
    }
    const fullPremium = getInsurancePremium(getSubtotal(), selectedInsuranceOption);
    if (insurancePolicy === 'SHARED') {
      return Math.round(fullPremium * 0.5);
    }
    return fullPremium;
  };

  const getProtectionFee = () => {
    const subtotal = getSubtotal();
    return getDynamicProtectionFee(subtotal, sellerHandle);
  };

  const buyerInsurancePremium = getBuyerInsurancePremium();
  const totalCheckoutAmount = getSubtotal() + getSelectedShippingFee() + getProtectionFee() + buyerInsurancePremium;

  // STK mobile number validation check
  const validatePhone = (num: string) => {
    // Kenya standard coordinates - 07XXXXXXXX or 01XXXXXXXX (10 digits)
    const normalized = num.trim();
    if (!/^(07|01)\d{8}$/.test(normalized)) {
      setPhoneError('Please enter a valid Kenayan mobile number (07XXXXXXXX or 01XXXXXXXX)');
      return false;
    }
    setPhoneError('');
    return true;
  };

  // Build Short protected pay Link for vendor listing
  const handleGenerateLink = (e: React.FormEvent) => {
    e.preventDefault();
    const shortCode = Math.random().toString(36).substring(2, 7).toUpperCase();
    const link = `https://buysafely.africa/pay/${shortCode}`;
    setGeneratedLink(link);
    setIsCopied(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedLink);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Copy code snippets for WordPress / Shopify
  const handleCopySnippet = (snippet: string, type: string) => {
    navigator.clipboard.writeText(snippet);
    setCopiedSnippetType(type);
    setTimeout(() => setCopiedSnippetType(null), 2540);
  };

  // Initiate real transaction upon STK trigger inside mock phone
  const handleTriggerSTKPayment = async () => {
    if (!validatePhone(buyerPhoneInput)) return;
    
    setPhoneStep('stk_paying');
    
    // Simulate Daraja network STK response loop
    setTimeout(async () => {
      try {
        const unitPrice = parseFloat(price) || 0;
        const currentShippingDetails = selectedShipping === 'Courier' ? {
          county,
          town,
          address,
          contactPerson: isNotRecipient ? recipientName : buyerName,
          phone: isNotRecipient ? recipientPhone : buyerPhoneInput
        } : selectedShipping === 'Pickup' ? {
          pickupLocation,
          pickupDate,
          pickupContact
        } : {
          deliveryArea,
          deliveryContact: deliveryContactDetails
        };

        const selectedCourier = selectedShipping === 'Courier' ? getEnrichedCouriers().find(c => c.id === selectedCourierId) : null;

        const response = await fetch('/api/transactions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            buyerPhone: buyerPhoneInput,
            buyerEmail: buyerAccountType === 'REGISTERED' ? `${buyerName.toLowerCase().replace(/\s+/g, '')}@gmail.com` : '',
            buyerName,
            buyerAccountType,
            buyerNationalId: buyerAccountType === 'REGISTERED' ? buyerNationalId : '',
            isNotRecipient,
            recipientDetails: isNotRecipient ? {
              name: recipientName,
              phone: recipientPhone,
              address: recipientAddress || `${county}, ${town}, ${address}`,
              relationship: recipientRelationship
            } : {
              name: buyerName,
              phone: buyerPhoneInput,
              address: selectedShipping === 'Courier' ? `${county}, ${town}, ${address}` : (selectedShipping === 'Pickup' ? pickupLocation : deliveryArea),
              relationship: 'Self'
            },
            sellerPhone,
            sellerHandle,
            socialPlatform: platform,
            amount: unitPrice,
            description: itemName,
            quantity: buyerQty,
            shippingMethod: selectedShipping,
            shippingFee: getSelectedShippingFee(),
            totalAmount: totalCheckoutAmount,
            paymentNetwork: buyerNetwork,
            shippingDetails: currentShippingDetails,
            orderStatus: 'PAID_PENDING_FULFILLMENT', // Starts as paid pending escrow hold
            deliveryPartnerId: selectedCourier ? selectedCourier.id : undefined,
            deliveryPartnerName: selectedCourier ? selectedCourier.name : undefined,
            deliveryPartnerType: selectedCourier ? selectedCourier.type : undefined,
            deliveryStatus: selectedCourier ? 'COURIER_ASSIGNED' : undefined,
            deliveryPin: selectedCourier ? Math.floor(100000 + Math.random() * 900000).toString() : undefined,
            deliveryPinEntered: selectedCourier ? false : false,
            // Transit Insurance metadata payload integration
            insurancePolicy,
            insuranceOption: selectedInsuranceOption,
            insurancePremium: getInsurancePremium(getSubtotal(), selectedInsuranceOption),
            insurancePaidBy: insurancePolicy === 'SELLER_COVERS' ? 'SELLER' : (insurancePolicy === 'SHARED' ? 'SHARED' : (selectedInsuranceOption === 'NONE' ? 'NONE' : 'BUYER'))
          })
        });

        if (!response.ok) throw new Error('STK push register failed');
        const newTx = await response.json();
        
        // Auto-complete deposit sequence to capture FUNDS_HELD
        await fetch(`/api/transactions/${newTx.id}/deposit`, { method: 'POST' });
        
        // Move phone state to complete checkout
        setPhoneStep('success');

        // Refresh global state so parent dashboard can map it in escrow timeline
        onTransactionCreated(newTx);
        
      } catch (err) {
        console.error(err);
        setPhoneStep('form');
        alert('STK push network simulation timing overflowed. Please try again.');
      }
    }, 1500);
  };

  // Embed widgets code generation templates
  const buyNowWidgetHTML = `<!-- Buy Safely Buy Now Widget -->
<div style="background: #ffffff; border: 1px solid #e2e8f0; padding: 16px; border-radius: 20px; font-family: system-ui, sans-serif; max-width: 300px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
  <div style="font-size: 10px; font-weight: 900; color: #10b981; margin-bottom: 8px;">🛡️ ESCROW GUARANTEE</div>
  <div style="display: flex; gap: 12px; align-items: center; margin-bottom: 12px;">
    <div style="width: 50px; height: 50px; background: #f1f5f9; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px;">📦</div>
    <div>
      <h4 style="margin: 0; font-size: 13px; font-weight: 800; color: #0f172a;">${itemName}</h4>
      <p style="margin: 2px 0 0 0; font-size: 11px; color: #10b981; font-weight: bold;">KSh ${(parseFloat(price) || 2500).toLocaleString()}</p>
    </div>
  </div>
  <button onclick="window.open('${generatedLink || 'https://buysafely.africa/pay/productID'}', '_blank')" style="width: 100%; background: #10b981; color: #0f172a; border: none; padding: 10px; border-radius: 10px; font-size: 11px; font-weight: 900; cursor: pointer; text-transform: uppercase;">Buy Now</button>
</div>`;

  const smartCartWidgetHTML = `<!-- Buy Safely Smart Cart Widget -->
<div style="background: #ffffff; border: 1px solid #e2e8f0; padding: 18px; border-radius: 24px; font-family: system-ui, sans-serif; max-width: 300px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
  <div style="font-size: 10px; font-weight: 900; color: #10b981; margin-bottom: 8px;">🛡️ ESCROW ACTIVE</div>
  <h4 style="margin: 0 0 4px 0; font-size: 14px; font-weight: bold; color: #0f172a;">${itemName}</h4>
  <p style="margin: 0 0 12px 0; font-size: 12px; font-weight: 900; color: #0f172a;">KSh ${(parseFloat(price) || 2500).toLocaleString()}</p>
  <div style="display: flex; gap: 8px;">
    <button style="flex: 1; background: #f1f5f9; color: #0f172a; border: none; padding: 10px; border-radius: 10px; font-size: 11px; font-weight: bold; cursor: pointer;">Add to Cart</button>
    <button style="flex: 1; background: #10b981; color: #0f172a; border: none; padding: 10px; border-radius: 10px; font-size: 11px; font-weight: bold; cursor: pointer;">Buy Now</button>
  </div>
</div>`;

  const storefrontWidgetHTML = `<!-- Buy Safely Storefront Widget -->
<div style="background: #ffffff; border: 1px solid #e2e8f0; padding: 20px; border-radius: 28px; font-family: system-ui, sans-serif; max-width: 450px; box-shadow: 0 4px 20px rgba(0,0,0,0.05);">
  <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center;">
    <div>
      <h3 style="margin: 0; font-size: 15px; font-weight: 900; color: #0f172a;">${sellerHandle || 'Verified Store'}</h3>
      <span style="font-size: 10px; color: #10b981; font-weight: bold;">✓ Verified Merchant</span>
    </div>
    <a href="/store/${sellerHandle || 'store'}" style="font-size: 11px; color: #4f46e5; text-decoration: none; font-weight: bold;">Visit Store</a>
  </div>
  <div style="display: flex; gap: 12px;">
    <div style="flex: 1; background: #f8fafc; padding: 12px; border-radius: 16px; border: 1px solid #f1f5f9;">
      <h4 style="margin: 0; font-size: 12px; font-weight: bold; color: #0f172a;">${itemName}</h4>
      <p style="margin: 4px 0 8px 0; font-size: 11px; font-weight: bold; color: #0f172a;">KSh ${(parseFloat(price) || 2500).toLocaleString()}</p>
      <button style="width: 100%; background: #10b981; color: #0f172a; border: none; padding: 6px; border-radius: 8px; font-size: 10px; font-weight: bold; cursor: pointer;">Add to Cart</button>
    </div>
  </div>
</div>`;

  const floatingWidgetHTML = `<!-- Buy Safely Floating Website Trigger -->
<div style="position: fixed; bottom: 24px; right: 24px; background: #0f172a; color: white; padding: 14px 20px; border-radius: 50px; display: flex; align-items: center; gap: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); font-family: system-ui, sans-serif; z-index: 9999; border: 1px solid rgba(16, 185, 129, 0.2);">
  <div style="display: flex; align-items: center; gap: 8px;">
    <span style="font-size: 16px;">🛡️</span>
    <div style="display: flex; flex-direction: column;">
      <span style="font-size: 11px; font-weight: 800; color: #ffffff;">Buy Safely</span>
      <span style="font-size: 9px; color: #10b981; font-weight: bold; margin-top: 2px;">Escrow Active</span>
    </div>
  </div>
  <button style="background: #10b981; color: #0f172a; border: none; padding: 8px 14px; border-radius: 30px; font-size: 10.5px; font-weight: 900; cursor: pointer; text-transform: uppercase;">Checkout</button>
</div>`;

  return (
    <div className="space-y-6 my-2 font-sans text-xs">
      
      {/* EXPLANATORY HERO SUB-HEADER */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-950 rounded-3xl p-6 md:p-8 text-white relative overflow-hidden shadow-sm">
        <div className="relative z-10 max-w-3xl space-y-2">
          <span className="text-[10px] font-bold tracking-widest text-emerald-400 bg-emerald-400/10 px-2.5 py-1 rounded-full border border-emerald-400/20 uppercase">
            ⚡ Universal Social Checkout Layer
          </span>
          <h2 className="text-2xl md:text-3xl font-black tracking-tight leading-tight">
            Escrow Commerce Link & Multi-Option Checkout
          </h2>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
            Social commerce sellers do not need to generate new payment links for every variation. Create one link, allow buyers to configure quantity, pick courier/pickup preferences, pay via multiple mobile money networks, and activate the CBK-regulated escrow lockbox instantly.
          </p>
        </div>
        <div className="absolute right-[-10%] bottom-[-20%] opacity-15 aspect-square bg-emerald-500 rounded-full w-96 blur-3xl"></div>
      </div>

      {/* SPLIT WINDOW - BUILDER LEFT, SMARTPHONE INTEGRATION RIGHT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: VENDOR CONTEXT HUB & EMBEDS */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Builder Form Frame */}
          <div className="bg-white rounded-3xl border border-slate-100 p-6 md:p-8 shadow-sm space-y-6">
            
            {/* Tab selection */}
            <div className="flex justify-between items-center border-b border-slate-100 pb-4">
              <h3 className="text-sm font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-500" /> Active Configurations
              </h3>

              <div className="flex bg-slate-100 p-0.5 rounded-xl text-xs font-bold text-slate-500">
                <button 
                  onClick={() => setFormTab('configure')}
                  className={`px-3.5 py-1.5 rounded-lg transition ${formTab === 'configure' ? 'bg-white text-slate-900 shadow-sm' : 'hover:text-slate-900'}`}
                >
                  ⚙️ Listing Config
                </button>
                <button 
                  onClick={() => setFormTab('embeds')}
                  className={`px-3.5 py-1.5 rounded-lg transition ${formTab === 'embeds' ? 'bg-white text-slate-900 shadow-sm' : 'hover:text-slate-900'}`}
                >
                  🔌 Embed Snippets
                </button>
              </div>
            </div>

            {/* TAB 1: CONFIGURE THE SHARED SOCIAL PRODUCT */}
            {formTab === 'configure' && (
              <div className="space-y-6">
                
                {/* ADVANCED AI PRODUCT ACQUISITION ENGINE (PAE) WORKSPACE */}
                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/50 space-y-4">
                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                      <Zap className="w-4 h-4 text-indigo-500 fill-indigo-500" /> AI Product Acquisition Engine (PAE)
                    </span>
                    <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">
                      Adaptive Multi-Layer
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 leading-normal">
                    Paves a fast route for social commerce vendors. Paste links or upload screenshots of your posts (Instagram, WhatsApp catalogs, TikTok showcase etc.) to auto-populate high assurance listings in seconds.
                  </p>

                  {/* LAYER SELECTORS (1-6) */}
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 bg-slate-200/50 p-1 rounded-xl">
                    <button 
                      type="button"
                      onClick={() => { setImportMethod('url'); clearImage(); }}
                      className={`py-2 text-[10px] font-bold rounded-lg transition flex flex-col items-center justify-center gap-1 ${importMethod === 'url' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                      <LinkIcon className="w-3.5 h-3.5" />
                      <span>1. URL Link</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => { setImportMethod('screenshot'); handleLoadSample('screenshot'); }}
                      className={`py-2 text-[10px] font-bold rounded-lg transition flex flex-col items-center justify-center gap-1 ${importMethod === 'screenshot' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>2. Screenshot</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => { setImportMethod('image'); handleLoadSample('image'); }}
                      className={`py-2 text-[10px] font-bold rounded-lg transition flex flex-col items-center justify-center gap-1 ${importMethod === 'image' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      <span>3. Image OCR</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => { setImportMethod('video'); handleLoadSample('video'); }}
                      className={`py-2 text-[10px] font-bold rounded-lg transition flex flex-col items-center justify-center gap-1 ${importMethod === 'video' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>4. Video Frame</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => { setImportMethod('whatsapp'); handleLoadSample('whatsapp'); }}
                      className={`py-2 text-[10px] font-bold rounded-lg transition flex flex-col items-center justify-center gap-1 ${importMethod === 'whatsapp' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>5. WA Catalog</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => setImportMethod('manual')}
                      className={`py-2 text-[10px] font-bold rounded-lg transition flex flex-col items-center justify-center gap-1 ${importMethod === 'manual' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>6. Pure Manual</span>
                    </button>
                  </div>

                  {/* ACTIVE IMPORT METHOD SUB-COMPONENTS */}
                  <div className="space-y-4 pt-1">
                    {importMethod === 'url' && (
                      <div className="space-y-1.5">
                        <label className="block text-[11px] font-bold text-slate-600">Product URL (Instagram / TikTok / Catalog Link)</label>
                        <div className="relative">
                          <Instagram className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                          <input 
                            type="url"
                            value={socialUrl}
                            onChange={(e) => setSocialUrl(e.target.value)}
                            placeholder="e.g. Paste Instagram page or WhatsApp catalog link"
                            className="w-full pl-9 pr-24 py-2.5 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500 text-slate-800 font-mono"
                          />
                          <button 
                            type="button" 
                            onClick={() => setSocialUrl('https://www.tiktok.com/@gikomba_kicks/video/ClassicSneakersPair')}
                            className="absolute right-2 top-1.5 text-[10px] bg-slate-100 hover:bg-slate-200 font-bold px-2.5 py-1.5 rounded-lg border text-slate-700"
                          >
                            Use Demo URL
                          </button>
                        </div>
                      </div>
                    )}

                    {importMethod !== 'url' && importMethod !== 'manual' && (
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-[10px] text-slate-500 font-bold leading-none">
                          <span>
                            {importMethod === 'screenshot' && "📂 Layer 5: Screenshot Import Pipeline (PRIMARY FALLBACK)"}
                            {importMethod === 'image' && "📂 Layer 3: Visual Product Photo Analysis"}
                            {importMethod === 'video' && "📂 Layer 4: Video Frame Analysis (TikTok, Reels, Shorts)"}
                            {importMethod === 'whatsapp' && "📂 Layer 6: WhatsApp Catalog Direct Snapshot"}
                          </span>
                          <span className="text-emerald-500 font-mono">Simulators Preloaded</span>
                        </div>

                        {/* File Upload / Drag space */}
                        <div 
                          onDragEnter={handleDrag}
                          onDragOver={handleDrag}
                          onDragLeave={handleDrag}
                          onDrop={handleDrop}
                          onClick={() => fileInputRef.current?.click()}
                          className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition flex flex-col items-center justify-center ${
                            dragActive ? 'border-indigo-500 bg-indigo-50/20' : 'border-slate-200 bg-white hover:bg-slate-50'
                          }`}
                        >
                          <input 
                            type="file" 
                            ref={fileInputRef} 
                            onChange={handleImageSelect} 
                            accept="image/*" 
                            className="hidden" 
                          />
                          {uploadedImageBase64 ? (
                            <div className="flex items-center gap-3 w-full justify-between text-left">
                              <img src={uploadedImageBase64} alt="Screenshot Data" className="w-14 h-12 object-cover rounded border" />
                              <div className="flex-1">
                                <p className="font-bold text-slate-800 text-xs">Media Extracted to Sandbox Buffer</p>
                                <span className="text-[9px] text-slate-400">Clicking extraction will parse using multimodal OCR coordinates</span>
                              </div>
                              <button 
                                onClick={(e) => { e.stopPropagation(); clearImage(); }} 
                                className="text-xs text-rose-600 font-extrabold hover:underline"
                              >
                                Remove
                              </button>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center gap-1">
                              <ImageIcon className="w-6 h-6 text-indigo-400" />
                              <p className="text-xs font-bold text-slate-700">Drag or click to attach product attachment metadata</p>
                              <span className="text-[9px] text-slate-400">Suports PNG, JPG, or WhatsApp Chat logs</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {importMethod === 'manual' && (
                      <div className="text-[11px] bg-slate-100 p-3 rounded-xl border border-slate-200">
                        👨🔬 <strong>Direct Input Mode:</strong> Skip AI extraction layers. Type details directly into the fields below to construct the CBK-regulated escrow payment.
                      </div>
                    )}

                    {importMethod !== 'manual' && (
                      <button 
                        type="button"
                        onClick={handleAIExtract}
                        disabled={isExtracting || (importMethod === 'url' ? !socialUrl : !uploadedImageBase64)}
                        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                      >
                        {isExtracting ? (
                          <>
                            <Clock className="w-4 h-4 animate-spin text-white" />
                            <span>Gemini AI executing layer checklists...</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300" />
                            <span>Run Multi-Layered Product Extraction Pipeline</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  {extractionAlert && (
                    <div className={`p-3 rounded-xl border flex items-center gap-2 leading-tight ${
                      extractionAlert.type === 'error' ? 'bg-rose-50 border-rose-100 text-rose-700' : 'bg-emerald-50 border-emerald-100 text-emerald-800'
                    }`}>
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>{extractionAlert.text}</span>
                    </div>
                  )}
                </div>

                {/* PAE DYNAMIC WORKSPACE: CONFIDENCE LEVEL FEEDBACK & MANUAL CONFIRMATION LAYER */}
                {paeDetails && importMethod !== 'manual' && (
                  <div className="p-5 bg-indigo-50/20 rounded-2xl border border-indigo-100/60 space-y-4">
                    <div className="flex justify-between items-center flex-wrap gap-2">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
                        🛡️ Layer 7: Manual Confirmation Workspace
                      </span>
                      <span className="text-[9px] text-slate-400 font-bold">
                        AI publishes NEVER silently. Review draft details
                      </span>
                    </div>

                    {/* CONFIDENCE BANNER DECISIONS */}
                    {paeDetails.confidenceLevel === 'HIGH' && (
                      <div className="bg-emerald-50 border border-emerald-200 px-4 py-3.5 rounded-xl flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <strong className="text-emerald-950 block font-bold text-xs">⚡ High Confidence Extract ({paeDetails.confidenceScore}%)</strong>
                          <span className="text-emerald-800/90 text-[10px] leading-relaxed block mt-0.5">
                            All necessary parameters verified via **{paeDetails.primaryLayerUsed}**. Check form inputs and click Generate to publish protected checkout link.
                          </span>
                        </div>
                      </div>
                    )}

                    {paeDetails.confidenceLevel === 'MEDIUM' && (
                      <div className="bg-amber-50 border border-amber-200 px-4 py-3.5 rounded-xl flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <strong className="text-amber-950 block font-bold text-xs">⚠️ Medium Confidence Extract ({paeDetails.confidenceScore}%)</strong>
                          <span className="text-amber-800/90 text-[10px] leading-relaxed block mt-0.5">
                            Some uncertainty identified. We highlighted uncertain fields (glowing gold borders) for easy seller correction to bypass blocks.
                          </span>
                        </div>
                      </div>
                    )}

                    {paeDetails.confidenceLevel === 'LOW' && (
                      <div className="bg-rose-50 border border-rose-200 px-4 py-3.5 rounded-xl flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <strong className="text-rose-950 block font-bold text-xs">🛑 Low Confidence Extract ({paeDetails.confidenceScore}%)</strong>
                          <span className="text-rose-800/90 text-[10px] leading-relaxed block mt-0.5">
                            Confidence score is under threshold. System defaults applied across fields to ensure the product creation flow is NEVER blocked. Fill fields manually below.
                          </span>
                        </div>
                      </div>
                    )}

                    {/* EXTRACTED PROFILE ANALYSIS LOG LINES */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10px] bg-white p-3.5 rounded-xl border">
                      <div>
                        <span className="block text-slate-400 font-bold uppercase tracking-wider text-[8px]">Primary extraction Layer Succeeded</span>
                        <p className="font-extrabold text-slate-800 mt-0.5">{paeDetails.primaryLayerUsed}</p>
                      </div>
                      <div>
                        <span className="block text-slate-400 font-bold uppercase tracking-wider text-[8px]">Verification Trace Layers Applied</span>
                        <p className="font-semibold text-slate-600 mt-0.5">{paeDetails.layersApplied?.join(', ') || 'N/A'}</p>
                      </div>
                      {paeDetails.originalPriceText && (
                        <div className="sm:col-span-2 border-t pt-2 border-slate-100 flex justify-between items-center flex-wrap">
                          <span className="text-slate-400 font-bold uppercase tracking-wider text-[8px]">🎯 Smart Price Detector Match:</span>
                          <span className="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-mono font-bold">
                            Detected {paeDetails.originalPriceText} • Confidence {paeDetails.confidenceScore}%
                          </span>
                        </div>
                      )}
                    </div>

                    {/* AI BENTO SUGGESTION ENGINE PANEL */}
                    {paeDetails.suggestions && (
                      <div className="space-y-3 bg-gradient-to-br from-indigo-950 to-slate-900 text-white p-4.5 rounded-xl">
                        <div className="flex justify-between items-center border-b border-indigo-900 pb-2.5">
                          <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                            💡 AI Product Suggestion Engine
                          </span>
                          <span className="text-[9px] text-slate-400 font-medium">Click any pill to instantly apply to form</span>
                        </div>

                        <div className="space-y-3.5">
                          {/* Alternative name titles selection */}
                          <div className="space-y-1.5">
                            <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-tight">Suggested Product Titles:</span>
                            <div className="flex flex-wrap gap-1.5">
                              {paeDetails.suggestions.productTitle?.map((t: string, idx: number) => (
                                <button 
                                  key={idx}
                                  type="button" 
                                  onClick={() => setItemName(t)} 
                                  className="text-[10px] font-bold bg-white/10 hover:bg-emerald-500 hover:text-white px-2.5 py-1.5 rounded-lg border border-white/5 transition text-left cursor-pointer text-slate-200"
                                >
                                  👉 "{t}"
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Quick Category switcher suggestion */}
                          <div className="space-y-1.5">
                            <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-tight">Suggested Categories:</span>
                            <div className="flex flex-wrap gap-1.5">
                              {paeDetails.suggestions.category?.map((cat: string, idx: number) => (
                                <button 
                                  key={idx}
                                  type="button" 
                                  onClick={() => {
                                    // Map categories securely
                                    if (cat.includes('Fashion')) setPaeDetails({...paeDetails, category: 'Apparel & Fashion'});
                                    else if (cat.includes('Footwear') || cat.includes('Shoes')) setPaeDetails({...paeDetails, category: 'Footwear & Kicks'});
                                  }} 
                                  className="text-[10px] bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-full text-slate-300 font-bold transition cursor-pointer"
                                >
                                  📂 {cat}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Suggested safeguard Tags */}
                          <div className="space-y-1.5">
                            <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-tight">Escrow Safeguard Tags:</span>
                            <div className="flex flex-wrap gap-1.5">
                              {paeDetails.suggestions.tags?.map((tg: string, idx: number) => (
                                <button 
                                  key={idx}
                                  type="button" 
                                  onClick={() => setDescription(description + ` #${tg}`)} 
                                  className="text-[9px] font-mono bg-emerald-500/10 hover:bg-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 transition cursor-pointer"
                                >
                                  #{tg}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Beautiful description rewrite templates block */}
                          {paeDetails.suggestions.description && (
                            <div className="space-y-1.5 border-t border-indigo-900 pt-3">
                              <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-tight">Polished Social Commerce Template:</span>
                              <div className="p-3 bg-white/5 text-slate-200 text-[10px] rounded-lg relative leading-relaxed font-mono">
                                <p className="line-clamp-3">{paeDetails.suggestions.description}</p>
                                <button 
                                  type="button"
                                  onClick={() => setDescription(paeDetails.suggestions.description)}
                                  className="mt-2 text-[9px] font-bold text-emerald-400 hover:text-emerald-300 hover:underline flex items-center gap-1 cursor-pointer bg-transparent border-0"
                                >
                                  ✨ Apply Premium Description with Emojis
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Main product creation settings fields */}
                <form onSubmit={handleGenerateLink} className="space-y-4">
                  <span className="block text-[10px] font-bold text-indigo-600 uppercase tracking-widest border-t border-slate-100 pt-3">Product Particulars</span>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Item Title Input */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1 flex justify-between items-center">
                        <span>Product Title</span>
                        {paeDetails && paeDetails.confidenceLevel !== 'HIGH' && paeDetails.highlightedFields?.includes('productTitle') && (
                          <span className="text-[9px] font-bold text-amber-600 animate-pulse bg-amber-50 px-1 rounded">Amber Level Verify</span>
                        )}
                      </label>
                      <input 
                        type="text" 
                        value={itemName}
                        onChange={(e) => setItemName(e.target.value)}
                        className={`w-full text-xs bg-slate-50 border rounded-xl px-3 py-2.5 outline-none focus:bg-white font-semibold text-slate-800 transition ${
                          paeDetails && paeDetails.confidenceLevel !== 'HIGH' && paeDetails.highlightedFields?.includes('productTitle') 
                            ? 'border-amber-400 ring-2 ring-amber-100 focus:border-amber-500' 
                            : 'border-slate-200 focus:border-indigo-500'
                        }`}
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Product Category</label>
                      <select 
                        value={productCategory}
                        onChange={(e) => setProductCategory(e.target.value as any)}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-500 text-slate-700 font-semibold"
                      >
                        <option value="Electronics & Gadgets">📱 Electronics & Gadgets</option>
                        <option value="Vehicles & Motors">🚗 Vehicles & Motors</option>
                        <option value="Machinery & Tools">⚙️ Machinery & Tools</option>
                        <option value="Furniture & Living">🛋️ Furniture & Living</option>
                        <option value="Apparel & Fashion">👕 Apparel & Fashion</option>
                        <option value="Other Products">📦 Other Products</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Discovery Platform</label>
                      <select 
                        value={platform}
                        onChange={(e) => setPlatform(e.target.value as any)}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-500 text-slate-700 font-semibold"
                      >
                        <option value="Instagram">🟣 Instagram Commerce</option>
                        <option value="WhatsApp">🟢 WhatsApp Catalog</option>
                        <option value="TikTok">⚫ TikTok Showcase</option>
                        <option value="Facebook">🔵 Facebook Marketplace</option>
                        <option value="Telegram">🔵 Telegram Group channel</option>
                      </select>
                    </div>
                  </div>

                  {/* Description input */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 flex justify-between items-center">
                      <span>Product Description</span>
                      {paeDetails && paeDetails.confidenceLevel !== 'HIGH' && paeDetails.highlightedFields?.includes('description') && (
                        <span className="text-[9px] font-bold text-amber-600 animate-pulse bg-amber-50 px-1 rounded">Amber Review</span>
                      )}
                    </label>
                    <textarea 
                      rows={3}
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className={`w-full text-xs bg-slate-50 border rounded-xl px-3 py-2.5 outline-none focus:bg-white text-slate-600 resize-none font-medium leading-relaxed transition ${
                        paeDetails && paeDetails.confidenceLevel !== 'HIGH' && paeDetails.highlightedFields?.includes('description') 
                          ? 'border-amber-400 ring-2 ring-amber-100 focus:border-amber-500' 
                          : 'border-slate-200 focus:border-indigo-500'
                      }`}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {/* Price Input */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1 flex justify-between items-center">
                        <span>Price (Ksh)</span>
                        {paeDetails && paeDetails.confidenceLevel !== 'HIGH' && paeDetails.highlightedFields?.includes('price') && (
                          <span className="text-[9px] font-bold text-amber-600 bg-amber-50 px-1 rounded animate-pulse">Assign Value</span>
                        )}
                      </label>
                      <input 
                        type="number" 
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className={`w-full text-xs bg-slate-50 border rounded-xl px-3 py-2.5 outline-none focus:bg-white font-mono font-bold text-slate-800 transition ${
                          paeDetails && paeDetails.confidenceLevel !== 'HIGH' && paeDetails.highlightedFields?.includes('price') 
                            ? 'border-amber-400 ring-2 ring-amber-100 focus:border-amber-500 animate-pulse' 
                            : 'border-slate-200 focus:border-indigo-500'
                        }`}
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Inventory Stock</label>
                      <input 
                        type="number" 
                        value={stock}
                        onChange={(e) => setStock(e.target.value)}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-500 focus:bg-white font-bold text-slate-800"
                        min="1"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Est. Ship-out Time</label>
                      <select 
                        value={daysToDeliver}
                        onChange={(e) => setDaysToDeliver(parseInt(e.target.value))}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-500 text-slate-700 font-semibold"
                      >
                        <option value={1}>24 Hours Dispatch</option>
                        <option value={2}>2 Days Courier</option>
                        <option value={3}>3 Days Fargo/Boda</option>
                        <option value={7}>7 Days (CBK Max Limit)</option>
                      </select>
                    </div>
                  </div>

                  {/* SHIPPING COST CONFIGURATION ENGINE */}
                  <div className="border border-slate-100 p-4 rounded-2xl bg-indigo-50/30 space-y-3">
                    <span className="block text-[10px] font-bold text-indigo-700 uppercase tracking-wider flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5" /> Configure Shipping Rates (Ksh)
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 mb-1">Courier (Flat-rate)</label>
                        <input 
                          type="number" 
                          value={courierFee}
                          onChange={(e) => setCourierFee(e.target.value)}
                          className="w-full text-xs bg-white border border-slate-200 rounded-xl px-3 py-2.5 font-bold font-mono outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 mb-1">Pickup (Store)</label>
                        <input 
                          type="number" 
                          value={pickupFee}
                          onChange={(e) => setPickupFee(e.target.value)}
                          className="w-full text-xs bg-white border border-slate-200 rounded-xl px-3 py-2.5 font-bold font-mono outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 mb-1">Boda / Self Delivery</label>
                        <input 
                          type="number" 
                          value={sellerDeliveryFee}
                          onChange={(e) => setSellerDeliveryFee(e.target.value)}
                          className="w-full text-xs bg-white border border-slate-200 rounded-xl px-3 py-2.5 font-bold font-mono outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* BUY SAFELY VERIFIED PRODUCT INSPECTION PROGRAM */}
                  <div className="border border-indigo-200 p-5 rounded-2xl bg-indigo-50/20 space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="block text-[11px] font-black text-indigo-950 uppercase tracking-wider flex items-center gap-1.5">
                        🔬 Buy Safely Product Inspection Program
                      </span>
                      <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        verificationStatus === 'UNVERIFIED' ? 'bg-amber-100 text-amber-800' :
                        verificationStatus === 'AUDITOR_ASSIGNED' ? 'bg-amber-500 text-white animate-pulse' :
                        verificationStatus === 'INSPECTION_COMPLETED' ? 'bg-blue-600 text-white animate-pulse' :
                        'bg-emerald-600 text-white'
                      }`}>
                        {verificationStatus.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <p className="text-[10px] text-slate-500 leading-normal">
                      Connect an independent Trust Auditor (Picker) to inspect and certify your products before sale. Displays the verified badge on social storefronts, lowering counterfeit disputes, increasing buyer conversions, and fast-tracking escrow payouts. Recommended for vehicles, machinery, electronics, and furniture.
                    </p>

                    {/* EXPIRATION GUIDE */}
                    <div className="bg-white/80 rounded-xl p-2.5 border border-slate-100 grid grid-cols-2 gap-2 text-[10px] text-slate-600">
                      <div>
                        <span className="font-bold text-slate-700 block">Category Expiry Policy:</span>
                        <span className="font-semibold text-indigo-600">Electronics: 30D | Furniture: 60D | Vehicles: 14D | Machinery: 30D | Fashion: 30D</span>
                      </div>
                      <div className="text-right border-l border-slate-100 pl-2">
                        <span className="font-bold text-slate-700 block text-right">Current Category Exp:</span>
                        <span className="font-bold text-slate-900">{CATEGORY_DETAILS[productCategory]?.validity || 30} Days validity</span>
                      </div>
                    </div>

                    {verificationStatus === 'UNVERIFIED' && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 mb-1">Select Inspection Tier:</label>
                            <select
                              value={verificationTier}
                              onChange={(e) => setVerificationTier(e.target.value as any)}
                              className="w-full text-xs bg-white border border-slate-200 rounded-xl px-3 py-2 outline-none font-semibold text-slate-700"
                            >
                              <option value="STANDARD">Standard Inspection (Ksh {CATEGORY_DETAILS[productCategory]?.standard})</option>
                              <option value="PRIORITY">Priority Inspection (Ksh {CATEGORY_DETAILS[productCategory]?.priority})</option>
                              <option value="PREMIUM">Premium Inspection (Ksh {CATEGORY_DETAILS[productCategory]?.premium})</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-500 mb-1">Assigned Trust Auditor:</label>
                            <div className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 flex items-center gap-1.55">
                              🕵️ Picker Alex (Trust Rating: 99%)
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleRegisterAndRequest}
                          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs py-2.5 rounded-xl transition shadow cursor-pointer text-center border-0"
                        >
                          Request Independent Product Verification (Setup Audit)
                        </button>
                      </div>
                    )}

                    {/* AUDITOR ASSIGNED TIMELINE & ACTIONS */}
                    {verificationStatus === 'AUDITOR_ASSIGNED' && (
                      <div className="p-3.5 bg-amber-50/50 border border-amber-200 rounded-xl space-y-3">
                        <div className="flex gap-2.5 items-start">
                          <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                          <div className="text-[10px] text-slate-600 space-y-0.5">
                            <span className="font-bold text-slate-900 block">Trust Auditor Dispatched to Seller Location</span>
                            <p>Auditor Alex (CBD Representative) is carrying out the verified audit scheduling. He will physically check dimensions, seller ID/location, take high-res media, and run operational diagnostic tests.</p>
                          </div>
                        </div>

                        {/* Interactive Auditor Checklist Simulation block */}
                        <div className="bg-white p-3 rounded-lg border border-amber-100 space-y-3">
                          <strong className="block text-[10px] text-slate-700">✍️ Simulated Physical Inspection Diagnostic Checklist:</strong>
                          <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-600">
                            <div>
                              <span className="block font-bold text-slate-500 mb-0.5 font-mono text-[9px]">Item Condition:</span>
                              <select 
                                value={auditCondition}
                                onChange={(e) => setAuditCondition(e.target.value as any)}
                                className="bg-slate-50 border border-slate-200 rounded p-1 w-full text-[10px]"
                              >
                                <option value="Excellent">🌟 Excellent (Flawless)</option>
                                <option value="Good">👍 Good (Light wear)</option>
                                <option value="Fair">😐 Fair (Average)</option>
                                <option value="Poor">🚨 Poor (Damaged)</option>
                              </select>
                            </div>
                            <div>
                              <span className="block font-bold text-slate-500 mb-0.5 font-mono text-[9px]">Tested Serial Number:</span>
                              <input 
                                type="text"
                                value={auditSerial}
                                onChange={(e) => setAuditSerial(e.target.value)}
                                className="bg-slate-50 border border-slate-200 rounded p-1 w-full text-[10px]"
                              />
                            </div>
                          </div>

                          <div className="flex items-center gap-2 text-[10px] text-slate-700 font-mono">
                            <input 
                              type="checkbox"
                              checked={auditFunctional}
                              onChange={(e) => setAuditFunctional(e.target.checked)}
                              id="functional-audit-pass"
                            />
                            <label htmlFor="functional-audit-pass" className="font-semibold cursor-pointer">Functional Diagnostic Tests PASS</label>
                          </div>

                          <div>
                            <span className="block font-bold text-slate-500 mb-0.5 text-[9px] uppercase font-mono">Auditor Notes & Visual Media Logs:</span>
                            <textarea 
                              value={auditNotes}
                              onChange={(e) => setAuditNotes(e.target.value)}
                              rows={2}
                              className="w-full bg-slate-50 border border-slate-200 rounded p-1.5 text-[9px] font-mono"
                            />
                          </div>

                          <button 
                            type="button"
                            onClick={handleAuditorInspectSubmit}
                            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-extrabold py-2 rounded-lg transition border-0 cursor-pointer text-center"
                          >
                            🕵️ Record Physical Verification & Submit Report
                          </button>
                        </div>
                      </div>
                    )}

                    {/* REPORT SUBMITTED, REVIEW PENDING */}
                    {verificationStatus === 'INSPECTION_COMPLETED' && (
                      <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl space-y-3 text-[10px] text-slate-600">
                        <div className="flex gap-2.5 items-start">
                          <FileText className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                          <div className="space-y-0.5">
                            <span className="font-bold text-slate-900 block font-mono">PHYSICAL REPORT SUBMITTED SUCCESSFULLY</span>
                            <p>Independent Picker report received. Product is waiting for instant CBK platform vetting. The checklist passed and verification recommendation is locked on-chain.</p>
                          </div>
                        </div>

                        {/* Summary of what picker filed */}
                        <div className="bg-white p-2.5 rounded-lg border border-blue-100 font-mono text-[9px] space-y-1">
                          <p><span className="text-slate-400">Condition:</span> <span className="font-bold text-slate-800">{auditCondition}</span></p>
                          <p><span className="text-slate-400">Serial No:</span> <span className="font-bold text-slate-800">{auditSerial}</span></p>
                          <p><span className="text-slate-400">Functional Test:</span> <span className="font-bold text-emerald-700">{auditFunctional ? 'PASS' : 'FAIL'}</span></p>
                          <p><span className="text-slate-400">Notes:</span> <span>"{auditNotes}"</span></p>
                        </div>

                        <button
                          type="button"
                          onClick={handleInstantSystemApprove}
                          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold py-2 rounded-lg transition border-0 cursor-pointer"
                        >
                          🎓 Instant Review, Approve & Issue Verification Badge
                        </button>
                      </div>
                    )}

                    {/* GOLD BADGE ACTIVE WITH TOOLTIP */}
                    {verificationStatus === 'VERIFIED' && (
                      <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 text-[10px] text-slate-600">
                        <div className="flex gap-2 items-center">
                          <CheckCircle className="w-4 h-4 text-emerald-600 fill-emerald-100 shrink-0" />
                          <div>
                            <span className="font-bold text-emerald-950 block">BUY SAFELY VERIFIED BADGE ACTIVE! 🛡️</span>
                            <p className="text-[8px] text-slate-500 font-medium font-mono">Inspected on {new Date(verificationAt || Date.now()).toLocaleDateString()} • Expires: {new Date(verificationExpiresAt || (Date.now() + 30*24*3600*1000)).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <p className="text-[10px] font-medium leading-relaxed">
                          Your social checkout link has been upgraded with the verified badge. It ranks higher, enjoys optimized conversions, and demonstrates physical availability of the checked items to risk models.
                        </p>
                        <div className="bg-white p-2 rounded border border-emerald-100 text-[9px] italic text-slate-500 font-mono">
                          "Independently inspected and verified by a Buy Safely Trust Auditor."
                        </div>
                      </div>
                    )}

                    {/* STORE PLANS (BULK PACKS) */}
                    <div className="border-t border-slate-100 pt-3 space-y-2.5">
                      <span className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                        🏬 Store Verification Subscription Plans (Bulk Merchants)
                      </span>
                      <p className="text-[9px] text-slate-500">
                        Sellers running high volume social commerce can subscribe to monthly package plans containing automatic, pre-paid, priority auditor bookings:
                      </p>

                      <div className="grid grid-cols-3 gap-2 text-[10px]">
                        <button
                          type="button"
                          onClick={() => handleSubscribeBulkPlan('BASIC')}
                          className={`p-2 rounded-xl text-center border-2 transition cursor-pointer ${
                            bulkPlanSubscribed === 'BASIC' ? 'border-indigo-600 bg-indigo-50/20' : 'border-slate-150 bg-white hover:border-slate-200'
                          }`}
                        >
                          <strong className="block text-slate-800 text-[10px]">Basic (10)</strong>
                          <span className="text-[9px] font-mono block text-slate-500">Ksh 3,999/mo</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleSubscribeBulkPlan('GROWTH')}
                          className={`p-2 rounded-xl text-center border-2 transition cursor-pointer ${
                            bulkPlanSubscribed === 'GROWTH' ? 'border-indigo-600 bg-indigo-50/20' : 'border-slate-150 bg-white hover:border-slate-200'
                          }`}
                        >
                          <strong className="block text-slate-800 text-[10px]">Growth (50)</strong>
                          <span className="text-[9px] font-mono block text-slate-500">Ksh 14,999/mo</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleSubscribeBulkPlan('ENTERPRISE')}
                          className={`p-2 rounded-xl text-center border-2 transition cursor-pointer ${
                            bulkPlanSubscribed === 'ENTERPRISE' ? 'border-indigo-600 bg-indigo-50/20' : 'border-slate-150 bg-white hover:border-slate-200'
                          }`}
                        >
                          <strong className="block text-slate-800 text-[10px]">Enterprise (∞)</strong>
                          <span className="text-[9px] font-mono block text-slate-500">Ksh 29,999/mo</span>
                        </button>
                      </div>

                      {showBulkPlanSuccess && (
                        <div className="p-2 text-center bg-emerald-50 text-emerald-800 border border-emerald-100 text-[10px] rounded-xl font-bold font-mono">
                          ✓ Subscribed successfully! High conversion status unlocked.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* TRANSIT & CARGO INSURANCE CONFIGURATION */}
                  <div className="border border-slate-150 p-5 rounded-2xl bg-white space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="block text-[11px] font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                        🛡️ Transit & Cargo Insurance Settings
                      </span>
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 font-extrabold px-2 py-0.5 rounded-full uppercase">
                        Safe Buy Insured
                      </span>
                    </div>

                    <p className="text-[10px] text-slate-500 leading-normal">
                      Establish the shipping protection policy for this social checkout link. Insure shipments against theft, damage, or loss in transit underwritten by Jubilee and Britam Insurance.
                    </p>

                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 mb-1">Transit Protection Policy Mode:</label>
                      <select
                        value={insurancePolicy}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          setInsurancePolicy(val);
                          // Force logical default chosen values inside Checkout Simulator based on Selected settings!
                          if (val === 'NONE' || val === 'SELLER_COVERS') {
                            setSelectedInsuranceOption('NONE');
                          } else {
                            setSelectedInsuranceOption('BASIC');
                          }
                        }}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none font-semibold text-slate-700 font-sans"
                      >
                        <option value="NONE">No Insurance (Deactivated)</option>
                        <option value="BUYER_CHOOSES">Buyer May Choose Insurance (Optional)</option>
                        <option value="SELLER_COVERS">Seller Covers Insurance (Free for Buyer)</option>
                        <option value="MANDATORY">Insurance Mandatory (Required for Escrow Release)</option>
                        <option value="SHARED">Shared Cost (50/50 Split between Buyer & Seller)</option>
                      </select>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-[10px] text-slate-650">
                      <strong className="text-slate-850 block text-[9.5px] font-bold">💡 Jubilee/Britam Underwriter Premium Tiers:</strong>
                      <ul className="list-disc leading-relaxed pl-4 space-y-0.5 text-[9px] text-slate-450">
                        <li>Up to Ksh 5,000: <strong className="text-slate-700 font-mono">1.5% premium rate</strong></li>
                        <li>Ksh 5,001–20,000: <strong className="text-slate-700 font-mono">1.2% premium rate</strong></li>
                        <li>Ksh 20,001–100,000: <strong className="text-slate-700 font-mono">1.0% premium rate</strong></li>
                        <li>Above Ksh 100,000: <strong className="text-slate-700 font-mono">0.8% premium rate</strong></li>
                        <li>Minimum absolute underwriter cover rate is <strong className="text-indigo-600 font-mono">Ksh 40</strong> per parcel.</li>
                      </ul>
                    </div>
                  </div>

                  {showMpesaPrompt && (
                    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                      <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-slate-100 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-200">
                        <div className="text-center space-y-1">
                          <span className="text-3xl">📲</span>
                          <h3 className="font-black text-slate-900 tracking-tight text-base">Safaricom M-Pesa STK Push</h3>
                          <p className="text-[10px] text-slate-500">Physical Pre-Sale Inspection Escrow Fee Payout Authorization</p>
                        </div>

                        <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-2 text-[10px] text-slate-600">
                          <div className="flex justify-between font-mono">
                            <span>Verification Fee:</span>
                            <strong className="text-slate-900">Ksh {CATEGORY_DETAILS[productCategory][verificationTier.toLowerCase() as 'standard' | 'priority' | 'premium'].toLocaleString()} Relator</strong>
                          </div>
                          <div className="flex justify-between font-mono text-[9px] text-indigo-600 border-t border-slate-100 pt-2 font-bold font-mono">
                            <span>Service Tier:</span>
                            <span>{verificationTier} EXPEDITION</span>
                          </div>
                        </div>

                        {/* REVENUE BREAKDOWN - AUDITABILITY SYNC (Hides commission details from buyers/sellers) */}
                        <div className="p-3 bg-indigo-50/50 rounded-2xl border border-indigo-100 space-y-1.5 text-[9px] text-slate-600">
                          <strong className="block text-[10px] text-indigo-950 font-extrabold font-mono uppercase">📊 Internal Financial Allocation Sync:</strong>
                          <p className="text-[8px] text-slate-400 font-medium font-sans">To maintain privacy, the following revenue distribution split is restricted to the platform ledger account logs:</p>
                          <div className="space-y-1 font-mono text-[9px]">
                            <div className="flex justify-between">
                              <span className="text-slate-500">Auditor Delivery Compensation (75%):</span>
                              <span className="font-bold text-slate-800">Ksh {(CATEGORY_DETAILS[productCategory][verificationTier.toLowerCase() as 'standard' | 'priority' | 'premium'] * 0.75).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500 font-semibold text-indigo-800">Buy Safely Network Allocation (20%):</span>
                              <span className="font-bold text-indigo-600">Ksh {(CATEGORY_DETAILS[productCategory][verificationTier.toLowerCase() as 'standard' | 'priority' | 'premium'] * 0.20).toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-500">M-Pesa API Settlement PSP (5%):</span>
                              <span className="font-bold text-slate-800">Ksh {(CATEGORY_DETAILS[productCategory][verificationTier.toLowerCase() as 'standard' | 'priority' | 'premium'] * 0.05).toLocaleString()}</span>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[10px] font-bold text-slate-500">Enter Payment Number:</label>
                          <input 
                            type="text"
                            value={mpesaPaymentNumber}
                            onChange={(e) => setMpesaPaymentNumber(e.target.value)}
                            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 font-bold font-mono text-center outline-none focus:border-indigo-500 focus:bg-white"
                          />
                        </div>

                        {isVerifyingPayment ? (
                          <div className="flex items-center justify-center gap-2 text-indigo-600 text-xs font-black py-2.5">
                            <span className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></span>
                            Authorizing Secure Escrow Ledgers...
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 gap-3 pt-2">
                            <button
                              type="button"
                              onClick={() => setShowMpesaPrompt(false)}
                              className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs py-2.5 rounded-xl cursor-pointer border-0"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={handleConfirmMpesaPayment}
                              className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs py-2.5 rounded-xl cursor-pointer border-0"
                            >
                              Authorize & Pay
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-dashed border-slate-100 pt-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Payout Mobile Money M-Pesa Number</label>
                      <input 
                        type="text" 
                        value={sellerPhone}
                        onChange={(e) => setSellerPhone(e.target.value)}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-500 focus:bg-white font-mono font-bold text-slate-800"
                        placeholder="254798765432"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Public Seller Store Handle</label>
                      <input 
                        type="text" 
                        value={sellerHandle}
                        onChange={(e) => setSellerHandle(e.target.value)}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-500 focus:bg-white font-bold text-slate-800"
                        required
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs py-3.5 rounded-xl transition shadow active:scale-[0.98] cursor-pointer mt-4 flex items-center justify-center gap-2"
                  >
                    <LinkIcon className="w-4 h-4 text-emerald-400" />
                    <span>Generate Universal Buyer Escrow Link</span>
                  </button>
                </form>

                {scamRisk !== null && (
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mt-2 space-y-1">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold text-slate-700">AI Safety Score assessment:</span>
                      <span className={`font-mono text-[9px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded ${scamRisk > 30 ? 'bg-rose-50 text-rose-700' : 'bg-emerald-50 text-emerald-700'}`}>
                        {scamRisk > 30 ? 'Moderate Flag' : 'High Trust Verified'}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 leading-normal">{scamComments}</p>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: EMBEDDED BUTTONS & INTEGRATION PLUGINS */}
            {formTab === 'embeds' && (
              <div className="space-y-6">
                
                {/* CONFIGURATOR INTRO */}
                <div className="bg-gradient-to-r from-emerald-950 to-slate-900 border border-emerald-500/20 rounded-2xl p-4 text-white space-y-1">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span className="text-[10px] font-mono tracking-wider text-emerald-400 uppercase font-black">HIGH-CONVERSION ASSET LAYER</span>
                  </div>
                  <h4 className="text-xs uppercase font-extrabold text-white">Buy Safely Smart Escrow Widget Customizer</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                    Enable trust natively across any channel. Customize layout designs, configure visual thumbnail extractions, preview social media behaviors, and test the integrated Escrow Checkout Popup.
                  </p>
                </div>

                {/* THE CONFIGURATION CONSOLE & PREVIEW SPLIT */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
                  
                  {/* LEFT CONSOLE: SETTINGS (xl:col-span-7) */}
                  <div className="xl:col-span-7 space-y-6">
                    
                    {/* SECTION 1: EMBED OPTIONS */}
                    <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm space-y-3">
                      <div className="flex items-center gap-1.5 border-b border-slate-100 pb-2">
                        <span className="bg-emerald-50 text-emerald-800 text-[9px] font-black px-1.5 py-0.5 rounded">STEP 1</span>
                        <h4 className="text-xs uppercase font-extrabold text-slate-800">Choose Seller Embed Option</h4>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                        {/* Option A: Buy Now Widget */}
                        <div 
                          onClick={() => setEmbedOption('A')}
                          className={`border rounded-xl p-3 cursor-pointer transition-all flex flex-col justify-between ${embedOption === 'A' ? 'border-emerald-500 bg-emerald-50/20 shadow-xs' : 'border-slate-200 hover:bg-slate-50'}`}
                        >
                          <div>
                            <span className="font-extrabold text-slate-850 block">Buy Now Widget</span>
                            <span className="text-[9px] text-slate-500">Single-product quick checkout</span>
                          </div>
                          <div className="mt-2 text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-center font-mono">
                            ⚡ Direct Buy
                          </div>
                        </div>

                        {/* Option B: Smart Cart Widget */}
                        <div 
                          onClick={() => setEmbedOption('B')}
                          className={`border rounded-xl p-3 cursor-pointer transition-all flex flex-col justify-between ${embedOption === 'B' ? 'border-emerald-500 bg-emerald-50/20 shadow-xs' : 'border-slate-200 hover:bg-slate-50'}`}
                        >
                          <div>
                            <div className="flex justify-between items-center">
                              <span className="font-extrabold text-slate-850 block">Smart Cart</span>
                              <span className="text-[8px] bg-emerald-100 text-emerald-800 font-bold px-1 rounded">BEST</span>
                            </div>
                            <span className="text-[9px] text-slate-500">Add to cart + Escrow cart active</span>
                          </div>
                          <div className="mt-2 text-[10px] bg-slate-150 text-slate-700 px-2 py-0.5 rounded text-center font-mono font-bold">
                            Shopping Cart ✓
                          </div>
                        </div>

                        {/* Option C: Storefront Widget */}
                        <div 
                          onClick={() => setEmbedOption('C')}
                          className={`border rounded-xl p-3 cursor-pointer transition-all flex flex-col justify-between ${embedOption === 'C' ? 'border-emerald-500 bg-emerald-50/20 shadow-xs' : 'border-slate-200 hover:bg-slate-50'}`}
                        >
                          <div>
                            <span className="font-extrabold text-slate-850 block">Storefront</span>
                            <span className="text-[9px] text-slate-500">Multi-product merchant grid</span>
                          </div>
                          <div className="mt-2 text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-center font-mono">
                            🛍️ Visit Store
                          </div>
                        </div>

                        {/* Option D: Floating Buy Safely Widget */}
                        <div 
                          onClick={() => setEmbedOption('D')}
                          className={`border rounded-xl p-3 cursor-pointer transition-all flex flex-col justify-between ${embedOption === 'D' ? 'border-emerald-500 bg-emerald-50/20 shadow-xs' : 'border-slate-200 hover:bg-slate-50'}`}
                        >
                          <div>
                            <span className="font-extrabold text-slate-850 block">Floating Widget</span>
                            <span className="text-[9px] text-slate-500">Persistent checkout launcher</span>
                          </div>
                          <div className="mt-2 text-[10px] bg-slate-800 text-white px-2 py-0.5 rounded text-center font-mono">
                            Corner Bubble 💬
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* SECTION 2: PRODUCT THUMBNAIL SOURCES */}
                    <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm space-y-4">
                      <div className="flex items-center gap-1.5 border-b border-slate-100 pb-2">
                        <span className="bg-emerald-50 text-emerald-800 text-[9px] font-black px-1.5 py-0.5 rounded">STEP 2</span>
                        <h4 className="text-xs uppercase font-extrabold text-slate-800">Product Thumbnail Sources</h4>
                      </div>

                      <div className="flex bg-slate-100 p-1 rounded-xl gap-1">
                        <button 
                          type="button"
                          onClick={() => setThumbnailSource('UPLOAD')}
                          className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition ${thumbnailSource === 'UPLOAD' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                        >
                          Method 1: Manual Upload
                        </button>
                        <button 
                          type="button"
                          onClick={() => setThumbnailSource('WEBSITE')}
                          className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition ${thumbnailSource === 'WEBSITE' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                        >
                          Method 2: Web Extract
                        </button>
                        <button 
                          type="button"
                          onClick={() => setThumbnailSource('SOCIAL')}
                          className={`flex-1 py-1.5 text-[10px] font-bold rounded-lg transition ${thumbnailSource === 'SOCIAL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
                        >
                          Method 3: Social AI Extract
                        </button>
                      </div>

                      {/* METHOD 1 VIEW: UPLOAD */}
                      {thumbnailSource === 'UPLOAD' && (
                        <div className="space-y-3">
                          <p className="text-[11px] text-slate-500 leading-normal">
                            Provide high-assurance visual proof of inventory. Upload primary thumbnails and add secondary angles for multi-layer inspection.
                          </p>
                          
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-16 rounded-xl border-2 border-dashed flex flex-col items-center justify-center text-slate-400 hover:border-slate-300 hover:bg-slate-50 transition cursor-pointer relative overflow-hidden" onClick={() => fileInputRef.current?.click()}>
                              {uploadedImageBase64 ? (
                                <img src={uploadedImageBase64} alt="main" className="w-full h-full object-cover" />
                              ) : (
                                <>
                                  <ImageIcon className="w-4 h-4 text-slate-400" />
                                  <span className="text-[8px] mt-1">Main</span>
                                </>
                              )}
                            </div>

                            {/* Additional images list */}
                            {[1, 2, 3].map((idx) => (
                              <div 
                                key={idx}
                                onClick={() => {
                                  const demoImg = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" style="background:%23eceff1"><text x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-size="10" fill="%23455a64">Angle ${idx}</text></svg>`;
                                  if (additionalImages.includes(demoImg)) {
                                    setAdditionalImages(additionalImages.filter(i => i !== demoImg));
                                  } else {
                                    setAdditionalImages([...additionalImages, demoImg]);
                                  }
                                }}
                                className={`w-12 h-12 rounded-lg border flex flex-col items-center justify-center transition cursor-pointer relative overflow-hidden ${additionalImages.length >= idx ? 'border-emerald-400 bg-emerald-50/20' : 'border-slate-200 hover:bg-slate-50'}`}
                              >
                                {additionalImages.length >= idx ? (
                                  <img src={additionalImages[idx - 1]} alt="angle" className="w-full h-full object-cover" />
                                ) : (
                                  <>
                                    <Plus className="w-3.5 h-3.5 text-slate-400" />
                                    <span className="text-[7.5px] text-slate-400">Angle {idx}</span>
                                  </>
                                )}
                              </div>
                            ))}
                          </div>
                          <span className="block text-[10px] text-slate-400">Click placeholder slots above to toggle simulated alternate inspection angles.</span>
                        </div>
                      )}

                      {/* METHOD 2 VIEW: WEBSITE EXTRACTION */}
                      {thumbnailSource === 'WEBSITE' && (
                        <div className="space-y-3.5 text-xs">
                          <p className="text-[11px] text-slate-500 leading-normal">
                            Connect your web storefront. Buy Safely will automatically extract metadata tags, OpenGraph objects, price models, and primary product assets.
                          </p>
                          <div className="space-y-2">
                            <div className="relative">
                              <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                              <input 
                                type="text"
                                value={websiteUrl}
                                onChange={(e) => setWebsiteUrl(e.target.value)}
                                className="w-full pl-9 pr-24 py-2 bg-slate-50 border rounded-xl font-mono text-slate-800 outline-none focus:border-emerald-500 text-[11px]"
                                placeholder="e.g. shop.brand.co.ke/product-101"
                              />
                              <button 
                                type="button"
                                onClick={() => {
                                  setIsExtractingWeb(true);
                                  setTimeout(() => {
                                    setItemName("Original Samsung Galaxy S25 Ultra");
                                    setPrice("95000");
                                    setDescription("Directly extracted from merchant shop catalog. Active CBK capital escrow locked. 100% genuine guaranteed.");
                                    setUploadedImageBase64("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%23020617'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%2310b981'>S25 Ultra Pro</text></svg>");
                                    setIsExtractingWeb(false);
                                    alert("Website Product Data Extracted Successfully! Title, price, and thumbnail mapped.");
                                  }, 1500);
                                }}
                                disabled={isExtractingWeb}
                                className="absolute right-1 top-1 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black px-3 py-1 rounded-lg text-[9.5px] uppercase cursor-pointer"
                              >
                                {isExtractingWeb ? 'Extracting...' : 'Extract'}
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* METHOD 3 VIEW: SOCIAL AI EXTRACTION */}
                      {thumbnailSource === 'SOCIAL' && (
                        <div className="space-y-3.5 text-xs">
                          <p className="text-[11px] text-slate-500 leading-normal">
                            Paste links to Instagram Reels, Facebook posts, or TikTok challenges. Our Social Media AI parser extracts caption hashtags, currency listings, and post images.
                          </p>
                          <div className="space-y-2">
                            <div className="relative">
                              <Instagram className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                              <input 
                                type="text"
                                value={socialUrlWidget}
                                onChange={(e) => setSocialUrlWidget(e.target.value)}
                                className="w-full pl-9 pr-24 py-2 bg-slate-50 border rounded-xl font-mono text-slate-800 outline-none focus:border-emerald-500 text-[11px]"
                                placeholder="instagram.com/p/C7W2be_sy1g"
                              />
                              <button 
                                type="button"
                                onClick={() => {
                                  setIsExtractingSocial(true);
                                  setTimeout(() => {
                                    setItemName("Classic Heavy-Grade Distressed Leather Bomber");
                                    setPrice("6500");
                                    setDescription("Retro aviator jacket sourced via Instagram post OCR. Distressed heavy leather chassis, verified brass hardware.");
                                    setUploadedImageBase64("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%23311b92'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%2380deea'>Retro Leather Bomber</text></svg>");
                                    setIsExtractingSocial(false);
                                    alert("Social Media AI Extraction complete! Post comments and price tag parsed.");
                                  }, 1500);
                                }}
                                disabled={isExtractingSocial}
                                className="absolute right-1 top-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-3 py-1 rounded-lg text-[9.5px] uppercase cursor-pointer"
                              >
                                {isExtractingSocial ? 'Analyzing...' : 'AI Extract'}
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* SECTION 3: SOCIAL MEDIA ENVIRONMENT SPECIFIC BEHAVIOUR */}
                    <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm space-y-3">
                      <div className="flex items-center gap-1.5 border-b border-slate-100 pb-2">
                        <span className="bg-emerald-50 text-emerald-800 text-[9px] font-black px-1.5 py-0.5 rounded">STEP 3</span>
                        <h4 className="text-xs uppercase font-extrabold text-slate-800">Social Platform Integrations</h4>
                      </div>

                      <div className="grid grid-cols-4 gap-1">
                        {['whatsapp', 'instagram', 'facebook', 'website'].map((plat) => (
                          <button
                            key={plat}
                            type="button"
                            onClick={() => setSocialSpecificBehavior(plat as any)}
                            className={`py-1.5 rounded-lg text-[9.5px] font-extrabold uppercase border transition ${socialSpecificBehavior === plat ? 'border-emerald-500 bg-emerald-50 text-emerald-950 font-black' : 'border-slate-200 text-slate-500 hover:bg-slate-50'}`}
                          >
                            {plat}
                          </button>
                        ))}
                      </div>

                      {/* Dynamic information details card */}
                      <div className="bg-slate-50 border border-slate-150 p-3 rounded-xl text-[11px] leading-relaxed text-slate-600">
                        {socialSpecificBehavior === 'whatsapp' && (
                          <p>
                            🟢 <strong>WhatsApp Catalog Strategy:</strong> Native embedded browser widgets are sandboxed in WA chat. Buy Safely bypasses this by auto-generating a ultra-lightweight, 0.4s fast mobile checkout page optimized for mobile 3G.
                          </p>
                        )}
                        {socialSpecificBehavior === 'instagram' && (
                          <p>
                            📸 <strong>Instagram In-App WebView:</strong> Clicking the secure anchor swipe-up triggers the Buy Safely lightweight checkout directly inside the Instagram integrated browser overlay, retaining the buyer in-platform.
                          </p>
                        )}
                        {socialSpecificBehavior === 'facebook' && (
                          <p>
                            🔵 <strong>Facebook Marketplace Portal:</strong> Employs an ultra-secure overlay modal. It validates seller reputation on Marketplace feeds before showing payment options to minimize advance payment scams.
                          </p>
                        )}
                        {socialSpecificBehavior === 'website' && (
                          <p>
                            💻 <strong>Merchant Website Embedded Mode:</strong> Fully responsive embedded layout that conforms to 100% container width. Renders perfectly as a bento trust anchor next to custom buy buttons.
                          </p>
                        )}
                      </div>
                    </div>

                  </div>

                  {/* RIGHT PANEL: LIVE WIDGET PREVIEW (xl:col-span-5) */}
                  <div className="xl:col-span-5 space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Smart Widget Live Preview</span>
                      
                      {/* PREVIEW DEVICE/MODE TABS */}
                      <div className="flex bg-slate-150 p-0.5 rounded-lg text-[9px] font-bold text-slate-600 gap-0.5">
                        <button 
                          type="button"
                          onClick={() => setPreviewDevice('desktop')}
                          className={`px-2 py-1 rounded transition ${previewDevice === 'desktop' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-950'}`}
                        >
                          💻 Desktop
                        </button>
                        <button 
                          type="button"
                          onClick={() => setPreviewDevice('mobile')}
                          className={`px-2 py-1 rounded transition ${previewDevice === 'mobile' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-950'}`}
                        >
                          📱 Mobile
                        </button>
                        <button 
                          type="button"
                          onClick={() => {
                            // Pre-populate if empty to ensure review works
                            if (widgetCart.length === 0) {
                              setWidgetCart([{
                                product: {
                                  id: 'M-PROD-01',
                                  title: itemName || 'Classic Oversized Leather Bomber',
                                  price: parseFloat(price) || 2500,
                                  image: uploadedImageBase64 || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%23311b92'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%2380deea'>Bomber Jacket</text></svg>",
                                  sellerHandle: sellerHandle || '@trendy_thrifts_ke',
                                  category: productCategory || 'Apparel & Fashion'
                                },
                                quantity: 1,
                                insured: true
                              }]);
                            }
                            setPreviewDevice('popup');
                            setIsWidgetCheckoutOpen(true);
                            setWidgetStep('cart');
                          }}
                          className={`px-2 py-1 rounded transition ${previewDevice === 'popup' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-950'}`}
                        >
                          🛡️ Checkout
                        </button>
                        <button 
                          type="button"
                          onClick={() => {
                            if (widgetCart.length === 0) {
                              setWidgetCart([{
                                product: {
                                  id: 'M-PROD-01',
                                  title: itemName || 'Classic Oversized Leather Bomber',
                                  price: parseFloat(price) || 2500,
                                  image: uploadedImageBase64 || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%23311b92'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%2380deea'>Bomber Jacket</text></svg>",
                                  sellerHandle: sellerHandle || '@trendy_thrifts_ke',
                                  category: productCategory || 'Apparel & Fashion'
                                },
                                quantity: 1,
                                insured: true
                              }]);
                            }
                            setPreviewDevice('cart');
                          }}
                          className={`px-2 py-1 rounded transition ${previewDevice === 'cart' ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-950'}`}
                        >
                          🛒 Floating Cart
                        </button>
                      </div>
                    </div>

                    {/* PREVIEW CONTAINER */}
                    <div className={`border-2 border-dashed border-slate-200 rounded-3xl relative overflow-hidden bg-slate-100 flex flex-col justify-between ${
                      previewDevice === 'mobile' ? 'max-w-[340px] mx-auto aspect-[9/16] min-h-[500px]' : 'w-full min-h-[460px]'
                    }`}>
                      
                      {/* MOCK BROWSER HEADER */}
                      <div className="bg-white border-b border-slate-200 px-4 py-2 flex items-center gap-2 shrink-0">
                        <div className="flex gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-400 block"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 block"></span>
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 block"></span>
                        </div>
                        <div className="bg-slate-100 rounded-md py-1 px-3 text-[9px] text-slate-400 flex-1 font-mono text-center select-none truncate">
                          buysafely.africa/store/{sellerHandle.replace('@', '')}
                        </div>
                      </div>

                      {/* DEMO PRODUCTS DEFINITION */}
                      {(() => {
                        const mainProduct = {
                          id: 'M-PROD-01',
                          title: itemName || 'Classic Oversized Leather Bomber',
                          price: parseFloat(price) || 2500,
                          image: uploadedImageBase64 || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%23311b92'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%2380deea'>Bomber Jacket</text></svg>",
                          sellerHandle: sellerHandle || '@trendy_thrifts_ke',
                          category: productCategory || 'Apparel & Fashion'
                        };
                        
                        const secondaryProduct = {
                          id: 'M-PROD-02',
                          title: `${itemName} Care Cream & Protector`,
                          price: Math.max(350, Math.round((parseFloat(price) || 2500) * 0.25)),
                          image: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%231e293b'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%2310b981'>Shield Balm</text></svg>",
                          sellerHandle: sellerHandle || '@trendy_thrifts_ke',
                          category: productCategory || 'Apparel & Fashion'
                        };

                        const tertiaryProduct = {
                          id: 'M-PROD-03',
                          title: 'Custom Vintage Metal Hanger',
                          price: Math.max(250, Math.round((parseFloat(price) || 2500) * 0.15)),
                          image: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%230f172a'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%23f59e0b'>Metal Hanger</text></svg>",
                          sellerHandle: sellerHandle || '@trendy_thrifts_ke',
                          category: productCategory || 'Apparel & Fashion'
                        };

                        const conflictProduct = {
                          id: 'M-CONFLICT-01',
                          title: 'S25 Ultra Carbon Case',
                          price: 4200,
                          image: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%23311b92'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%23ff9100'>Carbon Case</text></svg>",
                          sellerHandle: '@abc_electronics',
                          category: 'Electronics & Gadgets'
                        };

                        // Cart summary stats
                        const cartCount = widgetCart.reduce((sum, item) => sum + item.quantity, 0);
                        const cartSubtotal = widgetCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

                        return (
                          <div className="flex-1 overflow-y-auto p-4 space-y-4 flex flex-col relative justify-center bg-slate-50 min-h-[360px]">
                            
                            {/* MERCHANT STORECONTEXT DISPLAY (Verified merchant details) */}
                            {embedOption !== 'A' && (
                              <div className="bg-white border border-slate-200/60 p-3 rounded-2xl shadow-xs flex items-center justify-between select-none shrink-0 mb-1">
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div className="w-8 h-8 rounded-full bg-emerald-50 border border-emerald-500/25 flex items-center justify-center font-black text-emerald-800 text-xs">
                                    {sellerHandle.slice(1, 3).toUpperCase()}
                                  </div>
                                  <div className="min-w-0">
                                    <h4 className="text-[11px] font-black text-slate-900 truncate leading-tight uppercase flex items-center gap-1">
                                      {sellerHandle.replace('@', '')} Store
                                      <span className="text-[9px] text-emerald-600">✓</span>
                                    </h4>
                                    <span className="text-[9px] text-slate-400 block leading-none">✓ Verified Escrow Merchant</span>
                                  </div>
                                </div>
                                <button 
                                  type="button"
                                  onClick={() => setEmbedOption('C')}
                                  className="text-[9.5px] font-black text-indigo-600 hover:text-indigo-800 uppercase px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 rounded-lg shrink-0 cursor-pointer transition"
                                >
                                  Visit Store
                                </button>
                              </div>
                            )}

                            {/* PREVIEW STAGE 1: INLINE CHEKOUT DIALOG POPUP PREVIEW */}
                            {previewDevice === 'popup' && (
                              <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full p-4 text-white text-left shadow-lg select-all">
                                <span className="text-[8px] bg-indigo-600 font-mono tracking-widest px-1.5 py-0.5 rounded uppercase font-black mb-2 inline-block">Interactive Preview Window</span>
                                <h4 className="text-[11px] font-bold text-slate-300"> Escrow Checkout Modal is active. See the interactive modal below.</h4>
                                <button 
                                  onClick={() => setIsWidgetCheckoutOpen(true)}
                                  className="mt-3 w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-[10px] uppercase py-2 rounded-xl text-center"
                                >
                                  Trigger Modal Focus
                                </button>
                              </div>
                            )}

                            {/* PREVIEW STAGE 2: INLINE FLOATING CART PREVIEW */}
                            {previewDevice === 'cart' && (
                              <div className="bg-white border border-slate-200 rounded-2xl p-4 text-slate-900 text-left shadow-lg space-y-4">
                                <div className="flex justify-between items-center border-b pb-2">
                                  <h4 className="text-xs font-black uppercase text-slate-800 flex items-center gap-1">
                                    <ShoppingCart className="w-3.5 h-3.5 text-indigo-600" /> Active Shopping Cart
                                  </h4>
                                  <span className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded font-mono font-bold">{cartCount} items</span>
                                </div>
                                
                                {widgetCart.length === 0 ? (
                                  <p className="text-[10px] text-slate-400 text-center py-6">Your cart is currently empty. Click Add to Cart below to add items!</p>
                                ) : (
                                  <div className="space-y-2.5 max-h-48 overflow-y-auto">
                                    {widgetCart.map((item, index) => (
                                      <div key={index} className="flex gap-2.5 items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200/50">
                                        <div className="flex gap-2 items-center min-w-0">
                                          <div className="w-8 h-8 rounded-lg bg-slate-200 overflow-hidden border shrink-0">
                                            <img src={item.product.image} className="w-full h-full object-cover" alt="" />
                                          </div>
                                          <div className="min-w-0">
                                            <h5 className="text-[10px] font-bold text-slate-900 truncate leading-tight">{item.product.title}</h5>
                                            <span className="text-[9px] text-slate-500 font-mono">KSh {item.product.price.toLocaleString()} x {item.quantity}</span>
                                          </div>
                                        </div>
                                        <button 
                                          type="button"
                                          onClick={() => {
                                            setWidgetCart(widgetCart.filter((_, i) => i !== index));
                                          }}
                                          className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                                        >
                                          <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    ))}
                                    
                                    <div className="border-t border-slate-200 pt-2.5 flex justify-between items-center font-mono text-[10px] text-slate-800">
                                      <span>Running Subtotal:</span>
                                      <strong className="text-sm text-slate-950">KSh {cartSubtotal.toLocaleString()}</strong>
                                    </div>
                                    
                                    <button 
                                      type="button"
                                      onClick={() => {
                                        setIsWidgetCheckoutOpen(true);
                                        setWidgetStep('cart');
                                      }}
                                      className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase text-[10px] py-2 rounded-xl text-center shadow-xs cursor-pointer"
                                    >
                                      Proceed to Checkout Safely
                                    </button>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* WIDGET DISPLAY OPTION A: BUY NOW WIDGET (Single-product only) */}
                            {previewDevice !== 'popup' && previewDevice !== 'cart' && embedOption === 'A' && (
                              <div className="w-full max-w-sm bg-white border border-slate-200/60 p-4 rounded-2xl shadow-md space-y-3.5 text-center flex flex-col justify-between">
                                <div className="space-y-1">
                                  <span className="text-[8px] bg-slate-100 text-slate-500 font-mono tracking-widest font-black uppercase px-2 py-0.5 rounded inline-block">Buy Now Widget</span>
                                  <h4 className="text-xs font-black text-slate-950 uppercase line-clamp-1">{mainProduct.title}</h4>
                                  <p className="text-[9px] text-slate-400 font-mono">KSh {mainProduct.price.toLocaleString()}</p>
                                </div>
                                <button 
                                  type="button"
                                  onClick={() => handleBuyNow(mainProduct)}
                                  className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase text-[10px] py-2.5 rounded-xl transition shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                                >
                                  🛡️ Buy Safely Escrow
                                </button>
                              </div>
                            )}

                            {/* WIDGET DISPLAY OPTION B: SMART CART WIDGET (Add to Cart enabled) */}
                            {previewDevice !== 'popup' && previewDevice !== 'cart' && embedOption === 'B' && (
                              <div className="w-full max-w-xs bg-white border border-slate-200/60 rounded-2xl p-4 shadow-md space-y-3.5 flex flex-col justify-between mx-auto">
                                <div className="flex justify-between items-start gap-2.5">
                                  <div className="min-w-0">
                                    <span className="bg-emerald-100 text-emerald-850 font-black text-[8px] rounded px-1.5 py-0.5 tracking-wider uppercase inline-block mb-1">🛡️ Escrow Active</span>
                                    <h4 className="text-xs font-black text-slate-900 line-clamp-2 uppercase leading-snug">{mainProduct.title}</h4>
                                    <span className="text-xs font-black text-emerald-600 font-mono mt-1 block">KSh {mainProduct.price.toLocaleString()}</span>
                                  </div>
                                  <div className="w-12 h-12 bg-slate-100 rounded-xl overflow-hidden shrink-0 border border-slate-200/50 flex items-center justify-center">
                                    <img src={mainProduct.image} alt="product" className="w-full h-full object-cover" />
                                  </div>
                                </div>

                                <div className="grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
                                  <button 
                                    type="button"
                                    onClick={() => {
                                      handleAddToCart(mainProduct);
                                      alert("✓ Added classic bomber to cart!");
                                    }}
                                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-[9.5px] uppercase py-2 px-2.5 rounded-xl transition cursor-pointer text-center"
                                  >
                                    Add to Cart
                                  </button>
                                  <button 
                                    type="button"
                                    onClick={() => handleBuyNow(mainProduct)}
                                    className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-[9.5px] uppercase py-2 px-2.5 rounded-xl transition cursor-pointer text-center shadow-xs"
                                  >
                                    Buy Now
                                  </button>
                                </div>
                              </div>
                            )}

                            {/* WIDGET DISPLAY OPTION C: STOREFRONT WIDGET (Merchant products grid) */}
                            {previewDevice !== 'popup' && previewDevice !== 'cart' && embedOption === 'C' && (
                              <div className="w-full bg-white border border-slate-200/60 rounded-2xl p-3.5 shadow-md space-y-3">
                                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                                  <span className="text-[9.5px] font-black text-slate-900 uppercase">Available Store Catalog</span>
                                  <span className="text-[8.5px] text-slate-400">3 Products online</span>
                                </div>

                                <div className="grid grid-cols-1 gap-2.5">
                                  {[mainProduct, secondaryProduct, tertiaryProduct].map((prod) => (
                                    <div key={prod.id} className="flex gap-2.5 items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200/50 hover:bg-slate-100/60 transition">
                                      <div className="flex gap-2 items-center min-w-0">
                                        <div className="w-9 h-9 bg-white rounded-lg overflow-hidden border shrink-0 flex items-center justify-center">
                                          <img src={prod.image} alt="" className="w-full h-full object-cover" />
                                        </div>
                                        <div className="min-w-0">
                                          <h5 className="text-[10.5px] font-extrabold text-slate-900 truncate leading-tight uppercase">{prod.title}</h5>
                                          <span className="text-[10px] text-emerald-600 font-mono font-bold">KSh {prod.price.toLocaleString()}</span>
                                        </div>
                                      </div>
                                      <div className="flex gap-1 shrink-0">
                                        <button 
                                          type="button"
                                          onClick={() => {
                                            handleAddToCart(prod);
                                            alert(`✓ Added ${prod.title} to cart!`);
                                          }}
                                          className="bg-white hover:bg-indigo-50 border border-slate-200 text-slate-700 hover:text-indigo-600 text-[8.5px] font-black px-2 py-1 rounded-md cursor-pointer uppercase transition"
                                        >
                                          + Cart
                                        </button>
                                        <button 
                                          type="button"
                                          onClick={() => handleBuyNow(prod)}
                                          className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-[8.5px] font-black px-2 py-1 rounded-md cursor-pointer uppercase transition"
                                        >
                                          Buy
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>

                                {/* MISMATCH CONFLICT SIMULATOR TRIGER */}
                                <div className="border-t border-slate-100 pt-2.5 text-center">
                                  <button 
                                    type="button"
                                    onClick={() => handleAddToCart(conflictProduct)}
                                    className="bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-mono text-[8px] font-black uppercase px-3 py-1 rounded-full inline-block cursor-pointer transition"
                                  >
                                    ⚠️ Test Multi-Merchant Cart Conflict
                                  </button>
                                </div>
                              </div>
                            )}

                            {/* WIDGET DISPLAY OPTION D: FLOATING BUY SAFELY WIDGET (Persistentsecure checkout button) */}
                            {previewDevice !== 'popup' && previewDevice !== 'cart' && embedOption === 'D' && (
                              <div className="w-full p-4 text-center space-y-6">
                                <div className="bg-white border border-slate-200 p-4 rounded-xl text-slate-500 text-[10px] leading-relaxed max-w-xs mx-auto">
                                  👇 A persistent secure floating widget sits anchored on the bottom corner of your page, reflecting active items instantly.
                                </div>
                                <div className="flex justify-center">
                                  <div 
                                    onClick={() => {
                                      setIsWidgetCheckoutOpen(true);
                                      setWidgetStep('cart');
                                    }}
                                    className="bg-slate-900 border border-slate-800 hover:bg-slate-950 text-white p-3 px-5 rounded-full flex items-center gap-2.5 shadow-lg select-none cursor-pointer hover:scale-105 active:scale-95 transition-all"
                                  >
                                    <span className="text-xs">🛡️</span>
                                    <div className="text-left font-sans">
                                      <span className="text-[10px] block font-black uppercase text-emerald-400 tracking-wider">Buy Safely Escrow</span>
                                      <span className="text-[9px] text-slate-300 block">{cartCount} items • KSh {cartSubtotal.toLocaleString()}</span>
                                    </div>
                                    {cartCount > 0 && (
                                      <span className="bg-emerald-500 text-slate-950 text-[9px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center">
                                        {cartCount}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* PERSISTENT FLOATING CART DRAWER/BUBBLE (Fulfills floating cart widget requirement) */}
                            {widgetCart.length > 0 && previewDevice !== 'cart' && previewDevice !== 'popup' && (
                              <div className="absolute bottom-3 right-3 left-3 bg-slate-950 text-white rounded-2xl p-2.5 px-4 shadow-2xl border border-emerald-500/30 flex items-center justify-between select-none animate-slide-up shrink-0 z-10">
                                <div className="flex items-center gap-2">
                                  <div className="relative">
                                    <ShoppingCart className="w-4 h-4 text-emerald-400" />
                                    <span className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-slate-950 text-[7.5px] font-black w-3.5 h-3.5 rounded-full flex items-center justify-center">
                                      {cartCount}
                                    </span>
                                  </div>
                                  <div>
                                    <span className="text-[9px] text-slate-400 block leading-none font-bold uppercase">Escrow Shopping Cart</span>
                                    <span className="text-[10.5px] font-black text-white font-mono leading-none mt-1 block">KSh {cartSubtotal.toLocaleString()}</span>
                                  </div>
                                </div>
                                <div className="flex gap-1.5">
                                  <button 
                                    type="button"
                                    onClick={() => setPreviewDevice('cart')}
                                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-[9px] font-extrabold uppercase px-2 py-1.5 rounded-lg cursor-pointer"
                                  >
                                    View Cart
                                  </button>
                                  <button 
                                    type="button"
                                    onClick={() => {
                                      setIsWidgetCheckoutOpen(true);
                                      setWidgetStep('cart');
                                    }}
                                    className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-[9px] font-black uppercase px-3 py-1.5 rounded-lg cursor-pointer shadow-sm"
                                  >
                                    Checkout
                                  </button>
                                </div>
                              </div>
                            )}

                            {/* MERCHANT MISMATCH CONFLICT PROMPT (Requirement 6) */}
                            {cartConflictPromptOpen && (
                              <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 z-30 font-sans">
                                <div className="bg-white border border-slate-200 rounded-2xl p-4 max-w-xs text-left shadow-2xl space-y-3.5">
                                  <div className="flex gap-1.5 items-center text-amber-600 font-extrabold">
                                    <AlertTriangle className="w-4.5 h-4.5" />
                                    <h4 className="text-xs uppercase font-black tracking-tight">Merchant Mismatch Conflict</h4>
                                  </div>
                                  <p className="text-[10.5px] text-slate-600 leading-normal">
                                    You currently have items from another merchant in your shopping cart.
                                    Escrow contracts are split per merchant to ensure secure independent fulfillment.
                                  </p>
                                  <div className="flex flex-col gap-1.5 text-[9.5px] font-black uppercase">
                                    <button 
                                      type="button"
                                      onClick={() => {
                                        if (pendingConflictItem) {
                                          setWidgetCart([{ product: pendingConflictItem, quantity: 1, insured: true }]);
                                        }
                                        setPendingConflictItem(null);
                                        setCartConflictPromptOpen(false);
                                        alert("✓ Cleared previous items. Started a fresh cart.");
                                      }}
                                      className="w-full bg-slate-900 hover:bg-slate-950 text-white py-2 rounded-xl text-center cursor-pointer"
                                    >
                                      1. Start a New Cart
                                    </button>
                                    <button 
                                      type="button"
                                      onClick={() => {
                                        setPendingConflictItem(null);
                                        setCartConflictPromptOpen(false);
                                      }}
                                      className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 py-2 rounded-xl text-center cursor-pointer"
                                    >
                                      2. Continue with Existing Cart
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}

                          </div>
                        );
                      })()}

                    </div>

                    <p className="text-[10px] text-center text-slate-400">
                      💡 Click the buttons in the live preview to test shopping carts, combined shipping, and the fully multi-step secure escrow checkout flow.
                    </p>
                  </div>

                </div>

                {/* THE ESCROW CHECKOUT POPUP MODAL (Completely matching 6-stage checkout flow) */}
                {isWidgetCheckoutOpen && (
                  <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in font-sans">
                    <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col justify-between max-h-[90vh]">
                      
                      {/* MODAL GLOBAL HEADER */}
                      <div className="bg-slate-950 p-4 border-b border-slate-800 flex justify-between items-center select-none shrink-0">
                        <div className="flex items-center gap-1.5">
                          <span className="bg-emerald-500 text-slate-950 text-[8px] font-black font-mono px-1.5 py-0.5 rounded tracking-widest uppercase">SECURED ESCROW</span>
                          <h3 className="text-xs uppercase font-extrabold text-white">CBK Licensed Checkout</h3>
                        </div>
                        <button 
                          type="button" 
                          onClick={() => setIsWidgetCheckoutOpen(false)}
                          className="text-slate-400 hover:text-white font-extrabold text-sm cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>

                      {/* POPUP STAGE 1: CART REVIEW */}
                      {widgetStep === 'cart' && (
                        <div className="flex flex-col flex-1 overflow-y-auto">
                          <div className="bg-slate-950 border-b border-slate-850 p-3 flex justify-between items-center text-[10px] font-mono text-slate-400 uppercase">
                            <span>STEP 1 of 6</span>
                            <span className="text-emerald-400 font-bold">Shopping Cart Review</span>
                          </div>

                          <div className="p-4 space-y-4 text-left">
                            {widgetCart.length === 0 ? (
                              <div className="text-center py-12 space-y-2">
                                <p className="text-xs text-slate-400">Your shopping cart is empty.</p>
                                <button 
                                  type="button"
                                  onClick={() => {
                                    setWidgetCart([{
                                      product: {
                                        id: 'M-PROD-01',
                                        title: itemName || 'Classic Oversized Leather Bomber',
                                        price: parseFloat(price) || 2500,
                                        image: uploadedImageBase64 || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' style='background:%23311b92'><text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-weight='bold' font-size='10' fill='%2380deea'>Bomber Jacket</text></svg>",
                                        sellerHandle: sellerHandle || '@trendy_thrifts_ke',
                                        category: productCategory || 'Apparel & Fashion'
                                      },
                                      quantity: 1,
                                      insured: true
                                    }]);
                                  }}
                                  className="text-[10px] font-bold text-emerald-400 uppercase hover:underline"
                                >
                                  Load Configured Product
                                </button>
                              </div>
                            ) : (
                              <div className="space-y-3">
                                <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Products in Escrow Basket</label>
                                
                                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                                  {widgetCart.map((item, index) => (
                                    <div key={index} className="bg-slate-950 border border-slate-850 p-3 rounded-2xl flex gap-3 items-center justify-between">
                                      <div className="flex gap-2.5 items-center min-w-0">
                                        <div className="w-11 h-11 bg-slate-900 rounded-lg overflow-hidden border shrink-0 border-slate-800 flex items-center justify-center">
                                          <img src={item.product.image} className="w-full h-full object-cover" alt="" />
                                        </div>
                                        <div className="min-w-0">
                                          <h5 className="text-[10.5px] font-black text-white uppercase truncate">{item.product.title}</h5>
                                          <span className="font-mono text-[10px] text-emerald-400 block font-bold mt-0.5">KSh {item.product.price.toLocaleString()}</span>
                                        </div>
                                      </div>
                                      
                                      <div className="flex items-center gap-2 shrink-0">
                                        <div className="flex items-center bg-slate-900 rounded-lg p-0.5 border border-slate-800">
                                          <button 
                                            type="button"
                                            onClick={() => {
                                              if (item.quantity > 1) {
                                                setWidgetCart(widgetCart.map((it, i) => i === index ? { ...it, quantity: it.quantity - 1 } : it));
                                              } else {
                                                setWidgetCart(widgetCart.filter((_, i) => i !== index));
                                              }
                                            }}
                                            className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold flex items-center justify-center text-xs"
                                          >
                                            -
                                          </button>
                                          <span className="font-mono text-xs font-black text-white w-5 text-center">{item.quantity}</span>
                                          <button 
                                            type="button"
                                            onClick={() => {
                                              setWidgetCart(widgetCart.map((it, i) => i === index ? { ...it, quantity: it.quantity + 1 } : it));
                                            }}
                                            className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold flex items-center justify-center text-xs"
                                          >
                                            +
                                          </button>
                                        </div>
                                        
                                        <button 
                                          type="button"
                                          onClick={() => {
                                            setWidgetCart(widgetCart.filter((_, i) => i !== index));
                                          }}
                                          className="text-rose-500 hover:text-rose-400 p-1 shrink-0 cursor-pointer"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </button>
                                      </div>
                                    </div>
                                  ))}
                                </div>

                                {/* Running Cost breakdown */}
                                <div className="border-t border-slate-850 pt-3.5 space-y-1.5 select-none font-mono text-[10px] text-slate-400">
                                  <div className="flex justify-between">
                                    <span>Items Subtotal:</span>
                                    <strong className="text-white">KSh {widgetCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0).toLocaleString()}</strong>
                                  </div>
                                  <div className="flex justify-between">
                                    <span>Shipping (Combined):</span>
                                    <span className="text-emerald-400 font-bold">Estimated in Step 3</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span>Service Fee (1%):</span>
                                    <span className="text-emerald-400 font-bold">Estimated in Step 5</span>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="p-4 bg-slate-950 border-t border-slate-800">
                            <button
                              type="button"
                              onClick={() => {
                                if (widgetCart.length === 0) {
                                  alert("Your cart is empty. Please add items.");
                                  return;
                                }
                                setWidgetStep('recipient');
                              }}
                              className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-2.5 rounded-xl transition text-xs cursor-pointer shadow-md"
                            >
                              Proceed to Recipient Details
                            </button>
                          </div>
                        </div>
                      )}

                      {/* POPUP STAGE 2: RECIPIENT DETAILS */}
                      {widgetStep === 'recipient' && (
                        <div className="flex flex-col flex-1 overflow-y-auto">
                          <div className="bg-slate-950 border-b border-slate-850 p-3 flex justify-between items-center text-[10px] font-mono text-slate-400 uppercase">
                            <span>STEP 2 of 6</span>
                            <span className="text-emerald-400 font-bold">Recipient & Shipping Details</span>
                          </div>

                          <div className="p-4 space-y-4 text-left">
                            <div className="space-y-1.5">
                              <label className="text-[10px] text-slate-400 font-bold uppercase block">Recipient Full Name</label>
                              <input 
                                type="text"
                                value={widgetBuyerName}
                                onChange={(e) => setWidgetBuyerName(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-sans outline-none focus:border-emerald-500 text-xs"
                                placeholder="Recipient name"
                              />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-[10px] text-slate-400 font-bold uppercase block">Recipient Phone Number</label>
                              <input 
                                type="tel"
                                value={widgetBuyerPhone}
                                onChange={(e) => setWidgetBuyerPhone(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono outline-none focus:border-emerald-500 text-xs"
                                placeholder="Recipient Safaricom Phone"
                              />
                            </div>

                            <div className="space-y-1.5">
                              <label className="text-[10px] text-slate-400 font-bold uppercase block">Physical Shipping Address</label>
                              <textarea 
                                rows={2}
                                value={widgetRecipientAddress}
                                onChange={(e) => setWidgetRecipientAddress(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-sans outline-none focus:border-emerald-500 text-xs resize-none"
                                placeholder="E.g. Apartment A2, Wood Avenue, Kilimani, Nairobi"
                              />
                            </div>
                          </div>

                          <div className="p-4 bg-slate-950 border-t border-slate-800 grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setWidgetStep('cart')}
                              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                            >
                              Back
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (!widgetBuyerName.trim() || !widgetBuyerPhone.trim() || !widgetRecipientAddress.trim()) {
                                  alert("Please fill in all recipient details.");
                                  return;
                                }
                                setWidgetStep('delivery');
                              }}
                              className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                            >
                              Next: Courier
                            </button>
                          </div>
                        </div>
                      )}

                      {/* POPUP STAGE 3: DELIVERY SELECTION */}
                      {widgetStep === 'delivery' && (
                        <div className="flex flex-col flex-1 overflow-y-auto">
                          <div className="bg-slate-950 border-b border-slate-850 p-3 flex justify-between items-center text-[10px] font-mono text-slate-400 uppercase">
                            <span>STEP 3 of 6</span>
                            <span className="text-emerald-400 font-bold">Delivery Selection</span>
                          </div>

                          <div className="p-4 space-y-4 text-left">
                            <div className="bg-emerald-950/40 border border-emerald-500/20 p-3 rounded-2xl flex items-center gap-2 text-[10.5px] text-slate-200">
                              <span className="text-emerald-400 text-xs">✓</span>
                              <span><strong>Combined Shipping Active:</strong> Items from the same merchant are consolidated into a single package and shipped together under one delivery charge.</span>
                            </div>

                            <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Select Consolidated Shipping Courier</label>
                            
                            <div className="space-y-2.5">
                              {[
                                { id: 'Courier', name: '🚚 Fargo Courier Secure', fee: 300, desc: 'CBK escrow integrated transit carrier. Takes 12-24 hours.' },
                                { id: 'Rider', name: '🏍️ Express Bike Dispatcher', fee: 150, desc: 'Instant motorcycle delivery within Nairobi. Takes 2-4 hours.' },
                                { id: 'Pickup', name: '🏪 CBD Warehouse Pickup', fee: 0, desc: 'Self-collect at our secure locker point. Takes 0 KSh.' }
                              ].map((m) => (
                                <div 
                                  key={m.id}
                                  onClick={() => setWidgetDeliveryMethod(m.id as any)}
                                  className={`p-3.5 border rounded-2xl cursor-pointer transition flex items-center justify-between ${
                                    widgetDeliveryMethod === m.id ? 'border-emerald-500 bg-emerald-950/20' : 'border-slate-800 hover:bg-slate-850'
                                  }`}
                                >
                                  <div className="space-y-0.5">
                                    <span className="text-xs font-black text-white block">{m.name}</span>
                                    <span className="text-[9.5px] text-slate-400 block leading-normal">{m.desc}</span>
                                  </div>
                                  <span className="font-mono text-xs font-black text-emerald-400 shrink-0">KSh {m.fee}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="p-4 bg-slate-950 border-t border-slate-800 grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setWidgetStep('recipient')}
                              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                            >
                              Back
                            </button>
                            <button
                              type="button"
                              onClick={() => setWidgetStep('insurance')}
                              className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                            >
                              Next: Insurance
                            </button>
                          </div>
                        </div>
                      )}

                      {/* POPUP STAGE 4: INSURANCE SELECTION */}
                      {widgetStep === 'insurance' && (
                        <div className="flex flex-col flex-1 overflow-y-auto">
                          <div className="bg-slate-950 border-b border-slate-850 p-3 flex justify-between items-center text-[10px] font-mono text-slate-400 uppercase">
                            <span>STEP 4 of 6</span>
                            <span className="text-emerald-400 font-bold">Transit Escrow Insurance</span>
                          </div>

                          <div className="p-4 space-y-4 text-left">
                            <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl flex items-start gap-3.5 justify-between select-none">
                              <div className="space-y-1">
                                <span className="text-[9px] bg-indigo-950 text-indigo-400 font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">Premium Capital Guard</span>
                                <h4 className="text-xs font-black text-white uppercase flex items-center gap-1 mt-1">
                                  🛡️ Trans-Route Safety Insurance Shield
                                </h4>
                                <p className="text-[10px] text-slate-400 leading-normal block">
                                  Full capital reimbursement in case of courier road accidents, theft, package damage, or shipping disruptions. Activating insurance triggers priority transit auditing.
                                </p>
                              </div>
                              <input 
                                type="checkbox"
                                checked={widgetInsurance}
                                onChange={(e) => setWidgetInsurance(e.target.checked)}
                                className="w-5 h-5 accent-emerald-500 shrink-0 cursor-pointer mt-1"
                              />
                            </div>

                            <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl text-[10px] leading-relaxed text-slate-400 font-mono">
                              <span className="text-white block uppercase font-bold text-[9px] mb-1">Coverage Breakdown</span>
                              <p>✓ Cargo Transit Accidents: 100% covered</p>
                              <p>✓ Courier Handshake Audit: Activated</p>
                              <p>✓ Premium Fee: KSh {widgetInsurance ? '120 flat' : '0'}</p>
                            </div>
                          </div>

                          <div className="p-4 bg-slate-950 border-t border-slate-800 grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setWidgetStep('delivery')}
                              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                            >
                              Back
                            </button>
                            <button
                              type="button"
                              onClick={() => setWidgetStep('breakdown')}
                              className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                            >
                              Next: Summary
                            </button>
                          </div>
                        </div>
                      )}

                      {/* POPUP STAGE 5: COST BREAKDOWN & M-PESA PHONE ENTRY */}
                      {widgetStep === 'breakdown' && (
                        <div className="flex flex-col flex-1 overflow-y-auto">
                          <div className="bg-slate-950 border-b border-slate-850 p-3 flex justify-between items-center text-[10px] font-mono text-slate-400 uppercase">
                            <span>STEP 5 of 6</span>
                            <span className="text-emerald-400 font-bold">Consolidated Review</span>
                          </div>

                          {(() => {
                            const subtotal = widgetCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
                            const shipFee = widgetDeliveryMethod === 'Courier' ? 300 : widgetDeliveryMethod === 'Rider' ? 150 : 0;
                            const insPrem = widgetInsurance ? 120 : 0;
                            const platformFee = Math.max(25, Math.round(subtotal * 0.01));
                            const finalTotal = subtotal + shipFee + insPrem + platformFee;

                            return (
                              <div className="p-4 space-y-4 text-left">
                                <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Invoice Receipt Breakdown</label>
                                
                                <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-850 font-mono text-[10.5px] text-slate-400 space-y-2 select-none">
                                  <div className="flex justify-between border-b border-slate-850 pb-2 text-white">
                                    <span>Escrow Basket ({widgetCart.reduce((sum, item) => sum + item.quantity, 0)} items)</span>
                                    <span>KSh {subtotal.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span>Consolidated Shipping:</span>
                                    <span>KSh {shipFee.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span>Transit Insurance Premium:</span>
                                    <span>KSh {insPrem.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span>CBK Service Clearing Fee (1%):</span>
                                    <span>KSh {platformFee.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between border-t border-slate-850 pt-2 text-emerald-400 font-black text-sm">
                                    <span>Total Secured Amount:</span>
                                    <span>KSh {finalTotal.toLocaleString()}</span>
                                  </div>
                                </div>

                                <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-2xl space-y-1.5">
                                  <label className="text-[10px] text-slate-400 font-bold uppercase block">Buyer Safaricom Phone (M-Pesa Escrow)</label>
                                  <input 
                                    type="tel"
                                    value={widgetBuyerPhone}
                                    onChange={(e) => setWidgetBuyerPhone(e.target.value)}
                                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono outline-none focus:border-emerald-500 text-xs"
                                    placeholder="0712345678"
                                  />
                                </div>

                                <div className="bg-emerald-950/20 border border-emerald-500/25 p-3 rounded-xl text-[9px] font-mono text-emerald-400 flex gap-2">
                                  <span>🔒</span>
                                  <span>Note: Safaricom Daraja STK Push and payment dialogs only appear after checkout review is completed.</span>
                                </div>

                                <div className="p-0.5 bg-slate-950 border-t border-slate-800 grid grid-cols-2 gap-2 mt-2">
                                  <button
                                    type="button"
                                    onClick={() => setWidgetStep('insurance')}
                                    className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                                  >
                                    Back
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (!/^(07|01)\d{8}$/.test(widgetBuyerPhone.trim())) {
                                        alert("Please enter a valid 10-digit Safaricom phone number starting with 07 or 01");
                                        return;
                                      }
                                      setWidgetStep('stk');
                                    }}
                                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-2.5 rounded-xl transition text-xs cursor-pointer shadow-lg"
                                  >
                                    Authorize Payment
                                  </button>
                                </div>
                              </div>
                            );
                          })()}
                        </div>
                      )}

                      {/* POPUP STAGE 6: MPESA STK SIMULATOR OVERLAY */}
                      {widgetStep === 'stk' && (
                        <div className="p-6 text-center space-y-6 flex flex-col justify-center items-center min-h-[300px]">
                          
                          {(() => {
                            const subtotal = widgetCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
                            const shipFee = widgetDeliveryMethod === 'Courier' ? 300 : widgetDeliveryMethod === 'Rider' ? 150 : 0;
                            const insPrem = widgetInsurance ? 120 : 0;
                            const platformFee = Math.max(25, Math.round(subtotal * 0.01));
                            const finalTotal = subtotal + shipFee + insPrem + platformFee;

                            return (
                              <div className="bg-slate-950 border-2 border-emerald-500 p-5 rounded-2xl w-full max-w-xs space-y-4 shadow-xl">
                                <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                                  <span className="text-emerald-400 font-black text-[10px] font-mono tracking-widest uppercase">SAFARICOM DARAJA</span>
                                  <span className="text-[10px] text-slate-400">M-PESA ONLINE</span>
                                </div>
                                
                                <p className="text-[11px] text-slate-200 leading-relaxed text-left font-mono">
                                  Do you want to lock and pay <strong>KSh {finalTotal.toLocaleString()}</strong> to Buy Safely Escrow for <strong>{widgetCart.length} products</strong> from {sellerHandle}?
                                </p>

                                <div className="space-y-2">
                                  <label className="text-[9px] text-slate-400 block text-left uppercase">Enter M-Pesa PIN:</label>
                                  <input 
                                    type="password"
                                    maxLength={4}
                                    value={widgetMpesaPin}
                                    onChange={(e) => {
                                      const val = e.target.value.replace(/\D/g, '');
                                      if (val.length <= 4) {
                                        setWidgetMpesaPin(val);
                                      }
                                    }}
                                    className="w-full bg-slate-900 text-center border border-slate-800 p-2 text-lg text-white font-mono tracking-widest outline-none rounded-lg"
                                    placeholder="••••"
                                  />
                                </div>

                                <div className="grid grid-cols-2 gap-2 text-[10px] font-black font-sans uppercase">
                                  <button 
                                    type="button"
                                    onClick={() => setWidgetStep('breakdown')}
                                    className="bg-slate-900 border border-slate-800 py-2 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                                  >
                                    Cancel
                                  </button>
                                  
                                  <button 
                                    type="button"
                                    onClick={async () => {
                                      setIsProcessingWidgetCheckout(true);
                                      setTimeout(async () => {
                                        try {
                                          const descText = widgetCart.map(item => `${item.product.title} (Qty: ${item.quantity})`).join(', ');
                                          const response = await fetch('/api/transactions', {
                                            method: 'POST',
                                            headers: { 'Content-Type': 'application/json' },
                                            body: JSON.stringify({
                                              buyerPhone: widgetBuyerPhone,
                                              buyerName: widgetBuyerName,
                                              buyerAccountType: 'GUEST',
                                              recipientDetails: {
                                                name: widgetBuyerName,
                                                phone: widgetBuyerPhone,
                                                address: widgetRecipientAddress,
                                                relationship: 'Self'
                                              },
                                              sellerPhone,
                                              sellerHandle,
                                              socialPlatform: platform,
                                              amount: subtotal,
                                              description: descText,
                                              quantity: widgetCart.reduce((sum, item) => sum + item.quantity, 0),
                                              shippingMethod: widgetDeliveryMethod,
                                              shippingFee: shipFee,
                                              totalAmount: finalTotal,
                                              paymentNetwork: 'mpesa',
                                              shippingDetails: {
                                                county: 'Nairobi',
                                                town: 'Widget Hub',
                                                address: widgetRecipientAddress
                                              },
                                              orderStatus: 'PAID_PENDING_FULFILLMENT',
                                              insurancePolicy: 'BUYER_CHOOSES',
                                              insuranceOption: widgetInsurance ? 'BASIC' : 'NONE',
                                              insurancePremium: insPrem,
                                              insurancePaidBy: widgetInsurance ? 'BUYER' : 'NONE',
                                              cartEnabled: true,
                                              items: widgetCart.map(item => ({
                                                productId: item.product.id,
                                                title: item.product.title,
                                                price: item.product.price,
                                                quantity: item.quantity
                                              })),
                                              packages: [
                                                {
                                                  id: 'PKG-001',
                                                  items: widgetCart.map(item => item.product.id),
                                                  carrier: 'Fargo Courier',
                                                  shippingFee: shipFee,
                                                  status: 'PENDING'
                                                }
                                              ]
                                            })
                                          });

                                          if (response.ok) {
                                            const newTx = await response.json();
                                            // Auto-complete deposit sequence to capture FUNDS_HELD
                                            await fetch(`/api/transactions/${newTx.id}/deposit`, { method: 'POST' });
                                            onTransactionCreated(newTx);
                                          }
                                          
                                          setIsProcessingWidgetCheckout(false);
                                          setWidgetStep('success');
                                        } catch (e) {
                                          console.error("Failed to mock write transaction:", e);
                                          setIsProcessingWidgetCheckout(false);
                                          setWidgetStep('success');
                                        }
                                      }, 1500);
                                    }}
                                    className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 py-2 rounded-lg cursor-pointer"
                                  >
                                    {isProcessingWidgetCheckout ? 'Securing...' : 'Secure Vault'}
                                  </button>
                                </div>
                              </div>
                            );
                          })()}

                          <span className="text-[10px] text-slate-400 block font-mono">
                            🔄 Handshaking with Safaricom M-Pesa Daraja Gateway...
                          </span>

                        </div>
                      )}

                      {/* POPUP STAGE 7: SUCCESS SCREEN */}
                      {widgetStep === 'success' && (
                        <div className="p-6 text-center space-y-5 flex flex-col justify-center items-center min-h-[300px]">
                          <div className="w-14 h-14 bg-emerald-950 border border-emerald-500/30 rounded-full flex items-center justify-center text-emerald-400 text-xl font-bold animate-bounce animate-duration-1000">
                            ✓
                          </div>
                          
                          <div className="space-y-1">
                            <span className="text-[9px] font-mono text-emerald-400 font-bold uppercase tracking-wider block">Capital Locked Securely</span>
                            <h4 className="text-base font-black text-white uppercase">Escrow Vault Active!</h4>
                            <p className="text-[11px] text-slate-400 leading-normal max-w-xs mx-auto">
                              Your funds have been deposited into the secure NCBA escrow reserve bank. The merchant has been authorized and dispatched to fulfill your combined package immediately.
                            </p>
                          </div>

                          <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 font-mono text-[10px] text-slate-400 w-full max-w-xs space-y-1 text-left select-all">
                            <p><strong>Contract ID:</strong> BS-ESC-2026-MULTI</p>
                            <p><strong>Inspected Status:</strong> CBK LICENSED ESCROW ACTIVE</p>
                            <p><strong>Combined Shipping:</strong> Fargo Consolidated Courier</p>
                          </div>

                          <button 
                            type="button"
                            onClick={() => {
                              setIsWidgetCheckoutOpen(false);
                              setWidgetCart([]); // empty cart on success
                              setWidgetStep('cart');
                            }}
                            className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold uppercase py-2.5 rounded-xl transition text-xs cursor-pointer"
                          >
                            Close checkout
                          </button>
                        </div>
                      )}

                    </div>
                  </div>
                )}

                {/* COPYABLE CODE SNIPPET BOXES */}
                <div className="space-y-4">
                  <div className="space-y-1.5 text-left">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                        {embedOption === 'A' && 'Buy Now Widget Embed Code'}
                        {embedOption === 'B' && 'Smart Cart Widget Embed Code (Recommended)'}
                        {embedOption === 'C' && 'Storefront Widget Embed Code'}
                        {embedOption === 'D' && 'Floating Buy Safely Widget Embed Code'}
                      </label>
                      <button 
                        onClick={() => {
                          const code = embedOption === 'A' ? buyNowWidgetHTML : 
                                       (embedOption === 'B' ? smartCartWidgetHTML : 
                                       (embedOption === 'C' ? storefrontWidgetHTML : floatingWidgetHTML));
                          handleCopySnippet(code, 'widget');
                        }}
                        className="text-xs text-indigo-600 font-black flex items-center gap-1 cursor-pointer"
                      >
                        {copiedSnippetType === 'widget' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedSnippetType === 'widget' ? 'Copied' : 'Copy HTML Code'}</span>
                      </button>
                    </div>
                    
                    <pre className="text-[10px] font-mono leading-normal bg-slate-900 text-emerald-300 p-4.5 rounded-xl overflow-x-auto border border-slate-800 select-all max-h-48">
                      {embedOption === 'A' ? buyNowWidgetHTML : 
                       (embedOption === 'B' ? smartCartWidgetHTML : 
                       (embedOption === 'C' ? storefrontWidgetHTML : floatingWidgetHTML))}
                    </pre>
                  </div>
                </div>

              </div>
            )}

            {/* LIVE SHARE LINK PANEL */}
            {generatedLink && (
              <div className="bg-emerald-500 text-white rounded-3xl p-6 md:p-8 space-y-6 shadow-md relative overflow-hidden select-none">
                <div className="absolute right-[-10%] top-[-20%] opacity-20 aspect-square bg-white rounded-full w-48 blur-2xl"></div>

                <div className="space-y-2 relative z-10">
                  <span className="text-[9px] text-emerald-950 bg-white/20 px-2.5 py-1 rounded-full border border-white/10 uppercase tracking-widest font-black">
                    ✓ Escrow Checkouts Activated
                  </span>
                  <h3 className="text-xl font-bold tracking-tight">Protected Seller Link Generated</h3>
                  <p className="text-xs text-emerald-100">Copy and place this URL in WhatsApp catalogs, Instagram profiles, TikTok bios, or WordPress links.</p>
                </div>

                {/* Main Link box */}
                <div className="flex bg-white/20 rounded-2xl p-2 border border-white/10 items-center justify-between gap-2 relative z-10">
                  <div className="font-mono text-xs text-white font-medium overflow-x-auto whitespace-nowrap px-2">
                    {generatedLink}
                  </div>
                  <button 
                    onClick={copyToClipboard}
                    className="bg-white text-emerald-800 hover:bg-slate-100 font-bold text-xs px-4 py-2.5 rounded-xl transition flex items-center gap-1 shrink-0 active:scale-95 cursor-pointer"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? 'Copied' : 'Copy link'}</span>
                  </button>
                </div>

                {/* Social media direct shares */}
                <div className="border-t border-white/10 pt-4 flex flex-wrap gap-2 text-xs font-semibold relative z-10">
                  <a 
                    href={`https://wa.me/?text=Buy%20safely%20with%20escrow%20protection:%20${generatedLink}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="bg-emerald-600 hover:bg-emerald-700 px-3.5 py-2 rounded-xl flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" /> WhatsApp Shop
                  </a>
                  
                  <button 
                    onClick={() => alert(`Please paste: "${generatedLink}" in Instagram direct messages.`)}
                    className="bg-pink-600 hover:bg-pink-700 px-3.5 py-2 rounded-xl flex items-center gap-1.5"
                  >
                    <Instagram className="w-3.5 h-3.5" /> Instagram DM
                  </button>

                  <a 
                    href={`https://t.me/share/url?url=${generatedLink}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="bg-sky-600 hover:bg-sky-700 px-3.5 py-2 rounded-xl flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" /> Telegram Post
                  </a>
                </div>
              </div>
            )}

          </div>
        </div>

        {/* RIGHT COLUMN: SMARTPHONE USER CHECKOUT SANDBOX (HIGHLY INTERACTIVE) */}
        <div className="lg:col-span-5 lg:sticky lg:top-24 space-y-4">
          <div className="flex justify-between items-center select-none">
            <h4 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider">M-Pesa Buyer Device Playground</h4>
            <span className="text-[10px] bg-slate-200 text-slate-600 font-bold font-mono px-2 py-0.5 rounded">Checkout Simulator</span>
          </div>

          {/* REAL MOBILE BROWSER INTEGRATION SHELL */}
          <div className="relative mx-auto max-w-[340px] border-[10px] border-slate-900 rounded-[44px] bg-white h-[680px] shadow-2xl overflow-hidden flex flex-col justify-between font-sans ring-1 ring-slate-100">
            
            {/* Phone Top Notch Speaker */}
            <div className="absolute top-0 inset-x-0 h-5 bg-slate-900 z-50 rounded-b-xl flex justify-center items-center">
              <div className="w-16 h-2 bg-slate-800 rounded-full"></div>
            </div>

            {/* In-app Browser Address Header */}
            <div className="bg-slate-900 text-white pt-6 pb-2.5 px-4 text-xs flex justify-between items-center border-b border-slate-800 shrink-0 select-none">
              <div className="flex items-center gap-1.5 font-mono text-[9px] text-slate-300">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span className="text-slate-200">buysafely.africa/pay/BS-{socialUrl ? 'LINK' : 'PORTAL'}</span>
              </div>
              <div className="flex gap-2 text-slate-400">
                <span>🔒 Secure API</span>
              </div>
            </div>

            {/* INTERACTIVE COMPONENT SWITCHER STEP PANEL */}
            <div className="flex-1 bg-slate-50/50 overflow-y-auto p-4 space-y-4 pt-4 text-xs">
              
              {/* STAGE 1: STOREFRONT BROWSE JOURNEY */}
              {phoneStep === 'storefront' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-slate-900 text-white rounded-2xl p-3 border border-slate-800 flex justify-between items-center">
                    <div>
                      <span className="text-[8px] uppercase tracking-wider text-slate-400">STOREFRONT LINK</span>
                      <h4 className="text-xs font-black tracking-tight">{sellerHandle || '@trendy_thrifts_ke'}</h4>
                    </div>
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[8px] font-black uppercase rounded-full px-2 py-0.5">
                      ✓ Secure Escrow
                    </span>
                  </div>

                  <p className="text-[10px] text-slate-500 leading-normal text-left">
                    Browse and purchase certified items safely under Central Bank of Kenya-protected trust escrow.
                  </p>

                  {/* Product Grid Catalog */}
                  <div className="space-y-3">
                    {getPlaygroundProducts().map((prod) => (
                      <div key={prod.id} className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm space-y-2">
                        <div className="flex justify-between gap-2">
                          <div className="space-y-1 text-left">
                            <h5 className="text-xs font-bold text-slate-900 leading-tight">{prod.title}</h5>
                            <p className="text-[9px] text-slate-400 line-clamp-2 leading-relaxed">{prod.description}</p>
                          </div>
                          <div className="w-12 h-12 bg-slate-100 rounded-lg shrink-0 overflow-hidden border flex items-center justify-center">
                            {prod.image ? (
                              <img src={prod.image} alt={prod.title} className="w-full h-full object-cover" />
                            ) : (
                              <span className="text-xl">
                                {prod.id === 'PROD-001' ? '🧥' : prod.id === 'PROD-002' ? '🧼' : '🧣'}
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex justify-between items-center pt-1.5 border-t border-slate-50 leading-none">
                          <span className="font-mono text-xs font-extrabold text-indigo-700">Ksh {prod.price.toLocaleString()}</span>
                          <span className="text-[8px] text-slate-400 font-bold">Qty available: {prod.stock}</span>
                        </div>

                        <div className="grid grid-cols-2 gap-1.5 pt-1">
                          <button
                            type="button"
                            onClick={() => {
                              const existing = playgroundCart.find(item => item.product.id === prod.id);
                              if (existing && existing.quantity >= prod.stock) {
                                alert(`Seller stock limit reached (${prod.stock} units left).`);
                                return;
                              }
                              if (existing) {
                                setPlaygroundCart(playgroundCart.map(item => 
                                  item.product.id === prod.id ? { ...item, quantity: item.quantity + 1 } : item
                                ));
                              } else {
                                setPlaygroundCart([...playgroundCart, { product: prod, quantity: 1, insured: true }]);
                              }
                            }}
                            className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold py-2 rounded-xl text-[9px] uppercase tracking-wide transition flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <ShoppingCart className="w-3 h-3" />
                            <span>Add to Cart</span>
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => {
                              setPlaygroundCart([{ product: prod, quantity: 1, insured: true }]);
                              setPhoneStep('cart');
                            }}
                            className="bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-2 rounded-xl text-[9px] uppercase tracking-wide transition flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Lock className="w-3 h-3 text-emerald-400" />
                            <span>Buy Now</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Floating Cart Panel Component */}
                  {playgroundCart.length > 0 && (
                    <div className="sticky bottom-0 bg-indigo-950 text-white rounded-2xl p-3 shadow-lg flex justify-between items-center z-10 animate-fade-in mt-4 border border-indigo-800">
                      <div className="text-[10px] leading-tight text-left">
                        <p className="font-extrabold text-emerald-400">{playgroundCart.reduce((sum, item) => sum + item.quantity, 0)} Items Selected</p>
                        <span className="text-slate-200 font-mono text-[11px] font-bold">Ksh {getPlaygroundSubtotal().toLocaleString()}</span>
                      </div>
                      <button 
                        onClick={() => setPhoneStep('cart')}
                        className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black px-3 py-1.5 rounded-xl uppercase text-[9px] tracking-wider cursor-pointer"
                      >
                        View Cart
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* STAGE 2: "REVIEW CART & CHECKOUT" SCREEN */}
              {phoneStep === 'cart' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="flex justify-between items-center">
                    <button onClick={() => setPhoneStep('storefront')} className="flex items-center gap-1 text-[10px] text-indigo-600 font-extrabold cursor-pointer">
                      ← Storefront
                    </button>
                    <span className="text-[8px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded font-mono font-bold">Step 1 of 4</span>
                  </div>

                  <div className="bg-slate-900 text-white rounded-2xl p-3 border border-slate-800 flex justify-between items-center">
                    <h4 className="text-xs font-black uppercase">Review Cart &amp; Checkout</h4>
                    <span className="text-[9px] text-emerald-400 font-bold font-mono">Basket ({playgroundCart.reduce((sum, item) => sum + item.quantity, 0)})</span>
                  </div>

                  {playgroundCart.length === 0 ? (
                    <div className="bg-white rounded-2xl border border-slate-100 p-8 text-center space-y-3 shadow-sm">
                      <ShoppingCart className="w-8 h-8 text-slate-300 mx-auto" />
                      <p className="text-[10px] text-slate-500 font-bold">Your cart is currently empty.</p>
                      <button 
                        type="button"
                        onClick={() => setPhoneStep('storefront')}
                        className="bg-slate-900 text-white text-[9px] font-bold px-4 py-2 rounded-xl"
                      >
                        Browse Storefront Catalog
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {/* Cart Items List */}
                      <div className="space-y-2">
                        {playgroundCart.map((item) => (
                          <div key={item.product.id} className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm flex gap-3 items-center justify-between">
                            <div className="w-10 h-10 bg-slate-100 rounded-lg shrink-0 overflow-hidden border flex items-center justify-center">
                              {item.product.image ? (
                                <img src={item.product.image} alt={item.product.title} className="w-full h-full object-cover" />
                              ) : (
                                <span className="text-lg">
                                  {item.product.id === 'PROD-001' ? '🧥' : item.product.id === 'PROD-002' ? '🧼' : '🧣'}
                                </span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0 text-left">
                              <h5 className="text-[10px] font-bold text-slate-900 truncate">{item.product.title}</h5>
                              <p className="text-[9px] font-mono text-indigo-700 font-bold">Ksh {item.product.price.toLocaleString()}</p>
                            </div>

                            {/* Quantity Adjusters */}
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => {
                                  if (item.quantity > 1) {
                                    setPlaygroundCart(playgroundCart.map(it => 
                                      it.product.id === item.product.id ? { ...it, quantity: it.quantity - 1 } : it
                                    ));
                                  } else {
                                    setPlaygroundCart(playgroundCart.filter(it => it.product.id !== item.product.id));
                                  }
                                }}
                                className="w-5 h-5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-[10px]"
                              >
                                -
                              </button>
                              <span className="text-[10px] font-bold font-mono text-slate-900 w-4 text-center">{item.quantity}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  if (item.quantity < item.product.stock) {
                                    setPlaygroundCart(playgroundCart.map(it => 
                                      it.product.id === item.product.id ? { ...it, quantity: it.quantity + 1 } : it
                                    ));
                                  } else {
                                    alert(`Seller stock limit reached (${item.product.stock} units left).`);
                                  }
                                }}
                                className="w-5 h-5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-[10px]"
                              >
                                +
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  setPlaygroundCart(playgroundCart.filter(it => it.product.id !== item.product.id));
                                }}
                                className="ml-1 text-slate-400 hover:text-red-500 cursor-pointer p-0.5"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Combined Shipping Notice */}
                      <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-3 space-y-1 text-emerald-800 text-[10px] leading-relaxed text-left">
                        <div className="flex items-center gap-1 text-emerald-900 font-bold">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600 fill-emerald-50" />
                          <span>COMBINED SHIPPING ACTIVE</span>
                        </div>
                        <p className="text-slate-600 text-[9px]">
                          All selected items belong to the same merchant <strong className="text-indigo-950 font-bold">{sellerHandle || '@trendy_thrifts_ke'}</strong>. A single delivery fee applies.
                        </p>
                      </div>

                      {/* Running subtotal */}
                      <div className="bg-slate-900 text-white rounded-2xl p-3 font-mono flex justify-between items-center leading-none">
                        <span className="text-[9px] text-slate-400 font-sans">Cart Subtotal:</span>
                        <strong className="text-xs">Ksh {getPlaygroundSubtotal().toLocaleString()}</strong>
                      </div>

                      {/* Proceed */}
                      <button
                        type="button"
                        onClick={() => setPhoneStep('checkout')}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3 rounded-2xl uppercase tracking-wider text-[10px] shadow-sm flex items-center justify-center gap-1 transition"
                      >
                        <span>Proceed to Details &amp; Shipping</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* STAGE 3: RECIPIENT & SHIPPING DETAILS */}
              {phoneStep === 'checkout' && (
                <div className="space-y-4 animate-fade-in text-left">
                  <div className="flex justify-between items-center">
                    <button onClick={() => setPhoneStep('cart')} className="flex items-center gap-1 text-[10px] text-indigo-600 font-extrabold cursor-pointer">
                      ← Edit Cart
                    </button>
                    <span className="text-[8px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded font-mono font-bold">Step 2 of 4</span>
                  </div>

                  {/* BUYER PROFILE & IDENTITY FORM */}
                  <div className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm space-y-3">
                    <div className="flex justify-between items-center whitespace-nowrap leading-none">
                      <span className="font-extrabold text-slate-800 tracking-tight text-[10.5px]">1. Purchaser Identity</span>
                      <span className="text-[7px] bg-red-50 text-red-700 font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">Sandbox Mode</span>
                    </div>

                    <div className="grid grid-cols-2 gap-1.5 bg-slate-100 p-1 rounded-xl">
                      <button 
                        type="button"
                        onClick={() => {
                          setBuyerAccountType('GUEST');
                          setBuyerNationalId('');
                        }}
                        className={`py-1 text-[9px] font-extrabold text-center rounded-lg transition ${buyerAccountType === 'GUEST' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'}`}
                      >
                        Guest
                      </button>
                      <button 
                        type="button"
                        onClick={() => {
                          setBuyerAccountType('REGISTERED');
                        }}
                        className={`py-1 text-[9px] font-extrabold text-center rounded-lg transition ${buyerAccountType === 'REGISTERED' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'}`}
                      >
                        Registered User
                      </button>
                    </div>

                    <div className="space-y-2">
                      <div>
                        <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Purchaser Full Name</label>
                        <input 
                          type="text" 
                          value={buyerName} 
                          onChange={(e) => {
                            setBuyerName(e.target.value);
                            if (!isNotRecipient) setContactPerson(e.target.value);
                          }} 
                          className="w-full bg-slate-50 border rounded-lg p-2 text-xs font-semibold outline-none" 
                          placeholder="e.g. James Kamau"
                          required 
                        />
                      </div>

                      {buyerAccountType === 'REGISTERED' && (
                        <div className="animate-fadeIn">
                          <label className="block text-[8px] font-bold text-slate-500 mb-0.5">National ID (Required for Registered)</label>
                          <input 
                            type="text" 
                            value={buyerNationalId} 
                            onChange={(e) => setBuyerNationalId(e.target.value)} 
                            className="w-full bg-slate-50 border rounded-lg p-2 text-xs font-mono outline-none" 
                            placeholder="e.g. 32098412" 
                            required 
                          />
                        </div>
                      )}

                      {/* Recipient Checkbox */}
                      <div className="pt-1.5 border-t border-slate-100 mt-2">
                        <label className="flex items-center gap-2 cursor-pointer text-[9.5px] font-bold text-slate-600">
                          <input 
                            type="checkbox" 
                            checked={isNotRecipient} 
                            onChange={(e) => {
                              setIsNotRecipient(e.target.checked);
                              if (!e.target.checked) {
                                setContactPerson(buyerName);
                              } else {
                                setContactPerson('');
                              }
                            }} 
                            className="rounded text-indigo-600 accent-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
                          />
                          <span>Deliver to a separate recipient</span>
                        </label>
                      </div>

                      {isNotRecipient && (
                        <div className="bg-indigo-50/30 border border-indigo-100/50 rounded-xl p-2.5 space-y-2 mt-2 animate-fadeIn text-left">
                          <span className="text-[8px] uppercase font-bold text-indigo-800 tracking-wider block">Recipient Contact Details</span>
                          <div>
                            <label className="block text-[7.5px] font-bold text-slate-500 mb-0.5">Recipient Full Name</label>
                            <input 
                              type="text" 
                              value={recipientName} 
                              onChange={(e) => {
                                setRecipientName(e.target.value);
                                setContactPerson(e.target.value);
                              }} 
                              className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs outline-none" 
                              placeholder="e.g. Mary Wanjiku"
                              required 
                            />
                          </div>
                          <div>
                            <label className="block text-[7.5px] font-bold text-slate-500 mb-0.5">Recipient Phone Number</label>
                            <input 
                              type="text" 
                              value={recipientPhone} 
                              onChange={(e) => {
                                setRecipientPhone(e.target.value);
                                setBuyerContactPhone(e.target.value);
                              }} 
                              className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs font-mono outline-none" 
                              placeholder="e.g. 0722334455"
                              required 
                            />
                          </div>
                          <div>
                            <label className="block text-[7.5px] font-bold text-slate-500 mb-0.5">Relationship to Purchaser</label>
                            <select 
                              value={recipientRelationship} 
                              onChange={(e) => setRecipientRelationship(e.target.value)} 
                              className="w-full bg-white border border-slate-200 rounded-lg p-1.5 text-xs outline-none"
                            >
                              <option value="Friend">Friend / Colleague</option>
                              <option value="Spouse">Spouse / Partner</option>
                              <option value="Family">Family Member / Relative</option>
                              <option value="Client">Corporate Client</option>
                              <option value="Gift Receiver">Gift Receiver</option>
                            </select>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* SELECT SHIPPING METHOD */}
                  <div className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm space-y-3">
                    <span className="font-extrabold text-slate-800 tracking-tight block text-[10.5px]">2. Delivery Handover Method</span>
                    
                    <div className="grid grid-cols-1 gap-1.5 font-sans">
                      <label className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition ${selectedShipping === 'Courier' ? 'bg-indigo-50/40 border-indigo-200 text-indigo-950 font-bold' : 'bg-slate-50 border-slate-200'}`}>
                        <div className="flex items-center gap-1.5">
                          <input type="radio" checked={selectedShipping === 'Courier'} onChange={() => setSelectedShipping('Courier')} />
                          <div>
                            <p className="text-[11px]">Courier Express Dispatch</p>
                            <span className="text-[8px] text-slate-400 font-medium leading-none block">Delivered via Courier Hub</span>
                          </div>
                        </div>
                        <span className="font-mono text-[9px] text-indigo-650 font-bold">Ksh {selectedShipping === 'Courier' ? getPlaygroundShippingFee() : courierFee}</span>
                      </label>

                      <label className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition ${selectedShipping === 'Pickup' ? 'bg-indigo-50/40 border-indigo-200 text-indigo-950 font-bold' : 'bg-slate-50 border-slate-200'}`}>
                        <div className="flex items-center gap-1.5">
                          <input type="radio" checked={selectedShipping === 'Pickup'} onChange={() => setSelectedShipping('Pickup')} />
                          <div>
                            <p className="text-[11px]">Self Collect / Pickup</p>
                            <span className="text-[8px] text-slate-400 font-medium leading-none block">Collect from verified location</span>
                          </div>
                        </div>
                        <span className="font-mono text-[9px]">Ksh {pickupFee}</span>
                      </label>

                      <label className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition ${selectedShipping === 'Seller Delivery' ? 'bg-indigo-50/40 border-indigo-200 text-indigo-950 font-bold' : 'bg-slate-50 border-slate-200'}`}>
                        <div className="flex items-center gap-1.5">
                          <input type="radio" checked={selectedShipping === 'Seller Delivery'} onChange={() => setSelectedShipping('Seller Delivery')} />
                          <div>
                            <p className="text-[11px]">Seller Custom Delivery</p>
                            <span className="text-[8px] text-slate-400 font-medium leading-none block">Delivered directly by vendor</span>
                          </div>
                        </div>
                        <span className="font-mono text-[9px]">Ksh {sellerDeliveryFee}</span>
                      </label>
                    </div>

                    <AnimatePresence mode="wait">
                      {selectedShipping === 'Courier' && (
                        <motion.div 
                          key="courier"
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="space-y-2 border-t pt-3 border-slate-100"
                        >
                          <div>
                            <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Delivery County</label>
                            <select value={county} onChange={(e) => setCounty(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-2 font-semibold text-xs">
                              <option value="Nairobi">Nairobi County</option>
                              <option value="Mombasa">Mombasa County</option>
                              <option value="Kiambu">Kiambu County</option>
                              <option value="Kisumu">Kisumu County</option>
                              <option value="Nakuru">Nakuru County</option>
                              <option value="Uasin Gishu">Uasin Gishu County</option>
                            </select>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Town</label>
                              <input type="text" value={town} onChange={(e) => setTown(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs" required />
                            </div>
                            <div>
                              <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Recipient Phone</label>
                              <input type="text" value={buyerContactPhone} onChange={(e) => setBuyerContactPhone(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs font-mono" />
                            </div>
                          </div>
                          <div>
                            <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Fulfillment Address / Landmarks</label>
                            <input type="text" value={address} onChange={(e) => setAddress(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs" required />
                          </div>
                          <div>
                            <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Recipient Name</label>
                            <input type="text" value={contactPerson} onChange={(e) => setContactPerson(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs" required />
                          </div>

                          <div className="pt-3 border-t border-dashed border-slate-100 space-y-1.5 mt-1">
                            <div className="flex justify-between items-center leading-none">
                              <span className="text-[9.5px] uppercase font-extrabold text-indigo-950 tracking-wider">Choose your courier partner</span>
                            </div>

                            <div className="flex gap-1 justify-between text-[8px]">
                              <span className="text-slate-400 font-bold">Sort:</span>
                              <div className="flex gap-1">
                                {[
                                  { id: 'recommended', label: '⭐ Rec' },
                                  { id: 'cheapest', label: '💰 Cheap' },
                                  { id: 'fastest', label: '⚡ Fast' }
                                ].map(st => (
                                  <button
                                    key={st.id}
                                    type="button"
                                    onClick={() => setCourierSort(st.id as any)}
                                    className={`px-1 py-0.5 rounded text-[7.5px] font-bold transition-all ${courierSort === st.id ? 'bg-indigo-600 text-white' : 'bg-slate-150 hover:bg-slate-200 text-slate-600'}`}
                                  >
                                    {st.label}
                                  </button>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                              {getEnrichedCouriers().map(courier => {
                                const isSelected = selectedCourierId === courier.id;
                                return (
                                  <div
                                    key={courier.id}
                                    onClick={() => setSelectedCourierId(courier.id)}
                                    className={`p-1.5 rounded-lg border text-[10px] cursor-pointer transition-all flex flex-col gap-1 relative ${isSelected ? 'bg-indigo-50/20 border-indigo-600' : 'bg-white border-slate-200'}`}
                                  >
                                    <div className="flex items-center justify-between leading-none">
                                      <span className="font-extrabold text-slate-800">{courier.name}</span>
                                      <span className="font-mono font-bold text-indigo-650 text-[10px]">Ksh {courier.fee}</span>
                                    </div>
                                    <div className="flex justify-between text-[8px] text-slate-400 font-mono leading-none">
                                      <span>★ {courier.rating} • {courier.completedDeliveries} trips</span>
                                      <span>⏱️ {courier.timeText}</span>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        </motion.div>
                      )}

                      {selectedShipping === 'Pickup' && (
                        <motion.div 
                          key="pickup"
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="space-y-2 border-t pt-3 border-slate-100"
                        >
                          <div>
                            <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Pickup Location</label>
                            <select value={pickupLocation} onChange={(e) => setPickupLocation(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-2 font-semibold text-xs outline-none">
                              <option value="Nairobi CBD - Kimathi Street Coop Tower">Nairobi CBD - Kimathi Street Coop Tower</option>
                              <option value="Westlands Shop - Mall Chambers Floor 1">Westlands Shop - Mall Chambers Floor 1</option>
                            </select>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Pickup Date</label>
                              <input type="date" value={pickupDate} onChange={(e) => setPickupDate(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs font-semibold outline-none" />
                            </div>
                            <div>
                              <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Collector Contact</label>
                              <input type="text" value={pickupContact} onChange={(e) => setPickupContact(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs outline-none" />
                            </div>
                          </div>
                        </motion.div>
                      )}

                      {selectedShipping === 'Seller Delivery' && (
                        <motion.div 
                          key="seller"
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="space-y-2 border-t pt-3 border-slate-100"
                        >
                          <div>
                            <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Specify Handover Area</label>
                            <input type="text" value={deliveryArea} onChange={(e) => setDeliveryArea(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs outline-none font-semibold" placeholder="e.g. Ruiru, Upperhill blocks" />
                          </div>
                          <div>
                            <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Delivery Contact/Boda Details</label>
                            <input type="text" value={deliveryContactDetails} onChange={(e) => setDeliveryContactDetails(e.target.value)} className="w-full bg-slate-50 border rounded-lg p-1.5 text-xs outline-none" />
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* SHIPPING PROTECTION SELECTION */}
                  <div className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm space-y-2 text-left">
                    <span className="font-extrabold text-slate-800 tracking-tight block text-[10.5px]">3. Shipping Transit Protection</span>
                    
                    {insurancePolicy === 'NONE' ? (
                      <p className="text-[8px] text-slate-400 font-bold">Merchant disabled insurance cover for this link transaction.</p>
                    ) : insurancePolicy === 'SELLER_COVERS' ? (
                      <div className="bg-emerald-50 text-emerald-800 p-2 border border-emerald-100 rounded-xl text-[9px]">
                        <strong>✓ Seller Covers Premium!</strong>
                        <p className="mt-0.5">Premium covered in full by merchant. You are protected for Ksh 0.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-1.5">
                        <label className={`p-2 rounded-xl border flex justify-between cursor-pointer text-[9px] ${selectedInsuranceOption === 'NONE' ? 'border-indigo-600 bg-indigo-50/10' : 'bg-slate-50 border-slate-200'}`}>
                          <div className="flex gap-1">
                            <input type="radio" checked={selectedInsuranceOption === 'NONE'} onChange={() => setSelectedInsuranceOption('NONE')} />
                            <div>
                              <strong className="block text-slate-800">No Insurance</strong>
                              <span className="text-[7.5px] text-slate-400 block leading-tight">Buyer bears complete parcel damage liabilities</span>
                            </div>
                          </div>
                          <span className="font-mono text-slate-500 font-bold">Ksh 0</span>
                        </label>

                        <label className={`p-2 rounded-xl border flex justify-between cursor-pointer text-[9px] ${selectedInsuranceOption === 'BASIC' ? 'border-indigo-600 bg-indigo-50/10' : 'bg-slate-50 border-slate-200'}`}>
                          <div className="flex gap-1">
                            <input type="radio" checked={selectedInsuranceOption === 'BASIC'} onChange={() => setSelectedInsuranceOption('BASIC')} />
                            <div>
                              <strong className="block text-slate-800">Basic Jubilee Cargo Protection</strong>
                              <span className="text-[7.5px] text-slate-400 block leading-tight">Loss compensation up to absolute items value</span>
                            </div>
                          </div>
                          <span className="font-mono text-indigo-700 font-bold">
                            Ksh {insurancePolicy === 'SHARED' ? Math.round(getInsurancePremium(getPlaygroundSubtotal(), 'BASIC') * 0.5) : getInsurancePremium(getPlaygroundSubtotal(), 'BASIC')}
                          </span>
                        </label>

                        <label className={`p-2 rounded-xl border flex justify-between cursor-pointer text-[9px] ${selectedInsuranceOption === 'ENHANCED' ? 'border-indigo-600 bg-indigo-50/10' : 'bg-slate-50 border-slate-200'}`}>
                          <div className="flex gap-1">
                            <input type="radio" checked={selectedInsuranceOption === 'ENHANCED'} onChange={() => setSelectedInsuranceOption('ENHANCED')} />
                            <div>
                              <strong className="block text-indigo-700">Enhanced Priority Underwriting</strong>
                              <span className="text-[7.5px] text-indigo-650 block font-bold leading-tight">Priority 24h claim review &amp; expedited processing</span>
                            </div>
                          </div>
                          <span className="font-mono text-indigo-700 font-bold">
                            Ksh {insurancePolicy === 'SHARED' ? Math.round(getInsurancePremium(getPlaygroundSubtotal(), 'ENHANCED') * 0.5) : getInsurancePremium(getPlaygroundSubtotal(), 'ENHANCED')}
                          </span>
                        </label>
                      </div>
                    )}
                  </div>

                  {/* COST BREAKDOWN CARD */}
                  <div className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm space-y-1.5 text-slate-500 font-sans text-[10px] leading-tight">
                    <span className="font-extrabold text-slate-800 block text-[10.5px]">4. Transparent Cost Breakdown</span>
                    <div className="flex justify-between">
                      <span>Products Subtotal ({playgroundCart.reduce((sum, item) => sum + item.quantity, 0)} items):</span>
                      <strong className="text-slate-800 font-mono">Ksh {getPlaygroundSubtotal().toLocaleString()}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Combined Flat Shipping:</span>
                      <strong className="text-slate-800 font-mono">Ksh {getPlaygroundShippingFee().toLocaleString()}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Safe Buy Protected Trust Fee:</span>
                      <strong className="text-slate-800 font-mono">Ksh {getPlaygroundProtectionFee().toLocaleString()}</strong>
                    </div>
                    {getPlaygroundInsurancePremium() > 0 && (
                      <div className="flex justify-between text-emerald-700 font-semibold">
                        <span>Jubilee Transit Cargo Cover:</span>
                        <strong className="font-mono">Ksh {getPlaygroundInsurancePremium().toLocaleString()}</strong>
                      </div>
                    )}
                    <div className="border-t border-dashed pt-1.5 flex justify-between items-center text-slate-900 font-extrabold font-mono text-[11px]">
                      <span>TOTAL PAYABLE AMOUNT:</span>
                      <span className="text-indigo-600 font-black text-xs">Ksh {getPlaygroundTotalAmount().toLocaleString()}</span>
                    </div>
                  </div>

                  {/* PROCEED */}
                  <button
                    type="button"
                    onClick={() => {
                      if (!buyerName.trim()) {
                        alert("Please enter the purchaser full name.");
                        return;
                      }
                      if (buyerAccountType === 'REGISTERED' && !buyerNationalId.trim()) {
                        alert("Please enter your National ID.");
                        return;
                      }
                      if (isNotRecipient && (!recipientName.trim() || !recipientPhone.trim())) {
                        alert("Please enter the separate recipient details.");
                        return;
                      }
                      setPhoneStep('payment');
                    }}
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-3 rounded-2xl uppercase tracking-wider text-[10px] shadow-sm flex items-center justify-center gap-1 transition cursor-pointer"
                  >
                    <span>Inspect Order &amp; Select Payment</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* STAGE 4: "ORDER SUMMARY & PAYMENT OPTIONS" SCREEN */}
              {phoneStep === 'payment' && (
                <div className="space-y-4 animate-fade-in text-left">
                  <div className="flex justify-between items-center">
                    <button onClick={() => setPhoneStep('checkout')} className="flex items-center gap-1 text-[10px] text-indigo-600 font-extrabold cursor-pointer">
                      ← Back to Details
                    </button>
                    <span className="text-[8px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded font-mono font-bold">Step 3 of 4</span>
                  </div>

                  {/* Summary Lockbox Container */}
                  <div className="bg-slate-900 text-white rounded-3xl p-3 space-y-3 border border-slate-800 shadow-md">
                    <div className="text-center pb-2 border-b border-slate-800">
                      <span className="text-[8px] text-emerald-400 font-mono tracking-widest uppercase font-black">Escrow Lockbox Summary</span>
                      <h4 className="text-[11px] font-extrabold text-white mt-0.5">NCBA Monitored Safe Trust Account</h4>
                    </div>

                    <div className="space-y-2 text-[10px] leading-tight font-sans">
                      {/* Item lists */}
                      <div className="space-y-1.5 pb-2 border-b border-slate-800 max-h-24 overflow-y-auto pr-1">
                        {playgroundCart.map(item => (
                          <div key={item.product.id} className="flex justify-between text-slate-300">
                            <span className="truncate max-w-[150px]">{item.product.title} (Qty: {item.quantity})</span>
                            <span className="font-mono text-slate-100">Ksh {(item.product.price * item.quantity).toLocaleString()}</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-400">Shipment Dest:</span>
                        <strong className="text-slate-200 truncate max-w-[140px]">
                          {selectedShipping === 'Courier' ? `${county}, ${town}` : selectedShipping === 'Pickup' ? 'Self Collect Store' : 'Boda Delivery'}
                        </strong>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-400">Safe Protect:</span>
                        <strong className="text-emerald-400">Ksh {getPlaygroundProtectionFee().toLocaleString()} (CBK Trust)</strong>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-400">Cargo Insurance:</span>
                        <strong className="text-slate-200">
                          {getPlaygroundInsurancePremium() > 0 ? `Ksh ${getPlaygroundInsurancePremium().toLocaleString()} (Jubilee)` : 'NONE'}
                        </strong>
                      </div>

                      <div className="flex justify-between border-t border-slate-800 pt-2 text-[10.5px] font-bold">
                        <span className="text-slate-300 font-sans">TOTAL CHARGED DEPOSIT:</span>
                        <strong className="text-white font-mono text-xs">Ksh {getPlaygroundTotalAmount().toLocaleString()}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Safe Escrow Notice Disclaimer */}
                  <div className="bg-sky-50 border border-sky-100 rounded-2xl p-3 space-y-1 text-left text-[9.5px] leading-relaxed text-slate-600">
                    <h5 className="font-black text-sky-950 flex items-center gap-1 leading-none">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 fill-emerald-50" />
                      <span>CBK LICENSED SAFE BUY ESCROW</span>
                    </h5>
                    <p className="text-[8.5px]">
                      Your payment of <strong>Ksh {getPlaygroundTotalAmount().toLocaleString()}</strong> is securely held under NCBA Trusteeship. Funds will not be disbursed to {sellerHandle || '@trendy_thrifts_ke'} until package handover verification clears.
                    </p>
                  </div>

                  {/* Payment Network choices ONLY displayed now after summary completed */}
                  <div className="bg-white rounded-2xl border border-slate-100 p-3 shadow-sm space-y-3">
                    <span className="font-extrabold text-slate-800 tracking-tight block text-[10px]">Select Authorized Payment Wallet</span>

                    <div className="grid grid-cols-3 gap-1.5 font-bold font-sans">
                      <button 
                        type="button" 
                        onClick={() => setBuyerNetwork('mpesa')}
                        className={`py-2 rounded-xl border text-[8.5px] flex items-center justify-center gap-1 transition ${buyerNetwork === 'mpesa' ? 'bg-slate-900 text-white border-slate-900 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        <span>M-Pesa</span>
                      </button>
                      <button 
                        type="button" 
                        onClick={() => setBuyerNetwork('airtel')}
                        className={`py-2 rounded-xl border text-[8.5px] flex items-center justify-center gap-1 transition ${buyerNetwork === 'airtel' ? 'bg-slate-900 text-white border-slate-900 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                        <span>Airtel</span>
                      </button>
                      <button 
                        type="button" 
                        onClick={() => setBuyerNetwork('tcash')}
                        className={`py-2 rounded-xl border text-[8.5px] flex items-center justify-center gap-1 transition ${buyerNetwork === 'tcash' ? 'bg-slate-900 text-white border-slate-900 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-600'}`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                        <span>T-Cash</span>
                      </button>
                    </div>

                    <div className="space-y-2">
                      <div>
                        <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Buyer Billing Mobile Number</label>
                        <input 
                          type="tel" 
                          value={buyerPhoneInput}
                          onChange={(e) => setBuyerPhoneInput(e.target.value)}
                          className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 outline-none font-mono font-bold tracking-wider text-slate-800"
                          placeholder="0712345678"
                        />
                        {phoneError && <p className="text-[8px] font-bold text-red-600 mt-0.5">{phoneError}</p>}
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[8px] font-bold text-slate-500 mb-0.5">Enter Mobile Wallet Transaction PIN</label>
                        <input 
                          type="password"
                          maxLength={4}
                          value={widgetMpesaPin}
                          onChange={(e) => {
                            const val = e.target.value.replace(/\D/g, '');
                            if (val.length <= 4) {
                              setWidgetMpesaPin(val);
                            }
                          }}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl text-center p-1.5 text-base font-mono tracking-widest outline-none"
                          placeholder="••••"
                        />
                      </div>
                    </div>
                  </div>

                  {/* ACTION TRIGGER: INITIATE STK WEBHOOK */}
                  <button 
                    onClick={handlePlaygroundSTKPayment}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3 rounded-2xl uppercase tracking-wider text-[10px] shadow-md flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5 text-slate-950 fill-white" />
                    <span>Pay Ksh {getPlaygroundTotalAmount().toLocaleString()} Safely</span>
                  </button>
                </div>
              )}

              {/* STAGE 5: STK RING / WAITING FOR SIMULATE */}
              {phoneStep === 'stk' && (
                <div className="h-full flex flex-col items-center justify-center space-y-4 py-16 text-center select-none animate-fade-in">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-4 border-slate-100 border-t-indigo-600 animate-spin"></div>
                    <Lock className="w-6 h-6 text-indigo-600 absolute left-5 top-5" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-xs font-black text-slate-900">Pushing STK API Prompt...</h4>
                    <p className="text-[9.5px] text-slate-400 leading-normal max-w-[200px] mx-auto">
                      Authorized network routing of <strong>Ksh {getPlaygroundTotalAmount().toLocaleString()}</strong> to {buyerPhoneInput}. Enter sandbox validation sequence to complete trust contract registration.
                    </p>
                  </div>
                </div>
              )}

              {/* STAGE 6: CHECKOUT PROCESS SUCCESS BANNER */}
              {phoneStep === 'success' && (
                <div className="h-full flex flex-col justify-center items-center py-6 space-y-5 text-center select-none animate-fade-in">
                  
                  <div className="w-14 h-14 bg-emerald-50 rounded-full border border-emerald-200 flex items-center justify-center relative shadow-sm">
                    <CheckCircle className="w-8 h-8 text-emerald-600" />
                  </div>

                  <div className="space-y-1">
                    <span className="text-[8.5px] font-bold text-emerald-600 bg-emerald-50 px-2 rounded-full border uppercase tracking-wider">
                      ✓ Deposit Escrow Funded
                    </span>
                    <h4 className="text-sm font-black text-slate-900">Payment Received Safely!</h4>
                    <p className="text-[9.5px] text-slate-500 max-w-[220px] leading-relaxed mx-auto">
                      Safaricom webhook confirmed. Multi-product order code registered onto trust ledger under status <strong className="text-indigo-950 font-bold">PAID_PENDING_FULFILLMENT</strong>.
                    </p>
                  </div>

                  {/* Summary receipt box */}
                  <div className="bg-white border rounded-2xl p-3.5 w-full space-y-2 text-left text-[9.5px] leading-relaxed text-slate-600 shadow-xs">
                    <div className="flex justify-between font-bold border-b pb-1">
                      <span>Store Handout:</span>
                      <span className="font-mono text-slate-800">{sellerHandle || '@trendy_thrifts_ke'}</span>
                    </div>
                    
                    <div className="border-b pb-1 space-y-1">
                      <span className="font-semibold block text-slate-700 text-[9px]">Order Items:</span>
                      {playgroundCart.map(item => (
                        <div key={item.product.id} className="flex justify-between text-slate-500 font-mono text-[8.5px]">
                          <span>{item.quantity}x {item.product.title}</span>
                          <span>Ksh {(item.product.price * item.quantity).toLocaleString()}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-between">
                      <span>Delivery Option:</span>
                      <span>{selectedShipping} ({selectedShipping === 'Courier' ? county : selectedShipping === 'Pickup' ? 'Store Collect' : 'Direct'})</span>
                    </div>

                    <div className="flex justify-between font-bold text-emerald-700 border-t pt-1 font-mono text-[10px]">
                      <span>Escrow Secured:</span>
                      <span>Ksh {getPlaygroundTotalAmount().toLocaleString()}</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => {
                      setPlaygroundCart([]);
                      setPhoneStep('storefront');
                    }}
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-xl transition cursor-pointer"
                  >
                    Return to Storefront Catalog
                  </button>

                </div>
              )}

            </div>

            {/* LOWER THUMB PAY SAFELY ACTION FOOTER PREVENTATIVE MARGINS */}
            <div className="bg-slate-900 text-[9px] text-slate-400 py-3 text-center tracking-wide shrink-0 select-none">
              <span>🛡️ Securely Hosted on Buy Safely Africa Nodes </span>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}

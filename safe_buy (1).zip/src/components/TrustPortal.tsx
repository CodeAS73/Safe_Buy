import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  UserCheck, 
  HelpCircle, 
  TrendingUp, 
  ArrowRight, 
  Smartphone, 
  CheckCircle2, 
  Briefcase, 
  Truck, 
  Search, 
  Lock, 
  Mail, 
  Globe, 
  RefreshCw, 
  FileText,
  AlertTriangle,
  Layers,
  Sparkles,
  Users,
  Building,
  Check,
  Send,
  ExternalLink,
  ChevronRight,
  Database,
  ArrowBigUp,
  MapPin,
  Calendar,
  Layers as LayersIcon,
  Copy,
  Plus,
  Minus,
  Link2,
  UserPlus,
  Package
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Transaction, Merchant, DeliveryPartner, VerifiedProduct } from '../types';

const DEMO_PRODUCTS: VerifiedProduct[] = [
  {
    id: 'PROD-2900',
    title: 'Apple iPhone 15 Pro Max (Titanium Blue, 512GB)',
    category: 'Electronics & Gadgets',
    price: 142000,
    description: 'Perfect original iPhone 15 Pro Max with 96% battery health. Blue Titanium texture, fully unlocked, no iCloud lock. Tested facial ID and speaker grilles.',
    sellerHandle: '@apple_resellers_ke',
    sellerPhone: '254798765432',
    verificationStatus: 'VERIFIED',
    verificationTier: 'STANDARD',
    verificationFee: 450,
    auditorId: 'DP-003',
    auditorName: 'Picker Alex (Safety Inspector)',
    verificationReport: {
      productName: 'Apple iPhone 15 Pro Max',
      category: 'Electronics & Gadgets',
      sellerId: 'USR-104',
      condition: 'Good',
      functionalPass: true,
      serialNumber: 'C39DK0L8Q5',
      notes: 'No scratches on the front display or rear frosted glass. Camera focal lenses and speaker output tested at 100% capacity. Charging port operates without loose contact.',
      outcome: 'Verified',
      submittedAt: '2026-06-19T14:45:00Z'
    },
    verifiedAt: '2026-06-19T14:45:00Z',
    expiresAt: '2026-07-19T14:45:00Z',
    bulkPlanSubscribed: 'BASIC',
    isFeatured: true
  },
  {
    id: 'PROD-7102',
    title: 'Toyota Probox KCK 489Y (White Edition, 1.5L Engine)',
    category: 'Vehicles & Motors',
    price: 840000,
    description: 'Extremely fuel-efficient Toyota Probox, 1.5L active engine, genuine white paint with robust suspensions. Regularly serviced and used for Nairobi light deliveries. Pre-sale certified and odometer physically verified.',
    sellerHandle: '@probox_deals_kenya',
    sellerPhone: '254711223344',
    verificationStatus: 'VERIFIED',
    verificationTier: 'PREMIUM',
    verificationFee: 1500,
    auditorId: 'DP-003',
    auditorName: 'Picker Alex (Safety Inspector)',
    verificationReport: {
      productName: 'Toyota Probox KCK 489Y',
      category: 'Vehicles & Motors',
      sellerId: 'USR-802',
      condition: 'Excellent',
      functionalPass: true,
      serialNumber: 'NCP51-018249',
      notes: 'Odometer matches digital dashboard reports. Frame inspected for previous repair welds or structural damage—none found. Engine idling is steady and gear shifts are seamless.',
      outcome: 'Verified',
      submittedAt: '2026-06-20T10:30:00Z'
    },
    verifiedAt: '2026-06-20T10:30:00Z',
    expiresAt: '2026-07-04T10:30:00Z',
    bulkPlanSubscribed: 'NONE',
    isFeatured: true
  },
  {
    id: 'PROD-9031',
    title: 'Premium Chesterfield L-Shaped Executive Leather Sofa',
    category: 'Furniture & Living',
    price: 185000,
    description: 'Beautiful full grain mahogany leather Chesterfield sectional sofa. Handcrafted with heavy deep tufting, brass nailhead trims, and high-density foam padding. Extremely luxurious furniture for upscale lounges.',
    sellerHandle: '@chesterfield_furnitures_nairobi',
    sellerPhone: '254722334455',
    verificationStatus: 'VERIFIED',
    verificationTier: 'PRIORITY',
    verificationFee: 800,
    auditorId: 'DP-003',
    auditorName: 'Picker Alex (Safety Inspector)',
    verificationReport: {
      productName: 'Chesterfield L-Shaped Sofa',
      category: 'Furniture & Living',
      sellerId: 'USR-209',
      condition: 'Excellent',
      functionalPass: true,
      serialNumber: 'CHEST-8942-A',
      notes: 'Inspected frame density—constructed with high-grade cured cypress and mahogany feet. Upholstery is genuine top grain leather, smells fresh, no standard synthetic tears or loose tufts.',
      outcome: 'Verified',
      submittedAt: '2026-06-12T09:15:00Z'
    },
    verifiedAt: '2026-06-12T09:15:00Z',
    expiresAt: '2026-08-11T09:15:00Z',
    bulkPlanSubscribed: 'GROWTH',
    isFeatured: true
  },
  {
    id: 'PROD-3891',
    title: 'Sany Heavy Duty Excavator SY215C (Excellent Technical Grade)',
    category: 'Machinery & Tools',
    price: 6800000,
    description: 'Heavy duty commercial crawler excavator. Features powerful Sany mechanical arm, hydraulic seal kit with high operational pressure, and high-performance diesel engine. Perfect for commercial construction sites.',
    sellerHandle: '@machinery_solutions_east_africa',
    sellerPhone: '254711999999',
    verificationStatus: 'UNVERIFIED',
    bulkPlanSubscribed: 'NONE',
    isFeatured: false
  }
];

const REVIEW_TEMPLATES: Record<string, { author: string; rating: number; comment: string; date: string }[]> = {
  'PROD-7102': [
    { author: 'Kamau N.', rating: 5, comment: 'Excellent Probox! The mechanical checks were highly detailed and the car drives wonderfully.', date: '3 days ago' },
    { author: 'Mumo J.', rating: 4, comment: 'Accurate odometer reading, verified physically. Good transparency.', date: '1 week ago' }
  ],
  'PROD-2900': [
    { author: 'Jane W.', rating: 5, comment: 'Perfect condition. Face ID is fast and screen looks completely brand new. Thank you!', date: '2 days ago' },
    { author: 'Dennis K.', rating: 5, comment: 'Delivered via Fargo Courier in under 3 hours, money was kept in escrow until I checked FaceID.', date: '5 days ago' }
  ],
  'PROD-3891': [
    { author: 'Otieno P.', rating: 4, comment: 'Solid machinery, currently awaiting trust inspector clearance.', date: '2 weeks ago' }
  ],
  'PROD-9031': [
    { author: 'Alice M.', rating: 5, comment: 'Incredible top-grain leather! The deep tufts look even better in person. Very happy with the escrow security.', date: '10 days ago' }
  ]
};

interface TrustPortalProps {
  transactions: Transaction[];
  onRefresh: () => void;
  onUpdateTransaction: (tx: Transaction) => void;
  activeSimulatedDomain: string;
  setActiveSimulatedDomain: (domain: string) => void;
  onOpenOpsPortal: () => void;
}

export default function TrustPortal({ 
  transactions, 
  onRefresh, 
  onUpdateTransaction,
  activeSimulatedDomain,
  setActiveSimulatedDomain,
  onOpenOpsPortal
}: TrustPortalProps) {
  
  // www.buysafely.africa sub-routing tabs & URL simulated paths
  const [publicPage, setPublicPage] = useState<'home' | 'how' | 'buyers' | 'sellers' | 'logistics' | 'verification' | 'support' | 'partners' | 'about'>('home');
  const [simulatedPath, setSimulatedPath] = useState<string>('');
  const [safeBuyLinkInput, setSafeBuyLinkInput] = useState<string>('');
  const [allProducts, setAllProducts] = useState<VerifiedProduct[]>([]);
  
  // Smart Merchant Cart States
  const [cartItems, setCartItems] = useState<{ product: VerifiedProduct; quantity: number; insured?: boolean }[]>([]);
  const [showCartDrawer, setShowCartDrawer] = useState(false);
  const [insuranceStructure, setInsuranceStructure] = useState<'ORDER' | 'ITEM'>('ORDER');
  const [orderInsuranceOption, setOrderInsuranceOption] = useState<'BASIC' | 'ENHANCED' | 'NONE'>('BASIC');
  const [shippingPackageStructure, setShippingPackageStructure] = useState<'SINGLE' | 'STAGGERED'>('SINGLE');
  const [cartToast, setCartToast] = useState<string | null>(null);
  const [checkoutReviewCompleted, setCheckoutReviewCompleted] = useState(false);

  // Auto reset checkout review status on path change
  useEffect(() => {
    setCheckoutReviewCompleted(false);
    setCheckoutError('');
  }, [simulatedPath]);
  
  // Checkout Interactive states
  const [checkoutForm, setCheckoutForm] = useState({
    quantity: 1,
    delivery: 'Courier',
    insurance: 'BASIC',
    phone: '',
    name: '',
    county: 'Nairobi',
    town: 'Kilimani',
    address: 'George Padmore Road'
  });
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);
  const [checkoutMpesaPin, setCheckoutMpesaPin] = useState('');
  const [showCheckoutPrompt, setShowCheckoutPrompt] = useState(false);
  const [checkoutError, setCheckoutError] = useState('');
  
  // Shopping Cart Utilities
  const handleAddToCart = (product: VerifiedProduct) => {
    const firstItem = cartItems[0];
    if (firstItem && firstItem.product.sellerHandle !== product.sellerHandle) {
      if (confirm(`Your shopping cart contains items from ${firstItem.product.sellerHandle}. Do you want to clear your cart and start a new cart with items from ${product.sellerHandle}?`)) {
        setCartItems([{ product, quantity: 1, insured: true }]);
        setCartToast(`Started new cart with ${product.title}`);
        setTimeout(() => setCartToast(null), 3000);
      }
      return;
    }

    const existingIndex = cartItems.findIndex(item => item.product.id === product.id);
    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += 1;
      setCartItems(updated);
    } else {
      setCartItems([...cartItems, { product, quantity: 1, insured: true }]);
    }
    setCartToast(`Added ${product.title} to Cart`);
    setTimeout(() => setCartToast(null), 3000);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCartItems(cartItems.filter(item => item.product.id !== productId));
  };

  const handleUpdateCartQty = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCartItems(cartItems.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };

  const handleToggleItemInsurance = (productId: string) => {
    setCartItems(cartItems.map(item => item.product.id === productId ? { ...item, insured: !item.insured } : item));
  };
  
  // Start Selling View modes
  const [sellerMode, setSellerMode] = useState<'selection' | 'register' | 'login'>('selection');
  
  // Product creation form in Merchant Portal
  const [productForm, setProductForm] = useState({
    title: '',
    price: '',
    category: 'Electronics & Gadgets' as any,
    description: ''
  });
  const [productCreateSuccess, setProductCreateSuccess] = useState(false);
  const [copiedLinkId, setCopiedLinkId] = useState<string | null>(null);

  // Simulated Escrow ID mapper
  const formatEscrowId = (txId: string) => {
    const num = txId.replace(/[^0-9]/g, '');
    const padded = num.padStart(8, '0');
    return `BS-ESC-2026-${padded || '00001245'}`;
  };

  // Onboarding & Flow states
  const [newSeller, setNewSeller] = useState({ name: '', phone: '', social: '' });
  const [kycStep, setKycStep] = useState(0); // 0=idle, 1=AML, 2=Trust, 3=done
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [selectedMerchantId, setSelectedMerchantId] = useState('MCH-001');

  // Support Track & Disputing states
  const [trackId, setTrackId] = useState('');
  const [selectedTrackTx, setSelectedTrackTx] = useState<Transaction | null>(null);
  const [supportSearch, setSupportSearch] = useState('');
  const [faqOpen, setFaqOpen] = useState<number | null>(null);
  const [disputeForm, setDisputeForm] = useState({ escrowId: '', reason: '', evidence: '' });
  const [disputeSuccess, setDisputeSuccess] = useState(false);

  // Link Builder state
  const [linkBuilder, setLinkBuilder] = useState({ title: '', price: 1000, buyerPhone: '254711223344', shipping: 300 });
  const [generatedLink, setGeneratedLink] = useState('');

  // Social product import state
  const [socialUrl, setSocialUrl] = useState('');
  const [socialResult, setSocialResult] = useState<any | null>(null);
  const [isExtracting, setIsExtracting] = useState(false);

  // Logistics joining states
  const [riderForm, setRiderForm] = useState({ name: '', Phone: '', Plate: '', nId: '' });
  const [joinSuccess, setJoinSuccess] = useState(false);

  // Picker inspection assignment lists
  const [inspections, setInspections] = useState<any[]>([
    { id: 'PROD-2900', title: 'Apple iPhone 15 Pro Max (Titanium Blue)', price: 'KSh 142,000', seller: '@apple_resellers_ke', status: 'PENDING_INSPECTION' },
    { id: 'PROD-7102', title: 'Toyota Probox KCK 489Y (White Edition)', price: 'KSh 840,000', seller: '@probox_deals_kenya', status: 'VERIFIED' }
  ]);

  // Sync state
  const fetchMerchants = async () => {
    try {
      const res = await fetch('/api/merchants');
      if (res.ok) setMerchants(await res.json());
    } catch (e) {
      console.error(e);
    }
  };

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/verified-products');
      if (res.ok) setAllProducts(await res.json());
    } catch (e) {
      console.error(e);
    }
  };

  const getProductById = (id: string) => {
    const cleanId = id.toUpperCase().trim();
    const foundDemo = DEMO_PRODUCTS.find(p => p.id === cleanId || p.id.replace('PROD-', '') === cleanId || p.id === `PROD-${cleanId}`);
    if (foundDemo) return foundDemo;
    return allProducts.find(p => p.id === cleanId || p.id.replace('PROD-', '') === cleanId || p.id === `PROD-${cleanId}` || p.id === `BS-PRD-${cleanId}` || p.id.replace('BS-PRD-', '') === cleanId);
  };

  useEffect(() => {
    fetchMerchants();
    fetchProducts();
    const timer = setInterval(() => {
      fetchMerchants();
      fetchProducts();
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Sync selected track tx when transactions update
  useEffect(() => {
    if (selectedTrackTx) {
      const updated = transactions.find(t => t.id === selectedTrackTx.id || formatEscrowId(t.id) === selectedTrackTx.id);
      if (updated) setSelectedTrackTx(updated);
    }
  }, [transactions]);

  // Handle support track lookup
  const handleTrackLookup = (id: string) => {
    const cleanId = id.trim();
    if (!cleanId) return;
    const match = transactions.find(t => t.id === cleanId || formatEscrowId(t.id) === cleanId || t.buyerPhone.includes(cleanId) || t.sellerPhone.includes(cleanId));
    if (match) setSelectedTrackTx(match);
    else alert('No transaction found matching that ID or Mobile number.');
  };

  // Merchant creation
  const handleRegisterMerchant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSeller.name || !newSeller.phone) return;
    setKycStep(1);
    await new Promise(r => setTimeout(r, 1200));
    setKycStep(2);
    await new Promise(r => setTimeout(r, 1200));
    setKycStep(3);

    try {
      const res = await fetch('/api/merchants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newSeller.name, phone: newSeller.phone, socialMediaPage: newSeller.social || 'instagram.com/shop' })
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedMerchantId(data.merchant.id);
        fetchMerchants();
        setActiveSimulatedDomain('merchant.buysafely.africa');
        setNewSeller({ name: '', phone: '', social: '' });
        setKycStep(0);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Generate safe buy link
  const handleGenerateLink = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          buyerPhone: linkBuilder.buyerPhone,
          sellerPhone: '254711334455',
          sellerHandle: '@trendy_merchant_ke',
          socialPlatform: 'Instagram',
          amount: Number(linkBuilder.price),
          description: linkBuilder.title,
          shippingMethod: 'Courier',
          shippingFee: Number(linkBuilder.shipping),
          totalAmount: Number(linkBuilder.price) + Number(linkBuilder.shipping) + 12
        })
      });
      if (res.ok) {
        const tx = await res.json();
        setGeneratedLink(`https://${activeSimulatedDomain}/pay/${formatEscrowId(tx.id)}`);
        onRefresh();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Import social product
  const handleSocialImport = async () => {
    if (!socialUrl) return;
    setIsExtracting(true);
    try {
      const res = await fetch('/api/social-extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: socialUrl })
      });
      if (res.ok) {
        const data = await res.json();
        setSocialResult(data);
        setLinkBuilder({
          title: data.name || 'Social Product',
          price: data.price || 1500,
          buyerPhone: '254711223344',
          shipping: 250
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsExtracting(false);
    }
  };

  // Rider register
  const handleRiderRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setJoinSuccess(true);
    setTimeout(() => setJoinSuccess(false), 3000);
    setRiderForm({ name: '', Phone: '', Plate: '', nId: '' });
  };

  // File Dispute
  const handleFileDispute = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanId = disputeForm.escrowId.trim();
    const match = transactions.find(t => t.id === cleanId || formatEscrowId(t.id) === cleanId);
    if (match) {
      try {
        const res = await fetch(`/api/transactions/${match.id}/dispute`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reason: disputeForm.reason })
        });
        if (res.ok) {
          setDisputeSuccess(true);
          onRefresh();
          setTimeout(() => {
            setDisputeSuccess(false);
            setDisputeForm({ escrowId: '', reason: '', evidence: '' });
          }, 3000);
        }
      } catch (err) {
        alert('Dispute submission error: ' + err);
      }
    } else {
      alert('Could not find active Escrow transaction matching this ID.');
    }
  };

  const activeMerchant = merchants.find(m => m.id === selectedMerchantId) || merchants[0] || {
    id: 'MCH-001', businessName: 'Trendy Store Nairobi', sellerHandle: '@trendystore_ke', phone: '254711221122', email: 'merchants@buysafely.africa', onboardingStep: 'VERIFIED', volumeKsh: 345000, trustRating: 98
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col text-slate-100 min-h-[720px] font-sans">
      
      {/* VIRTUAL BROWSER CHROME HUD */}
      <div className="bg-slate-950 px-5 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 select-none">
        
        {/* Browser Indicators */}
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-500/85"></span>
            <span className="w-3 h-3 rounded-full bg-amber-500/85"></span>
            <span className="w-3 h-3 rounded-full bg-emerald-500/85"></span>
          </div>
          <span className="text-[10px] bg-slate-905 px-2 py-0.5 rounded text-slate-500 font-mono font-bold tracking-wider ml-1">
            ECOSYSTEM CONTROLLER
          </span>
        </div>

        {/* Browser Address Input Box */}
        <div className="flex-1 max-w-xl">
          <div className="bg-slate-900 border border-slate-800/80 rounded-xl px-4 py-1.5 flex items-center justify-between gap-2.5 text-xs">
            <div className="flex items-center gap-1.5 text-slate-400 overflow-x-auto scrollbar-none">
              <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="text-emerald-400 font-semibold font-mono shrink-0">https://</span>
              <span className="text-slate-200 font-mono font-bold shrink-0">{activeSimulatedDomain}</span>
              {activeSimulatedDomain === 'www.buysafely.africa' && simulatedPath && (
                <span className="text-emerald-300 font-mono font-semibold shrink-0">{simulatedPath}</span>
              )}
            </div>
            <div className="flex gap-1 items-center shrink-0">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider">LIVE</span>
            </div>
          </div>
        </div>

        {/* Change Platform Mock Address Select */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500 font-mono font-medium hidden md:inline">Jump Channel:</span>
          <select 
            value={activeSimulatedDomain}
            onChange={(e) => {
              setActiveSimulatedDomain(e.target.value);
              if (e.target.value === 'ops.buysafely.africa') onOpenOpsPortal();
            }}
            className="bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg text-xs px-2.5 py-1 text-white font-mono cursor-pointer outline-none focus:border-emerald-500 transition-colors"
          >
            <option value="www.buysafely.africa">🌐 www.buysafely.africa (Enterprise Portal)</option>
            <option value="merchant.buysafely.africa">🛍️ merchant.buysafely.africa (Sellers)</option>
            <option value="courier.buysafely.africa">🏍️ courier.buysafely.africa (Riders)</option>
            <option value="verify.buysafely.africa">🔍 verify.buysafely.africa (Verification)</option>
            <option value="help.buysafely.africa">❓ help.buysafely.africa (Help Centre)</option>
            <option value="ops.buysafely.africa">⚙️ ops.buysafely.africa (Protected Ops)</option>
          </select>
        </div>
      </div>

      {/* RENDER CHANNELS */}
      <div className="flex-1 bg-slate-950 flex flex-col justify-between">
        
        {/* ========================================== */}
        {/* MAIN CANONICAL WEBSITE PORTAL: www.buysafely.africa */}
        {/* ========================================== */}
        {activeSimulatedDomain === 'www.buysafely.africa' && (
          <div className="flex-1 flex flex-col justify-between">
            
            {/* TOP NAVIGATION HEADER */}
            <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex justify-between items-center flex-wrap gap-4">
              <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setPublicPage('home')}>
                <div className="w-8.5 h-8.5 bg-emerald-500 rounded-xl flex items-center justify-center text-slate-950 shadow-md">
                  <ShieldCheck className="w-5.5 h-5.5" />
                </div>
                <div className="text-left">
                  <span className="text-white font-black tracking-tight text-md">BUY SAFELY</span>
                  <span className="text-[9px] text-slate-400 block tracking-widest font-mono font-bold leading-none">TRUST GATEWAY</span>
                </div>
              </div>

              {/* Navigation Items (STRICTLY CORRESPONDS TO USER PILOTS) */}
              <div className="flex-wrap flex items-center gap-4.5 text-xs text-slate-400 font-semibold">
                {[
                  { tag: 'home', text: 'Home' },
                  { tag: 'how', text: 'How It Works' },
                  { tag: 'buyers', text: 'Buyers' },
                  { tag: 'sellers', text: 'Sellers' },
                  { tag: 'logistics', text: 'Logistics' },
                  { tag: 'verification', text: 'Verification' },
                  { tag: 'support', text: 'Support' },
                  { tag: 'partners', text: 'Partners' },
                  { tag: 'about', text: 'About Us' }
                ].map(nav => (
                  <button 
                    key={nav.tag}
                    onClick={() => {
                      setSimulatedPath('');
                      setPublicPage(nav.tag as any);
                    }}
                    className={`hover:text-emerald-400 transition-colors uppercase tracking-wider text-[11px] cursor-pointer ${
                      publicPage === nav.tag && !simulatedPath ? 'text-emerald-400 font-black border-b border-emerald-500 pb-0.5' : ''
                    }`}
                  >
                    {nav.text}
                  </button>
                ))}
              </div>

              {/* Strict Corporate Login Menu Selection */}
              <div className="relative group">
                <button className="bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/20 text-xs px-4 py-2 rounded-xl transition-all duration-150 flex items-center gap-1.5 font-bold cursor-pointer">
                  <span>Login Gateway</span>
                  <span className="text-[8px]">▼</span>
                </button>
                <div className="absolute right-0 mt-2 w-52 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-2 space-y-1.5 z-50 hidden group-hover:block text-left text-xs">
                  <div className="text-[9px] text-slate-500 font-mono tracking-widest px-2.5 py-1 border-b border-slate-800">SECURE ENDPOINTS</div>
                  
                  <button onClick={() => { setSimulatedPath(''); setActiveSimulatedDomain('help.buysafely.africa'); setPublicPage('support'); }} className="w-full text-left px-2.5 py-1.5 hover:bg-slate-800 rounded-lg text-slate-300 hover:text-white flex items-center justify-between transition-colors">
                    <span>Buyer Support</span>
                    <span className="text-[9.5px] font-mono text-slate-500">help.</span>
                  </button>
                  
                  <button onClick={() => { setSimulatedPath(''); setActiveSimulatedDomain('merchant.buysafely.africa'); }} className="w-full text-left px-2.5 py-1.5 hover:bg-slate-800 rounded-lg text-slate-200 hover:text-white flex items-center justify-between font-bold transition-colors">
                    <span>Merchant Portal</span>
                    <span className="text-[9.5px] font-mono text-emerald-400">merchant.</span>
                  </button>
                  
                  <button onClick={() => { setSimulatedPath(''); setActiveSimulatedDomain('courier.buysafely.africa'); }} className="w-full text-left px-2.5 py-1.5 hover:bg-slate-800 rounded-lg text-slate-300 hover:text-white flex items-center justify-between transition-colors">
                    <span>Courier Portal</span>
                    <span className="text-[9.5px] font-mono text-amber-500">courier.</span>
                  </button>
                  
                  <button onClick={() => { setSimulatedPath(''); setActiveSimulatedDomain('verify.buysafely.africa'); }} className="w-full text-left px-2.5 py-1.5 hover:bg-slate-800 rounded-lg text-slate-300 hover:text-white flex items-center justify-between transition-colors">
                    <span>Picker Portal</span>
                    <span className="text-[9.5px] font-mono text-sky-400">verify.</span>
                  </button>

                  <div className="border-t border-slate-800/80 pt-1.5 mt-1.5">
                    <button onClick={() => { setSimulatedPath(''); onOpenOpsPortal(); }} className="w-full text-left px-2.5 py-1.5 hover:bg-red-950/20 rounded-lg text-red-400 hover:text-white font-bold flex items-center justify-between transition-colors">
                      <span>Operations Portal</span>
                      <span className="text-[9px] bg-red-950 text-red-500 px-1 py-0.5 rounded font-mono">ops.</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* HIGH END BANNER: PRODUCTION SIMULATION ENVIRONMENT */}
            <div className="bg-gradient-to-r from-amber-500/10 via-slate-900 to-amber-500/10 border-y border-slate-800/60 px-6 py-2.5 text-center flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              <p className="text-[11px] text-slate-200 font-mono font-medium">
                <span className="text-amber-400 font-bold">Production Simulation Environment:</span> This environment demonstrates real Buy Safely workflows using simulated transactions. No actual funds are transferred.
              </p>
            </div>

            {/* ==================== SUB-PAGE SWITCH ENGINE ==================== */}
            <div className="flex-1">

              {/* 1. HOMEPAGE VIEW */}
              {publicPage === 'home' && (
                <div className="text-center">
                  
                  {/* Hero banner section */}
                  <div className="px-6 py-16 bg-gradient-to-b from-slate-900 to-slate-950 border-b border-slate-800/50 relative overflow-hidden">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
                    
                    <div className="max-w-3xl mx-auto space-y-6 relative z-10">
                      <span className="inline-flex items-center gap-1.5 bg-emerald-400/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono font-bold tracking-widest px-4 py-1 rounded-full uppercase">
                        🛡️ Licensed Escrow Trustee Gateway
                      </span>
                      
                      <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight uppercase">
                        Buy Safely. <br />
                        <span className="text-emerald-400">The Trusted Way to Buy and Sell Online.</span>
                      </h1>
                      
                      <p className="text-slate-300 text-sm md:text-md leading-relaxed max-w-2xl mx-auto font-sans">
                        Protecting buyers, sellers and logistics partners through secure escrow payments, verified delivery and dispute resolution. Settled under NCBA Trusteeship.
                      </p>

                      <div className="flex flex-wrap justify-center gap-4.5 pt-3">
                        <button onClick={() => setPublicPage('buyers')} className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black uppercase tracking-wider px-6.5 py-3.5 rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer">
                          Start Buying
                        </button>
                        <button onClick={() => setPublicPage('sellers')} className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-black uppercase tracking-wider px-6.5 py-3.5 rounded-xl border border-slate-850 transition-colors cursor-pointer">
                          Start Selling
                        </button>
                      </div>

                      <div className="flex flex-wrap justify-center gap-6 pt-4 text-xs font-semibold text-slate-400">
                        <button onClick={() => { setPublicPage('support'); setTimeout(() => { const el = document.getElementById('support-track-box'); if (el) el.scrollIntoView({ behavior: 'smooth' }); }, 100); }} className="hover:text-emerald-400 flex items-center gap-1.5 cursor-pointer">
                          🔍 Track Escrow Transaction
                        </button>
                        <span>•</span>
                        <button onClick={() => setPublicPage('support')} className="hover:text-emerald-400 flex items-center gap-1.5 cursor-pointer">
                          ✉️ Contact Dispute Support
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* 2. TRUST BAR */}
                  <div className="bg-slate-950 py-10 border-b border-slate-800 text-slate-100">
                    <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest text-center mb-6">INTEGRATED ESCROW COMPLIANCE BENCHMARKS</p>
                    <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-4 px-6 text-center">
                      {[
                        { title: 'Escrow Protected', d: 'Secure trust fund custody until release', icon: '🔒' },
                        { title: 'M-Pesa Integrated', d: 'Instant Daraja STK Push deposits', icon: '📲' },
                        { title: 'Verified Merchants', d: 'Mandatory anti-fraud company checks', icon: '🏢' },
                        { title: 'Dispute Resolution', d: 'Dedicated 24-hour supervisor panel', icon: '⚖️' },
                        { title: 'Fraud Monitoring', d: 'Automated ML transaction scans', icon: '🛡️' }
                      ].map((item, i) => (
                        <div key={i} className="p-4 bg-slate-900/60 border border-slate-800 rounded-2xl flex flex-col items-center">
                          <span className="text-xl mb-1.5">{item.icon}</span>
                          <strong className="text-white text-xs uppercase block">{item.title}</strong>
                          <span className="text-[10.5px] text-slate-400 mt-1 leading-tight block">{item.d}</span>
                        </div>
                      ))}
                    </div>

                    {/* Partner logos */}
                    <div className="mt-10 flex flex-wrap justify-center items-center gap-10 opacity-50 px-6 max-w-4xl mx-auto">
                      <span className="text-[11px] font-mono text-slate-500 tracking-wider">OFFICIAL SYSTEM PARTNERS:</span>
                      <strong className="font-mono text-xs text-slate-300">🏦 NCBA TRUST BANK</strong>
                      <strong className="font-mono text-xs text-emerald-400">📲 SAFARICOM DARAJA</strong>
                      <strong className="font-mono text-xs text-red-400">🔴 AIRTEL MONEY</strong>
                      <strong className="font-mono text-xs text-blue-400">⚖️ CBK FINTECH SANDBOX</strong>
                    </div>
                  </div>

                  {/* 3. HOW IT WORKS FLOW DIAGRAM */}
                  <div className="py-16 px-6 bg-slate-900/10 border-b border-slate-800">
                    <div className="max-w-4xl mx-auto text-center space-y-3 mb-10">
                      <span className="text-[10px] font-mono text-emerald-400 tracking-widest uppercase block font-bold">THE ESCROW PROTECTION ENGINE</span>
                      <h2 className="text-2xl font-black text-white uppercase">System Flow Mechanics</h2>
                      <p className="text-xs text-slate-400 max-w-xl mx-auto">See how we secure payments and protect capital during social-commerce deals.</p>
                    </div>

                    {/* Step Visual Block */}
                    <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-5 gap-3.5 text-left">
                      {[
                        { step: '01', title: 'Buyer Places Order', desc: 'Secure checkout URL handles payment specifications.' },
                        { step: '02', title: 'Funds Held in Escrow', desc: 'Safaricom STK deposit coordinates are held in cold bank vaults.' },
                        { step: '03', title: 'Seller Ships Order', desc: 'Assigned courierwaybill checks or pickers authenticate package.' },
                        { step: '04', title: 'Delivery Confirmed', desc: 'Buyer confirms package arrives safely and shares OTP pin.' },
                        { step: '05', title: 'Funds Released', desc: 'Blocked balances disburse to the seller account instantly.' }
                      ].map((obj, index) => (
                        <div key={index} className="bg-slate-900 border border-slate-800 p-4.5 rounded-2xl relative">
                          <span className="absolute top-4 right-4 text-xs font-mono font-bold text-emerald-400 bg-emerald-400/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                            {obj.step}
                          </span>
                          <h4 className="text-xs font-extrabold uppercase text-slate-200 mt-2 mb-1.5">{obj.title}</h4>
                          <p className="text-[11.5px] text-slate-400 leading-relaxed">{obj.desc}</p>
                          {index < 4 && (
                            <span className="hidden md:block absolute -right-3.5 top-1/2 -translate-y-1/2 text-slate-700 z-10 text-xs">▶</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 4. WHO USES BUY SAFELY (GRID PORTAL CARDS) */}
                  <div className="py-16 px-6 max-w-5xl mx-auto text-left space-y-8">
                    <div className="text-center space-y-2">
                      <span className="text-[10px] font-mono text-emerald-400 tracking-widest uppercase">ECOSYSTEM ENTRANCES</span>
                      <h2 className="text-2xl font-black text-white uppercase">Who Uses Buy Safely?</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 flex flex-col justify-between">
                        <div>
                          <span className="text-2xl font-mono">🛒</span>
                          <h3 className="text-sm font-bold uppercase text-slate-200 mt-1">Buyers</h3>
                          <p className="text-[11px] text-slate-400 leading-normal">
                            Protected shopping. Secure capital lock-up when checking out on Instagram, TikTok, or WhatsApp.
                          </p>
                        </div>
                        <button onClick={() => setPublicPage('buyers')} className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1">
                          Browse Buyers Guide <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 flex flex-col justify-between">
                        <div>
                          <span className="text-2xl font-mono">🛍️</span>
                          <h3 className="text-sm font-bold uppercase text-slate-200 mt-1">Sellers</h3>
                          <p className="text-[11px] text-slate-400 leading-normal">
                            Secure payment locks, automated invoice building, M-Pesa business till handshakes.
                          </p>
                        </div>
                        <button onClick={() => setPublicPage('sellers')} className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1">
                          Access Merchant Funnel <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 flex flex-col justify-between">
                        <div>
                          <span className="text-2xl font-mono">🏍️</span>
                          <h3 className="text-sm font-bold uppercase text-slate-200 mt-1">Couriers</h3>
                          <p className="text-[11px] text-slate-400 leading-normal">
                            Steady dispatch opportunities, secure delivery fees, automatic payout settlement release.
                          </p>
                        </div>
                        <button onClick={() => setPublicPage('logistics')} className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1">
                          Join Rider Logistics <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 flex flex-col justify-between">
                        <div>
                          <span className="text-2xl font-mono">🔍</span>
                          <h3 className="text-sm font-bold uppercase text-slate-200 mt-1">Pickers</h3>
                          <p className="text-[11px] text-slate-400 leading-normal">
                            Conduct physical product testing, check serial registries, and earn auditing premiums.
                          </p>
                        </div>
                        <button onClick={() => setPublicPage('verification')} className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1">
                          Apply as Auditor <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 flex flex-col justify-between md:col-span-2">
                        <div>
                          <span className="text-2xl font-mono">🏦</span>
                          <h3 className="text-sm font-bold uppercase text-slate-200 mt-1">Financial Enterprise Partners</h3>
                          <p className="text-[11px] text-slate-400 leading-normal">
                            Enabling banks, Payment Service Providers (PSPs), regulators, and insurances to clear high-fidelity escrow reserves.
                          </p>
                        </div>
                        <button onClick={() => setPublicPage('partners')} className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1">
                          View Bank Trustee Specs <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                </div>
              )}

              {/* 2. HOW IT WORKS PAGE DESCRIPTION */}
              {publicPage === 'how' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-8 text-left">
                  <div className="space-y-2 border-b border-slate-800 pb-5">
                    <span className="text-emerald-400 font-mono text-[10px] tracking-widest uppercase">REGULATORY PROTOCOL</span>
                    <h2 className="text-2xl font-black text-white uppercase">Escrow Release Standards & Framework</h2>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Escrows are blocked in physical trustee bank reserves of NCBA Kenya, operating under standard Central Bank Sandbox audits to protect consumers.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
                      <h3 className="text-xs uppercase font-extrabold text-emerald-400">Deposit Rules</h3>
                      <p className="text-xs text-slate-300 leading-relaxed font-sans">
                        When transactions initiate, buyers submit their deposit using mobile wallets via Daraja secure STK push. The funds lock under NCBA Bank Custody. 
                        Sellers cannot access the funds, nor can they cancel. Buyer holds absolute capital security.
                      </p>
                    </div>

                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
                      <h3 className="text-xs uppercase font-extrabold text-emerald-400">Release Milestones</h3>
                      <p className="text-xs text-slate-300 leading-relaxed font-sans">
                        Locked escrows release to the merchant's wallet ONLY when:
                        <br />• Buyer inputs their Delivery OTP via SMS callback.
                        <br />• Fargo Courier audits waybill telemetry confirming handover.
                        <br />• Assigned Picker completes a successful physical audit report.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Custom Cart Page Route */}
              {simulatedPath === '/cart' && (() => {
                const subtotal = cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
                const shippingFee = shippingPackageStructure === 'SINGLE' ? 300 : 500;
                const platformFee = Math.max(Math.round(subtotal * 0.01), 25);
                const insurancePremium = insuranceStructure === 'ORDER'
                  ? (orderInsuranceOption === 'BASIC' ? 450 : orderInsuranceOption === 'ENHANCED' ? 1200 : 0)
                  : cartItems.reduce((acc, item) => acc + (item.insured ? 150 * item.quantity : 0), 0);
                const totalAmount = subtotal + shippingFee + platformFee + insurancePremium;

                return (
                  <div className="max-w-4xl mx-auto px-6 py-10 space-y-8 text-left animate-fade-in font-sans">
                    {/* Back Link */}
                    <button 
                      onClick={() => { setSimulatedPath(''); setPublicPage('buyers'); }}
                      className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
                    >
                      ← Back to Safe Shopping Hub
                    </button>

                    <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                      <div>
                        <span className="text-emerald-400 font-mono text-[9.5px] uppercase tracking-wider">NCBA Trustee Escrow Ecosystem</span>
                        <h2 className="text-xl sm:text-2xl font-black text-white uppercase flex items-center gap-2">
                          <Package className="w-6 h-6 text-emerald-400" /> Shopping Cart
                        </h2>
                      </div>
                      <span className="text-xs bg-slate-900 px-3 py-1.5 border border-slate-800 text-slate-400 font-mono rounded-lg">
                        SELLER: <strong className="text-emerald-400 font-bold">{cartItems[0]?.product.sellerHandle || 'N/A'}</strong>
                      </span>
                    </div>

                    {cartItems.length === 0 ? (
                      <div className="bg-slate-900 border border-slate-800 p-12 rounded-2xl text-center space-y-4">
                        <Package className="w-16 h-16 text-slate-600 mx-auto" />
                        <h3 className="text-md font-bold text-white uppercase">Your Shopping Cart is Empty</h3>
                        <p className="text-xs text-slate-400">Add verified escrow products from Nairobi merchants to start secure transactions.</p>
                        <button 
                          onClick={() => { setSimulatedPath(''); setPublicPage('buyers'); }} 
                          className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase text-xs px-6 py-3 rounded-xl transition-all cursor-pointer"
                        >
                          Browse Merchant Storefront
                        </button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                        {/* Cart Items List */}
                        <div className="lg:col-span-7 space-y-4">
                          <h3 className="text-xs font-bold uppercase text-white tracking-wider">Shopping Cart Items</h3>
                          
                          <div className="space-y-3">
                            {cartItems.map((item) => (
                              <div key={item.product.id} className="bg-slate-900 border border-slate-800/80 p-4 rounded-xl flex gap-4 items-center justify-between">
                                {/* Thumbnail */}
                                <div className="w-12 h-12 bg-slate-950 rounded-xl border border-slate-850 flex items-center justify-center text-emerald-400 flex-none relative overflow-hidden">
                                  <Package className="w-6 h-6" />
                                  <div className="absolute inset-x-0 bottom-0 bg-slate-900/90 text-[8px] font-mono text-center text-slate-400 border-t border-slate-800">
                                    {item.product.id}
                                  </div>
                                </div>

                                {/* Title & Price */}
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-bold text-white text-xs uppercase truncate">{item.product.title}</h4>
                                  <p className="text-[10px] text-emerald-400 font-mono font-bold mt-0.5">KSh {item.product.price.toLocaleString()}</p>
                                </div>

                                {/* Controls */}
                                <div className="flex items-center gap-3">
                                  {/* Qty Controls */}
                                  <div className="flex items-center bg-slate-950 border border-slate-850 rounded-lg p-1">
                                    <button 
                                      onClick={() => handleUpdateCartQty(item.product.id, item.quantity - 1)}
                                      className="w-5 h-5 flex items-center justify-center rounded text-xs text-slate-400 hover:text-white hover:bg-slate-800 font-mono cursor-pointer"
                                    >
                                      -
                                    </button>
                                    <span className="text-xs font-bold text-white font-mono w-5 text-center">{item.quantity}</span>
                                    <button 
                                      onClick={() => handleUpdateCartQty(item.product.id, item.quantity + 1)}
                                      className="w-5 h-5 flex items-center justify-center rounded text-xs text-slate-400 hover:text-white hover:bg-slate-800 font-mono cursor-pointer"
                                    >
                                      +
                                    </button>
                                  </div>

                                  {/* Total per item */}
                                  <span className="font-mono text-xs font-bold text-white w-20 text-right">
                                    KSh {(item.product.price * item.quantity).toLocaleString()}
                                  </span>

                                  {/* Delete */}
                                  <button 
                                    onClick={() => handleRemoveFromCart(item.product.id)}
                                    className="text-red-400 hover:text-red-350 transition-colors p-1 rounded hover:bg-slate-800 cursor-pointer"
                                    title="Remove item"
                                  >
                                    ✕
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>

                          {/* Order Logistics Configuration */}
                          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                            <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">Logistics & Protection Settings</h4>
                            
                            <div className="space-y-4 text-xs">
                              {/* Consolidated Package Option */}
                              <div className="space-y-1.5">
                                <span className="text-slate-400 font-mono text-[9.5px] uppercase tracking-wider block">Package Logistics Architecture:</span>
                                <div className="grid grid-cols-2 gap-3">
                                  <button 
                                    onClick={() => setShippingPackageStructure('SINGLE')}
                                    className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${shippingPackageStructure === 'SINGLE' ? 'bg-emerald-950/20 border-emerald-500 text-white' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                                  >
                                    <span className="font-extrabold text-[11px]">Consolidated Shipping</span>
                                    <span className="text-[9.5px] font-mono leading-none mt-1">1 Package • KSh 300 Courier</span>
                                  </button>
                                  <button 
                                    onClick={() => setShippingPackageStructure('STAGGERED')}
                                    className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${shippingPackageStructure === 'STAGGERED' ? 'bg-emerald-950/20 border-emerald-500 text-white' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                                  >
                                    <span className="font-extrabold text-[11px]">Staggered (Multi-Pack)</span>
                                    <span className="text-[9.5px] font-mono leading-none mt-1">Separate dispatches • KSh 500 Courier</span>
                                  </button>
                                </div>
                              </div>

                              {/* Insurance Options */}
                              <div className="space-y-1.5">
                                <span className="text-slate-400 font-mono text-[9.5px] uppercase tracking-wider block">Insurance Protection Premium:</span>
                                <div className="grid grid-cols-2 gap-3">
                                  <button 
                                    onClick={() => setInsuranceStructure('ORDER')}
                                    className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${insuranceStructure === 'ORDER' ? 'bg-emerald-950/20 border-emerald-500 text-white' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                                  >
                                    <span className="font-extrabold text-[11px]">Order Level Umbrella Cover</span>
                                    <span className="text-[9.5px] font-mono leading-none mt-1">KSh 450 Standard Premium</span>
                                  </button>
                                  <button 
                                    onClick={() => setInsuranceStructure('ITEM')}
                                    className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${insuranceStructure === 'ITEM' ? 'bg-emerald-950/20 border-emerald-500 text-white' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                                  >
                                    <span className="font-extrabold text-[11px]">Item Level Selective Cover</span>
                                    <span className="text-[9.5px] font-mono leading-none mt-1">KSh 150 per item (Configure below)</span>
                                  </button>
                                </div>
                              </div>

                              {insuranceStructure === 'ITEM' && (
                                <div className="space-y-2 p-3 bg-slate-950 border border-slate-850 rounded-xl">
                                  <span className="text-[9px] font-mono text-slate-500 block uppercase tracking-wider">Configure Insured Items:</span>
                                  {cartItems.map((item) => (
                                    <div key={item.product.id} className="flex justify-between items-center text-[11px]">
                                      <span className="text-slate-300 truncate max-w-[250px]">{item.product.title}</span>
                                      <button 
                                        onClick={() => handleToggleItemInsurance(item.product.id)}
                                        className={`px-2.5 py-1 rounded font-mono text-[9.5px] uppercase cursor-pointer ${item.insured ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/25' : 'bg-slate-900 text-slate-500 border border-slate-800'}`}
                                      >
                                        {item.insured ? 'Insured (KSh 150)' : 'Uncovered'}
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              )}

                              {insuranceStructure === 'ORDER' && (
                                <div className="space-y-1.5">
                                  <span className="text-slate-400 text-[10px] uppercase font-mono block">Order-Level Protection Plan:</span>
                                  <div className="grid grid-cols-3 gap-2 font-mono text-[10px]">
                                    {['NONE', 'BASIC', 'ENHANCED'].map((opt) => (
                                      <button 
                                        key={opt}
                                        onClick={() => setOrderInsuranceOption(opt as any)}
                                        className={`p-2.5 rounded-lg border text-center transition-all cursor-pointer ${orderInsuranceOption === opt ? 'bg-emerald-950/20 border-emerald-500 text-white font-bold' : 'bg-slate-950 border-slate-850 text-slate-500'}`}
                                      >
                                        {opt === 'NONE' ? 'None' : opt === 'BASIC' ? 'Basic (450)' : 'Enhanced (1200)'}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Cart Summary Card */}
                        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
                          <h3 className="text-xs font-bold uppercase text-white tracking-wider border-b border-slate-800 pb-2">Order Summary</h3>
                          
                          {/* Automatic Combined Shipping Message */}
                          {cartItems.length > 1 && (
                            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl space-y-1 text-xs">
                              <div className="flex items-center gap-1.5 font-bold font-mono">
                                <span>🚚</span>
                                <span>Combined Shipping Applied</span>
                              </div>
                              <p className="text-[10px] text-slate-350 leading-relaxed font-sans">
                                Products belong to the same merchant, pickup from same node, and deliver to the same address. Shipping rates have been consolidated.
                              </p>
                            </div>
                          )}

                          <div className="space-y-3.5 text-xs font-mono leading-relaxed">
                            <div className="flex justify-between">
                              <span className="text-slate-400">Cart Subtotal:</span>
                              <span className="text-slate-200 font-bold font-mono">KSh {subtotal.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Shipping & Logistics:</span>
                              <span className="text-slate-200 font-bold font-mono">KSh {shippingFee.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Escrow Insurance Premium:</span>
                              <span className="text-slate-200 font-bold font-mono">KSh {insurancePremium.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Service clearing fee (1%):</span>
                              <span className="text-slate-200 font-bold font-mono">KSh {platformFee.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Escrow account setup:</span>
                              <span className="text-emerald-400 font-bold">FREE (NCBA TRUST)</span>
                            </div>

                            <div className="border-t border-slate-800 pt-4 flex justify-between font-black text-white text-sm">
                              <span>TOTAL SECURED ESCROW:</span>
                              <span className="text-emerald-400 font-bold text-md font-mono">KSh {totalAmount.toLocaleString()}</span>
                            </div>
                          </div>

                          <button 
                            onClick={() => {
                              setSimulatedPath('/pay/cart');
                            }}
                            className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-4 rounded-xl text-xs tracking-wider transition-all cursor-pointer shadow-lg shadow-emerald-500/10 flex items-center justify-center gap-2"
                          >
                            <Lock className="w-4 h-4 text-slate-950" />
                            <span>Proceed to Escrow Checkout</span>
                          </button>

                          <div className="p-3 bg-slate-950/60 border border-slate-850 rounded-xl leading-normal text-slate-500 text-[10px] font-sans">
                            🛡️ <strong className="text-slate-400">Trade Guarantee</strong>: Under Kenya Escrow Trusteeship regulations, capital resides locked under NCBA Bank until Fargo waybill confirms delivery handover checks.
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Custom Product Detail Page Route */}
              {simulatedPath.startsWith('/p/') && (() => {
                const prodId = simulatedPath.replace('/p/', '');
                const product = getProductById(prodId);
                if (!product) {
                  return (
                    <div className="max-w-md mx-auto my-16 p-8 bg-slate-900 border border-slate-800 rounded-2xl text-center space-y-4">
                      <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto" />
                      <h3 className="text-lg font-bold text-white">PRODUCT NOT FOUND</h3>
                      <p className="text-xs text-slate-400">The product reference {prodId} does not exist or has expired.</p>
                      <button onClick={() => { setSimulatedPath(''); setPublicPage('buyers'); }} className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors">
                        Back to Buyer Hub
                      </button>
                    </div>
                  );
                }

                const reviews = REVIEW_TEMPLATES[product.id] || [];
                const isVerified = product.verificationStatus === 'VERIFIED';

                return (
                  <div className="max-w-4xl mx-auto px-6 py-10 space-y-8 text-left">
                    {/* Back Link */}
                    <button 
                      onClick={() => { setSimulatedPath(''); setPublicPage('buyers'); }}
                      className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
                    >
                      ← Back to Safe Shopping Hub
                    </button>

                    {/* Header Card */}
                    <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div className="space-y-1">
                        <span className="text-emerald-400 font-mono text-[9.5px] uppercase tracking-wider">{product.category}</span>
                        <h2 className="text-xl sm:text-2xl font-black text-white leading-tight uppercase">{product.title}</h2>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[10px] font-mono text-slate-400">PRODUCT ID:</span>
                          <span className="text-[10px] font-mono text-white font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">{product.id}</span>
                          {isVerified ? (
                            <span className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                              🛡️ Verified Trust Asset
                            </span>
                          ) : (
                            <span className="bg-amber-500/15 text-amber-400 border border-amber-500/20 text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                              ⚠️ Self-Listed Unverified
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-left md:text-right">
                        <span className="text-[10px] font-mono text-slate-500 block">TRUST VALUE VALUE</span>
                        <span className="text-2xl font-black text-emerald-400 font-mono">KSh {product.price.toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                      {/* Left Column: Product Details & Audits */}
                      <div className="lg:col-span-7 space-y-6">
                        {/* Description */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">Product Description</h4>
                          <p className="text-xs text-slate-300 leading-relaxed font-sans">{product.description}</p>
                        </div>

                        {/* Verification & Audit Report if verified */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">Physical Audit & Trust Scorecard</h4>
                          
                          {isVerified && product.verificationReport ? (
                            <div className="space-y-4 text-xs">
                              <div className="flex items-start gap-3 p-3 bg-slate-950 border border-slate-850 rounded-xl">
                                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                                <div className="space-y-1">
                                  <p className="font-bold text-white uppercase">Inspection Cleared & Certified</p>
                                  <p className="text-slate-400 text-[11px]">Audit successfully logged by {product.verificationReport.outcome} outcome.</p>
                                </div>
                              </div>

                              <div className="grid grid-cols-2 gap-3.5 text-[11px] leading-relaxed font-mono">
                                <div className="bg-slate-950 p-2.5 rounded border border-slate-850">
                                  <span className="text-slate-500 block text-[9px]">PHYSICAL CONDITION</span>
                                  <strong className="text-emerald-400 uppercase">{product.verificationReport.condition} Grade</strong>
                                </div>
                                <div className="bg-slate-950 p-2.5 rounded border border-slate-850">
                                  <span className="text-slate-500 block text-[9px]">FUNCTIONAL CLEARANCE</span>
                                  <strong className="text-emerald-400 uppercase">{product.verificationReport.functionalPass ? 'PASS 100%' : 'FAIL'}</strong>
                                </div>
                                <div className="bg-slate-950 p-2.5 rounded border border-slate-850 col-span-2">
                                  <span className="text-slate-500 block text-[9px]">SERIAL NUMBER / IMEI</span>
                                  <strong className="text-slate-200">{product.verificationReport.serialNumber || 'N/A'}</strong>
                                </div>
                              </div>

                              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-850 space-y-1.5 leading-relaxed text-slate-300 text-[11px]">
                                <span className="text-slate-500 font-mono text-[9px] block">AUDITOR NOTES</span>
                                <p className="font-sans italic">"{product.verificationReport.notes}"</p>
                                <div className="border-t border-slate-850 pt-2 mt-2 flex justify-between text-[9px] font-mono text-slate-500">
                                  <span>AUDITOR ID: {product.auditorId || 'DP-003'}</span>
                                  <span>LOG DATE: {new Date(product.verifiedAt || '').toLocaleDateString()}</span>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-3 py-2 text-xs">
                              <p className="text-slate-400 leading-relaxed font-sans">
                                This is a self-listed product and has <strong className="text-amber-400">not undergone physical verification</strong> by our auditors yet. 
                                Money will remain completely locked in escrow until you receive and approve the item.
                              </p>
                              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex gap-2 text-amber-400 font-mono text-[10px]">
                                <AlertTriangle className="w-4 h-4 shrink-0" />
                                <span>Always opt for verified products for maximum trade guarantee.</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right Column: Seller Profile, Reviews & CTAs */}
                      <div className="lg:col-span-5 space-y-6">
                        {/* Seller profile */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 text-xs">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">Ecosystem Seller Profile</h4>
                          <div className="space-y-2 leading-relaxed">
                            <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-850">
                              <span className="text-slate-400 font-mono text-[10px]">HANDLE:</span>
                              <strong className="text-white font-mono">{product.sellerHandle}</strong>
                            </div>
                            <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-850">
                              <span className="text-slate-400 font-mono text-[10px]">TRUST VERIFIED:</span>
                              <span className="bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded text-[9px] font-bold font-mono">KYC COMPLETE</span>
                            </div>
                            <div className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-850">
                              <span className="text-slate-400 font-mono text-[10px]">TILL INTERFACE:</span>
                              <span className="text-slate-200 font-mono font-bold">MPESA DARAJA OK</span>
                            </div>
                          </div>
                        </div>

                        {/* Customer Reviews */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3 text-xs">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">Trade Feedback & Ratings</h4>
                          <div className="space-y-3">
                            {reviews.length === 0 ? (
                              <p className="text-slate-500 italic py-2 text-center">No transaction logs recorded yet.</p>
                            ) : (
                              reviews.map((r, i) => (
                                <div key={i} className="bg-slate-950 border border-slate-850 p-3 rounded-xl space-y-1.5">
                                  <div className="flex justify-between items-center">
                                    <span className="font-bold text-slate-300 font-mono text-[11px]">{r.author}</span>
                                    <span className="text-slate-500 text-[10px]">{r.date}</span>
                                  </div>
                                  <div className="flex items-center text-amber-400 font-mono text-[10px]">
                                    {'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}
                                  </div>
                                  <p className="text-slate-400 font-sans text-[11px] leading-relaxed">"{r.comment}"</p>
                                </div>
                              ))
                            )}
                          </div>
                        </div>

                        {/* Secure Escrow Buy CTA Button */}
                        {(() => {
                          const mch = merchants.find(m => m.sellerHandle === product.sellerHandle);
                          const isCartEnabled = mch ? !!mch.cartEnabled : false;
                          return (
                            <div className="space-y-3">
                              {isCartEnabled && (
                                <button 
                                  onClick={() => handleAddToCart(product)}
                                  className="w-full bg-slate-800 hover:bg-slate-700 active:scale-[0.99] text-white font-extrabold uppercase py-3.5 rounded-2xl text-xs tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer border border-slate-700 shadow-md"
                                >
                                  <Package className="w-4 h-4 text-emerald-400" />
                                  <span>Add to Merchant Cart</span>
                                </button>
                              )}
                              <button 
                                onClick={() => {
                                  setCartItems([{ product, quantity: 1, insured: true }]);
                                  setSimulatedPath(`/pay/${product.id}`);
                                }}
                                className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-slate-950 font-extrabold uppercase py-3.5 rounded-2xl text-xs tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xl shadow-emerald-950/20"
                              >
                                <Lock className="w-4 h-4 text-slate-950" />
                                <span>Buy Safely via Escrow</span>
                              </button>
                            </div>
                          );
                        })()}
                        <p className="text-[10px] text-slate-500 text-center font-mono">
                          Protected by NCBA Trustee Escrow. Funds are not disbursed to the merchant until you confirm delivery.
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Custom Checkout Page Route */}
              {/* Custom Checkout Page Route */}
              {simulatedPath.startsWith('/pay/') && (() => {
                const prodId = simulatedPath.replace('/pay/', '');
                const isCartCheckout = prodId === 'cart';
                const product = isCartCheckout 
                  ? (cartItems.length > 0 ? {
                      id: 'cart',
                      title: `${cartItems[0].product.sellerHandle} Escrow Cart`,
                      price: cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0),
                      category: 'Mixed Store Cart',
                      description: `${cartItems.length} items from ${cartItems[0].product.sellerHandle}`,
                      sellerHandle: cartItems[0].product.sellerHandle,
                      sellerPhone: cartItems[0].product.sellerPhone,
                      sellerName: cartItems[0].product.sellerHandle,
                      images: cartItems[0].product.images,
                    } : null)
                  : getProductById(prodId);

                if (!product) {
                  return (
                    <div className="max-w-md mx-auto my-16 p-8 bg-slate-900 border border-slate-800 rounded-2xl text-center space-y-4">
                      <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto" />
                      <h3 className="text-lg font-bold text-white">CHECKOUT RESTRICTED</h3>
                      <p className="text-xs text-slate-400">Checkout pages cannot load without active Product ID and Merchant ID context. Please select a product first.</p>
                      <button onClick={() => { setSimulatedPath(''); setPublicPage('buyers'); }} className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors">
                        Back to Shop
                      </button>
                    </div>
                  );
                }

                // Calculate price math
                const qty = checkoutForm.quantity;
                const subtotal = isCartCheckout 
                  ? cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0)
                  : product.price * qty;

                const shippingFee = isCartCheckout 
                  ? (shippingPackageStructure === 'SINGLE' ? 300 : 500)
                  : (checkoutForm.delivery === 'Courier' ? 300 : checkoutForm.delivery === 'Rider' ? 150 : 0);

                const platformFee = Math.max(Math.round(subtotal * 0.01), 25);

                const insurancePremium = isCartCheckout 
                  ? (insuranceStructure === 'ORDER'
                      ? (orderInsuranceOption === 'BASIC' ? 450 : orderInsuranceOption === 'ENHANCED' ? 1200 : 0)
                      : cartItems.reduce((acc, item) => acc + (item.insured ? 150 * item.quantity : 0), 0))
                  : (checkoutForm.insurance === 'BASIC' ? 450 : checkoutForm.insurance === 'ENHANCED' ? 1200 : 0);

                const totalAmount = subtotal + shippingFee + platformFee + insurancePremium;

                const handlePlaceOrder = () => {
                  setCheckoutError('');
                  if (!checkoutForm.phone.trim()) {
                    setCheckoutError('Please enter your Safaricom mobile money phone number.');
                    return;
                  }
                  if (checkoutForm.phone.trim().replace(/[^0-9]/g, '').length < 9) {
                    setCheckoutError('Please enter a valid Safaricom phone number (e.g., 254711223344 or 0711223344).');
                    return;
                  }
                  if (!checkoutForm.name.trim()) {
                    setCheckoutError('Please enter your full recipient name.');
                    return;
                  }
                  if (!checkoutForm.address.trim()) {
                    setCheckoutError('Please enter your physical shipping address.');
                    return;
                  }

                  setShowCheckoutPrompt(true);
                };

                const handleConfirmMpesa = async () => {
                  if (!checkoutMpesaPin) {
                    alert('Please enter your simulated 4-digit mobile money PIN.');
                    return;
                  }
                  setIsProcessingCheckout(true);
                  // Simulate latency
                  await new Promise(r => setTimeout(r, 2000));
                  
                  try {
                    // Normalize phone
                    let finalPhone = checkoutForm.phone.trim().replace(/[^0-9]/g, '');
                    if (finalPhone.startsWith('0')) {
                      finalPhone = '254' + finalPhone.substring(1);
                    }

                    // Create packages structure based on user choice
                    let finalPackages = [];
                    if (isCartCheckout) {
                      if (shippingPackageStructure === 'SINGLE') {
                        finalPackages = [
                          {
                            id: 'PKG-' + Math.floor(100000 + Math.random() * 900000),
                            status: 'SHIPPED',
                            released: false,
                            items: cartItems.map(item => ({
                              id: item.product.id,
                              title: item.product.title,
                              price: item.product.price,
                              quantity: item.quantity
                            }))
                          }
                        ];
                      } else {
                        // Staggered: 1 package per item group
                        finalPackages = cartItems.map(item => ({
                          id: 'PKG-' + Math.floor(100000 + Math.random() * 900000),
                          status: 'SHIPPED',
                          released: false,
                          items: [
                            {
                              id: item.product.id,
                              title: item.product.title,
                              price: item.product.price,
                              quantity: item.quantity
                            }
                          ]
                        }));
                      }
                    } else {
                      // Single product checkout package
                      finalPackages = [
                        {
                          id: 'PKG-' + Math.floor(100000 + Math.random() * 900000),
                          status: 'SHIPPED',
                          released: false,
                          items: [
                            {
                              id: product.id,
                              title: product.title,
                              price: product.price,
                              quantity: qty
                            }
                          ]
                        }
                      ];
                    }

                    const payload = {
                      buyerPhone: finalPhone,
                      buyerName: checkoutForm.name,
                      buyerEmail: 'buyer@demo.buysafely.africa',
                      sellerPhone: product.sellerPhone,
                      sellerHandle: product.sellerHandle,
                      amount: subtotal,
                      description: isCartCheckout 
                        ? `Consolidated Escrow Purchase - ${cartItems.length} Items` 
                        : `${product.title} (Qty: ${qty})`,
                      quantity: isCartCheckout ? cartItems.reduce((acc, item) => acc + item.quantity, 0) : qty,
                      shippingMethod: isCartCheckout ? 'Courier' : checkoutForm.delivery,
                      shippingFee: shippingFee,
                      totalAmount: totalAmount,
                      productId: isCartCheckout ? 'cart' : product.id,
                      merchantId: 'MCH-001', // default active seller
                      cartEnabled: isCartCheckout,
                      items: isCartCheckout ? cartItems.map(item => ({
                        id: item.product.id,
                        title: item.product.title,
                        price: item.product.price,
                        quantity: item.quantity,
                        category: item.product.category,
                        deliveryStatus: 'SHIPPED',
                        releasedAmount: 0
                      })) : [
                        {
                          id: product.id,
                          title: product.title,
                          price: product.price,
                          quantity: qty,
                          category: product.category,
                          deliveryStatus: 'SHIPPED',
                          releasedAmount: 0
                        }
                      ],
                      packages: finalPackages
                    };

                    const res = await fetch('/api/transactions', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(payload)
                    });

                    if (res.ok) {
                      const data = await res.json();
                      const createdTx = data.transaction;
                      
                      setIsProcessingCheckout(false);
                      setShowCheckoutPrompt(false);
                      setCheckoutMpesaPin('');
                      if (isCartCheckout) {
                        setCartItems([]);
                      }
                      
                      // Refresh transactions list via prop
                      if (onRefresh) onRefresh();

                      // Route to tracking dashboard
                      setSimulatedPath('');
                      setPublicPage('support');
                      setTrackId(createdTx.id);
                      setSelectedTrackTx(createdTx);
                      alert(`STK Push Payment Received! KSh ${totalAmount.toLocaleString()} has been locked inside NCBA Trust Escrow under transaction ID: ${createdTx.id}`);
                    } else {
                      const errText = await res.text();
                      setIsProcessingCheckout(false);
                      alert(`Transaction Creation Failed: ${errText}`);
                    }
                  } catch (e) {
                    setIsProcessingCheckout(false);
                    console.error(e);
                    alert('Failed to connect to local server.');
                  }
                };

                return (
                  <div className="max-w-4xl mx-auto px-6 py-10 space-y-8 text-left relative">
                    {/* Checkout Header */}
                    <div className="border-b border-slate-800 pb-4 flex justify-between items-center">
                      <div>
                        <span className="text-emerald-400 font-mono text-[9.5px] uppercase tracking-wider">NCBA Trustee-Guarded Escrow Clearing</span>
                        <h2 className="text-xl sm:text-2xl font-black text-white uppercase flex items-center gap-2">
                          <Lock className="w-5 h-5 text-emerald-400" /> Secure Escrow Checkout
                        </h2>
                      </div>
                      <button 
                        onClick={() => setSimulatedPath(`/p/${product.id}`)}
                        className="text-xs text-slate-400 hover:text-white transition-colors"
                      >
                        ← Return to Product View
                      </button>
                    </div>

                    {checkoutError && (
                      <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-xs flex items-center gap-2">
                        <AlertTriangle className="w-4.5 h-4.5 shrink-0" />
                        <span>{checkoutError}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                      {/* Left Column: Form Controls */}
                      <div className="lg:col-span-7 space-y-6">
                        
                        {/* Selected product overview */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">1. Order Item Details</h4>
                          {isCartCheckout ? (
                            <div className="space-y-3 text-xs">
                              {cartItems.map((item) => (
                                <div key={item.product.id} className="flex gap-3 items-center bg-slate-950 border border-slate-850 p-2.5 rounded-xl">
                                  <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-emerald-400">
                                    <Package className="w-5 h-5" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="font-bold text-white truncate uppercase text-[11px]">{item.product.title}</p>
                                    <div className="flex justify-between items-center text-[10px] text-slate-400 mt-0.5">
                                      <span>Qty: {item.quantity} • KSh {item.product.price.toLocaleString()}</span>
                                      <strong className="text-slate-200 font-mono">KSh {(item.product.price * item.quantity).toLocaleString()}</strong>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="flex gap-4 items-center text-xs">
                              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl text-emerald-400">
                                <Layers className="w-6 h-6" />
                              </div>
                              <div className="space-y-1.5 flex-1 min-w-0">
                                <p className="font-bold text-white truncate text-sm uppercase">{product.title}</p>
                                <p className="text-[11px] text-slate-400">Merchant Outlet: <strong className="font-mono text-emerald-400">{product.sellerHandle}</strong></p>
                                <div className="flex justify-between items-center pt-1">
                                  <span className="font-mono text-slate-300 font-bold">KSh {product.price.toLocaleString()} each</span>
                                  
                                  {/* Quantity selector */}
                                  <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-lg p-1">
                                    <button 
                                      onClick={() => setCheckoutForm({ ...checkoutForm, quantity: Math.max(1, qty - 1) })}
                                      className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
                                    >
                                      <Minus className="w-3.5 h-3.5" />
                                    </button>
                                    <span className="font-mono font-bold px-1.5 text-white text-xs">{qty}</span>
                                    <button 
                                      onClick={() => setCheckoutForm({ ...checkoutForm, quantity: qty + 1 })}
                                      className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
                                    >
                                      <Plus className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Recipient Details */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 text-xs font-sans">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">2. Recipient Shipping Address</h4>
                          <div className="grid grid-cols-2 gap-3.5">
                            <div className="space-y-1.5 col-span-2">
                              <label className="text-slate-400">Full Name / Consignee:</label>
                              <input 
                                type="text"
                                placeholder="e.g. John Doe Njoroge"
                                value={checkoutForm.name}
                                onChange={(e) => setCheckoutForm({ ...checkoutForm, name: e.target.value })}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-emerald-500"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-slate-400">County / Region:</label>
                              <input 
                                type="text"
                                value={checkoutForm.county}
                                onChange={(e) => setCheckoutForm({ ...checkoutForm, county: e.target.value })}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-emerald-500 font-mono"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-slate-400">Town / District:</label>
                              <input 
                                type="text"
                                value={checkoutForm.town}
                                onChange={(e) => setCheckoutForm({ ...checkoutForm, town: e.target.value })}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-emerald-500 font-mono"
                              />
                            </div>
                            <div className="space-y-1.5 col-span-2">
                              <label className="text-slate-400">Physical Delivery Address / Flat Number:</label>
                              <input 
                                type="text"
                                placeholder="e.g. Apartment 4B, Kilimani Gardens"
                                value={checkoutForm.address}
                                onChange={(e) => setCheckoutForm({ ...checkoutForm, address: e.target.value })}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-emerald-500"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Delivery Method Selector */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">3. Selected Delivery Mode</h4>
                          {isCartCheckout ? (
                            <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl space-y-1 text-xs">
                              <p className="font-bold text-white">
                                {shippingPackageStructure === 'SINGLE' ? 'Consolidated Delivery' : 'Staggered Multi-Package Delivery'}
                              </p>
                              <p className="text-[11px] text-slate-400 leading-normal">
                                {shippingPackageStructure === 'SINGLE' 
                                  ? 'All items will be physically verified and dispatched together in one consolidated consignment via Fargo Courier.' 
                                  : 'Items will be verified and dispatched in separate staggered wave packages from different merchant fulfillment centers.'}
                              </p>
                              <div className="pt-2 flex justify-between text-[11px] font-mono border-t border-slate-900 mt-2">
                                <span className="text-slate-400">LOGISTICS RATE:</span>
                                <strong className="text-emerald-450 text-emerald-400 font-bold">KSh {shippingFee.toLocaleString()}</strong>
                              </div>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                              {[
                                { key: 'Courier', title: 'Fargo Courier', desc: 'Secure Delivery', fee: 'KSh 300' },
                                { key: 'Rider', title: 'Rider Dispatch', desc: 'Fast Moto Delivery', fee: 'KSh 150' },
                                { key: 'Pickup', title: 'Self-Pickup', desc: 'Verify on Site', fee: 'FREE' }
                              ].map(del => (
                                <button
                                  key={del.key}
                                  type="button"
                                  onClick={() => setCheckoutForm({ ...checkoutForm, delivery: del.key })}
                                  className={`p-3 rounded-xl border text-left flex flex-col justify-between h-24 cursor-pointer transition-all ${
                                    checkoutForm.delivery === del.key 
                                      ? 'bg-emerald-500/10 border-emerald-500 text-white' 
                                      : 'bg-slate-950 border-slate-850 hover:border-slate-700 text-slate-300'
                                  }`}
                                >
                                  <span className="text-xs font-bold block">{del.title}</span>
                                  <div>
                                    <span className="text-[10px] text-slate-500 block leading-tight">{del.desc}</span>
                                    <span className="text-xs font-mono font-bold text-emerald-400 block mt-1">{del.fee}</span>
                                  </div>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Fraud Insurance Shield Selector */}
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                          <h4 className="text-xs font-bold text-white uppercase border-b border-slate-800 pb-2">4. Escrow Insurance & Fraud Shield</h4>
                          {isCartCheckout ? (
                            <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl space-y-2 text-xs">
                              <p className="font-bold text-white">
                                {insuranceStructure === 'ORDER' ? `Order-Level Protection Shield` : 'Item-Level Selective Protection Shield'}
                              </p>
                              <p className="text-[11px] text-slate-400 leading-normal">
                                {insuranceStructure === 'ORDER'
                                  ? `Standard umbrella protection is configured on the entire order with tier mode: ${orderInsuranceOption}.`
                                  : `Selective insurance protection configured individually per item in your shopping cart.`}
                              </p>
                              {insuranceStructure === 'ITEM' && (
                                <div className="space-y-1.5 pt-1.5 border-t border-slate-900">
                                  {cartItems.map(item => (
                                    <div key={item.product.id} className="flex justify-between text-[10px] font-mono text-slate-300">
                                      <span>{item.product.title}</span>
                                      <span>{item.insured ? 'Insured (KSh 150)' : 'Uncovered'}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                              <div className="pt-2 flex justify-between text-[11px] font-mono border-t border-slate-900 mt-1">
                                <span className="text-slate-400">TOTAL INSURANCE PREMIUM:</span>
                                <strong className="text-emerald-455 text-emerald-400 font-bold">KSh {insurancePremium.toLocaleString()}</strong>
                              </div>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                              {[
                                { key: 'NONE', title: 'No Cover', desc: 'Standard Escrow Only', fee: 'KSh 0' },
                                { key: 'BASIC', title: 'Basic Shield', desc: 'Theft & Loss Cover', fee: 'KSh 450' },
                                { key: 'ENHANCED', title: 'Priority Shield', desc: 'Damage & Full Refund', fee: 'KSh 1,200' }
                              ].map(ins => (
                                <button
                                  key={ins.key}
                                  type="button"
                                  onClick={() => setCheckoutForm({ ...checkoutForm, insurance: ins.key })}
                                  className={`p-3 rounded-xl border text-left flex flex-col justify-between h-24 cursor-pointer transition-all ${
                                    checkoutForm.insurance === ins.key 
                                      ? 'bg-emerald-500/10 border-emerald-500 text-white' 
                                      : 'bg-slate-950 border-slate-850 hover:border-slate-700 text-slate-300'
                                  }`}
                                >
                                  <span className="text-xs font-bold block">{ins.title}</span>
                                  <div>
                                    <span className="text-[10px] text-slate-500 block leading-tight">{ins.desc}</span>
                                    <span className="text-xs font-mono font-bold text-emerald-400 block mt-1">{ins.fee}</span>
                                  </div>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* M-Pesa phone number input */}
                        {!checkoutReviewCompleted ? (
                          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 text-xs text-slate-400">
                            <h4 className="text-xs font-bold text-slate-500 uppercase border-b border-slate-800 pb-2">5. Safaricom M-Pesa Mobile Money</h4>
                            <div className="p-6 bg-slate-950/80 border border-slate-850 rounded-xl text-center space-y-2">
                              <Lock className="w-5 h-5 text-slate-600 mx-auto animate-pulse" />
                              <p className="text-[11px] text-slate-400 font-sans leading-relaxed">Please complete your order details review above to unlock secure Daraja STK push payment options.</p>
                            </div>
                          </div>
                        ) : (
                          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3.5 text-xs animate-fade-in">
                            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                              <h4 className="text-xs font-bold text-emerald-400 uppercase">5. Safaricom M-Pesa Mobile Money</h4>
                              <span className="text-[9.5px] bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded font-mono uppercase font-bold">STK Unlocked</span>
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-slate-400">M-Pesa Mobile Number (STK Push Destination):</label>
                              <input 
                                type="tel"
                                required
                                placeholder="e.g. 0711223344 or 254711223344"
                                value={checkoutForm.phone}
                                onChange={(e) => setCheckoutForm({ ...checkoutForm, phone: e.target.value })}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono outline-none focus:border-emerald-500"
                              />
                              <p className="text-[10px] text-slate-500 font-mono mt-1">We will send a secure Daraja STK prompt requesting code authentication to lock capital.</p>
                            </div>
                          </div>
                        )}

                      </div>

                      {/* Right Column: Fee breakdown & CTA */}
                      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 h-fit sticky top-6">
                        <h4 className="text-xs uppercase font-extrabold text-white border-b border-slate-800 pb-2 flex items-center gap-1">
                          <Lock className="w-3.5 h-3.5 text-emerald-400" /> Escrow Balance Breakdown
                        </h4>

                        <div className="space-y-2.5 text-xs font-mono leading-relaxed">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Product Item Subtotal:</span>
                            <span className="text-slate-200">KSh {subtotal.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Logistics Transport:</span>
                            <span className="text-slate-200">KSh {shippingFee.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Fraud Insurance Cover:</span>
                            <span className="text-slate-200">KSh {insurancePremium.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Escrow Account Setup Duty:</span>
                            <span className="text-emerald-400 font-bold">FREE (NCBA TRUST)</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Clearing & Settlements (1%):</span>
                            <span className="text-slate-200">KSh {platformFee.toLocaleString()}</span>
                          </div>

                          <div className="border-t border-slate-800 pt-3 flex justify-between font-black text-white text-sm select-all">
                            <span className="text-emerald-400">GRAND TOTAL SECURED:</span>
                            <span className="text-emerald-400 font-bold">KSh {totalAmount.toLocaleString()}</span>
                          </div>
                        </div>

                        {!checkoutReviewCompleted ? (
                          <div className="space-y-3 font-sans">
                            <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl text-[10.5px] leading-relaxed">
                              <p className="font-bold">⚠️ Review Step Required</p>
                              <p className="mt-0.5 text-slate-350">Please review shipping destination details, consolidated/staggered package configurations, and selective insurance shields before locking payment.</p>
                            </div>
                            <button 
                              type="button"
                              onClick={() => {
                                if (!checkoutForm.name.trim()) {
                                  setCheckoutError('Please enter your full recipient name before proceeding.');
                                  return;
                                }
                                if (!checkoutForm.address.trim()) {
                                  setCheckoutError('Please enter your physical shipping address before proceeding.');
                                  return;
                                }
                                setCheckoutError('');
                                setCheckoutReviewCompleted(true);
                              }}
                              className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-slate-950 font-black uppercase py-3.5 rounded-xl text-xs tracking-wider transition-all cursor-pointer shadow-lg shadow-emerald-950/10 block text-center"
                            >
                              Confirm Details & Continue
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-3 font-sans">
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => setCheckoutReviewCompleted(false)}
                                className="w-full bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-750 text-slate-400 hover:text-white text-[10px] font-bold uppercase py-2 rounded-lg transition-colors cursor-pointer text-center"
                              >
                                ← Modify Details
                              </button>
                            </div>
                            <button 
                              type="button"
                              onClick={handlePlaceOrder}
                              className="w-full bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-slate-950 font-black uppercase py-3.5 rounded-xl text-xs tracking-wider transition-all cursor-pointer shadow-lg shadow-emerald-950/10 block text-center"
                            >
                              Unlock Escrow & Pay
                            </button>
                          </div>
                        )}

                        <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl leading-normal text-slate-500 text-[10px] font-sans">
                          🛡️ <strong className="text-slate-400">NCBA Escrow Account Guarantee</strong>: Funds will be held strictly locked in NCBA bank escrow under Central Bank of Kenya trust regulations. Settlement occurs only upon waybill signature confirmation.
                        </div>
                      </div>
                    </div>

                    {/* Simulated Smartphone M-Pesa Prompt Dialog Overlay */}
                    {showCheckoutPrompt && (
                      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 select-none animate-fade-in">
                        <div className="bg-slate-900 border-2 border-slate-800 w-full max-w-[320px] rounded-[32px] overflow-hidden shadow-2xl flex flex-col justify-between font-sans text-xs">
                          {/* Green Header */}
                          <div className="bg-emerald-700 p-4 text-white text-center space-y-1 relative">
                            <div className="w-12 h-1 bg-white/30 rounded-full mx-auto mb-2"></div>
                            <span className="text-[10px] tracking-widest font-mono font-bold uppercase block opacity-85">Safaricom M-Pesa</span>
                            <h3 className="text-sm font-black leading-none uppercase">Daraja Trust API</h3>
                          </div>

                          <div className="p-5 space-y-4 text-left">
                            <p className="text-slate-300 leading-normal text-[11.5px]">
                              Do you want to lock <strong className="text-white">KSh {totalAmount.toLocaleString()}</strong> into the Buy Safely NCBA Trust Escrow account for <strong className="text-white">{product.title}</strong>?
                            </p>

                            <div className="space-y-1.5">
                              <label className="text-slate-400 text-[10px] font-mono uppercase tracking-wider block">Enter Simulated M-Pesa PIN:</label>
                              <input 
                                type="password"
                                maxLength={4}
                                required
                                value={checkoutMpesaPin}
                                onChange={(e) => setCheckoutMpesaPin(e.target.value.replace(/[^0-9]/g, ''))}
                                placeholder="e.g. 1234"
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-center text-white font-mono text-lg tracking-widest outline-none focus:border-emerald-500"
                              />
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="border-t border-slate-800 p-4 flex gap-3 text-xs">
                            <button 
                              type="button"
                              onClick={() => { setShowCheckoutPrompt(false); setCheckoutMpesaPin(''); }}
                              disabled={isProcessingCheckout}
                              className="flex-1 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 py-2 rounded-xl transition-colors font-bold cursor-pointer"
                            >
                              Cancel
                            </button>
                            <button 
                              type="button"
                              onClick={handleConfirmMpesa}
                              disabled={isProcessingCheckout}
                              className="flex-1 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-500/40 text-slate-950 py-2 rounded-xl font-black transition-colors uppercase cursor-pointer flex items-center justify-center gap-1.5"
                            >
                              {isProcessingCheckout ? (
                                <RefreshCw className="w-4 h-4 animate-spin" />
                              ) : (
                                'Confirm'
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* 3. SECURE BUYERS PAGE (TRUST PORTAL ONLY) */}
              {simulatedPath === '' && publicPage === 'buyers' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-10 text-left animate-fade-in">
                  <div className="space-y-2 border-b border-slate-800 pb-5">
                    <span className="text-emerald-400 font-mono text-[10px] uppercase tracking-wider">SECURE SHOPPING GATEWAY</span>
                    <h2 className="text-2xl font-black text-white uppercase">Buyers: Capital Protection & Verification Hub</h2>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      Never deal under advance-payment risk again. Verify product authenticity, track real-time escrows, or parse secure links below.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                    {/* Column 1: Resolve link & Track transaction */}
                    <div className="space-y-6">
                      
                      {/* Resolve Safe Buy Product Link */}
                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                          <Link2 className="w-4 h-4 text-emerald-400" />
                          <h3 className="text-xs uppercase font-extrabold text-white">Enter Safe Buy Product Link</h3>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal">
                          Paste a secure Buy Safely payment link generated by a merchant to verify its trust details and checkout.
                        </p>
                        <div className="space-y-2.5 text-xs">
                          <input 
                            type="text"
                            placeholder="e.g. buysafely.africa/pay/BS-PRD-000101"
                            value={safeBuyLinkInput}
                            onChange={(e) => setSafeBuyLinkInput(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono placeholder:text-slate-600 outline-none focus:border-emerald-500"
                          />
                          <button 
                            type="button"
                            onClick={() => {
                              if (!safeBuyLinkInput.trim()) {
                                alert('Please paste a simulated link first.');
                                return;
                              }
                              // Extract product ID
                              const cleaned = safeBuyLinkInput.trim();
                              let matchedId = '';
                              if (cleaned.includes('/pay/')) {
                                matchedId = cleaned.split('/pay/')[1];
                              } else if (cleaned.includes('/p/')) {
                                matchedId = cleaned.split('/p/')[1];
                              } else {
                                matchedId = cleaned;
                              }

                              // Clean matchedId
                              matchedId = matchedId.split('?')[0].split('#')[0].trim();

                              const product = getProductById(matchedId);
                              if (product) {
                                setSimulatedPath(`/p/${product.id}`);
                              } else {
                                alert(`Invalid or unknown Product Reference ID: "${matchedId}". Try using one of our demo product IDs below (e.g. BS-PRD-000101).`);
                              }
                            }}
                            className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-2 rounded-lg transition-colors cursor-pointer text-[10px]"
                          >
                            Authenticate & Open Product Profile
                          </button>
                        </div>
                      </div>

                      {/* Track Existing Transaction */}
                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                          <Search className="w-4 h-4 text-emerald-400" />
                          <h3 className="text-xs uppercase font-extrabold text-white">Track Existing Escrow Transaction</h3>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal">
                          Enter your escrow clearance contract ID to monitor physical audit status, courier route waybills, and lock releases.
                        </p>
                        <div className="space-y-2.5 text-xs">
                          <input 
                            type="text"
                            placeholder="e.g. BS-ESC-2026-X79B2K"
                            value={trackId}
                            onChange={(e) => setTrackId(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white font-mono placeholder:text-slate-600 outline-none focus:border-emerald-500"
                          />
                          <button 
                            type="button"
                            onClick={handleTrackLookup}
                            className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold uppercase py-2 rounded-lg transition-colors cursor-pointer text-[10px]"
                          >
                            Open Telemetry Status Timeline
                          </button>
                        </div>
                      </div>

                    </div>

                    {/* Column 2: Demo Products */}
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                        <Sparkles className="w-4 h-4 text-emerald-400" />
                        <h3 className="text-xs uppercase font-extrabold text-white">View Demonstration Products</h3>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-normal">
                        Select an active simulated item from our verified partner program to experience the physical verification audit reports, escrow links, and secure payments.
                      </p>

                      <div className="space-y-3">
                        {allProducts.map((p) => {
                          const isVer = p.verificationStatus === 'VERIFIED';
                          return (
                            <div 
                              key={p.id}
                              className="bg-slate-950 border border-slate-850 hover:border-slate-750 p-3.5 rounded-xl space-y-2.5 transition-all flex flex-col justify-between"
                            >
                              <div className="flex justify-between items-start gap-2">
                                <div className="min-w-0 cursor-pointer" onClick={() => setSimulatedPath(`/p/${p.id}`)}>
                                  <h4 className="text-xs font-bold text-white uppercase hover:text-emerald-400 transition-colors truncate">{p.title}</h4>
                                  <span className="text-[9.5px] font-mono text-slate-500 uppercase">{p.category}</span>
                                </div>
                                <span className="font-mono text-xs font-bold text-emerald-400 shrink-0">KSh {p.price.toLocaleString()}</span>
                              </div>

                              <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-xs">
                                <div className="flex items-center gap-1.5">
                                  {isVer ? (
                                    <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-900/30">✓ AUDITED</span>
                                  ) : (
                                    <span className="text-[9px] font-mono text-slate-500 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">UNVERIFIED</span>
                                  )}
                                  <span className="text-[9px] font-mono text-slate-400">{p.id}</span>
                                </div>
                                
                                <button
                                  type="button"
                                  onClick={() => setSimulatedPath(`/p/${p.id}`)}
                                  className="text-[10px] text-emerald-400 hover:text-emerald-300 font-bold transition-colors cursor-pointer"
                                >
                                  View Details →
                                </button>
                              </div>

                              {/* Multi-Cart Action Controls */}
                              <div className="grid grid-cols-2 gap-2 pt-2.5 border-t border-slate-900 font-sans">
                                <button
                                  type="button"
                                  onClick={() => handleAddToCart(p)}
                                  className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-[10px] font-extrabold uppercase py-1.5 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1"
                                >
                                  <Plus className="w-3.5 h-3.5 text-emerald-400" />
                                  <span>Add to Cart</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setCartItems([{ product: p, quantity: 1, insured: true }]);
                                    setSimulatedPath(`/pay/cart`);
                                  }}
                                  className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-[10px] font-black uppercase py-1.5 rounded-lg transition-colors cursor-pointer flex items-center justify-center"
                                >
                                  Buy Now
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. SELLERS FUNNEL */}
              {simulatedPath === '' && publicPage === 'sellers' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-10 text-left animate-fade-in">
                  <div className="space-y-2 border-b border-slate-800 pb-5">
                    <span className="text-emerald-400 font-mono text-[10px] tracking-wider uppercase">HIGH-GROWTH ACQUISITION FUNNEL</span>
                    <h2 className="text-2xl font-black text-white uppercase">Merchant Portal & Onboarding</h2>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      Establish high-trust checkout anchors. Clear out advance-payment suspicions and convert social commerce traffic natively.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    
                    {/* Left Column: Onboarding Form (New Merchant Registration) */}
                    <div className="lg:col-span-6 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                        <UserPlus className="w-4 h-4 text-emerald-400" />
                        <h3 className="text-xs uppercase font-extrabold text-white">New Merchant Registration</h3>
                      </div>
                      
                      <form onSubmit={handleRegisterMerchant} className="space-y-3.5 text-xs font-sans">
                        <div className="space-y-1.5">
                          <label className="text-slate-400">Business Name / Instagram Outlet Name:</label>
                          <input 
                            type="text"
                            required
                            placeholder="e.g. Vintage Thrifts Nairobi"
                            value={newSeller.name}
                            onChange={(e) => setNewSeller({ ...newSeller, name: e.target.value })}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-slate-400">Safaricom Mobile Business KYC:</label>
                          <input 
                            type="text"
                            required
                            placeholder="e.g. 254711223344"
                            value={newSeller.phone}
                            onChange={(e) => setNewSeller({ ...newSeller, phone: e.target.value })}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-slate-400">Social Media Outlet Handle (Link):</label>
                          <input 
                            type="text"
                            placeholder="instagram.com/vintage_thrifts"
                            value={newSeller.social}
                            onChange={(e) => setNewSeller({ ...newSeller, social: e.target.value })}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white outline-none focus:border-emerald-500"
                          />
                        </div>

                        {kycStep === 0 ? (
                          <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase tracking-wider py-3 rounded-xl transition-all cursor-pointer">
                            Launch Escrow Verification
                          </button>
                        ) : (
                          <div className="text-center font-mono py-2 space-y-2">
                            <RefreshCw className="w-5 h-5 mx-auto text-emerald-400 animate-spin" />
                            <p className="text-[10px] text-emerald-400 uppercase font-black">
                              {kycStep === 1 && 'Pipeline Step 1/3: Instantiating background AML compliance check...'}
                              {kycStep === 2 && 'Pipeline Step 2/3: Integrating with Safaricom Daraja till records...'}
                              {kycStep === 3 && 'Pipeline Step 3/3: Mapping secure NCBA escrow reserve balance...'}
                            </p>
                          </div>
                        )}
                      </form>

                      {/* Social Importer */}
                      <div className="border-t border-slate-800/80 pt-4 mt-2 space-y-3">
                        <h4 className="text-xs uppercase font-extrabold text-slate-350 flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5 text-emerald-400" /> Auto-Import Social Listings
                        </h4>
                        <div className="flex gap-2 text-xs">
                          <input 
                            type="text" 
                            placeholder="Paste Instagram/TikTok link..."
                            value={socialUrl}
                            onChange={(e) => setSocialUrl(e.target.value)}
                            className="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-white outline-none"
                          />
                          <button 
                            type="button"
                            onClick={handleSocialImport} 
                            disabled={isExtracting}
                            className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 px-3 py-1 rounded font-bold uppercase text-[9px] cursor-pointer"
                          >
                            {isExtracting ? 'Loading..' : 'Parse'}
                          </button>
                        </div>
                        {socialResult && (
                          <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-[10px] space-y-1">
                            <p className="font-bold text-white uppercase">{socialResult.name || 'Sample apparel'}</p>
                            <p className="text-emerald-400 font-mono">Suggested Price: KSh {socialResult.price}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right Column: Existing Merchant Login */}
                    <div className="lg:col-span-6 space-y-6">
                      
                      {/* Secure login form */}
                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                          <Lock className="w-4 h-4 text-emerald-400" />
                          <h3 className="text-xs uppercase font-extrabold text-white">Existing Merchant Login</h3>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal">
                          Access your merchant dashboard to generate product links, manage orders, view settlements, and monitor escrow balances.
                        </p>

                        <div className="space-y-3.5 text-xs font-sans">
                          <div className="space-y-1.5">
                            <label className="text-slate-400">Registered Business Phone / Merchant ID:</label>
                            <input 
                              type="text"
                              placeholder="e.g. 254711223344 or MCH-001"
                              defaultValue="254711223344"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-emerald-500 font-mono"
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-slate-400">Access Key / PIN Code:</label>
                            <input 
                              type="password"
                              placeholder="••••"
                              defaultValue="1234"
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white outline-none focus:border-emerald-500 font-mono tracking-widest"
                            />
                          </div>

                          <button 
                            type="button"
                            onClick={() => {
                              // Route directly to the Merchant Portal domain
                              setSimulatedPath('');
                              setActiveSimulatedDomain('merchant.buysafely.africa');
                              alert('Secure handshake complete! Redirecting you to the Merchant Terminal (merchant.buysafely.africa).');
                            }}
                            className="w-full bg-slate-800 hover:bg-slate-700 text-emerald-400 font-bold uppercase py-3 rounded-xl transition-all cursor-pointer text-xs"
                          >
                            Authenticate & Enter Merchant Portal
                          </button>
                        </div>
                      </div>

                      {/* Fast Escrow Link Generator */}
                      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                          <Link2 className="w-4 h-4 text-emerald-400" />
                          <h3 className="text-xs uppercase font-extrabold text-white">Ecosystem Safe Link Generator</h3>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-normal">
                          Quick-generate standard checkout links for WhatsApp catalog deployment or Instagram Story swipe-up tags.
                        </p>

                        <div className="space-y-2.5 text-xs">
                          <input 
                            type="text"
                            placeholder="Product Title"
                            value={linkBuilder.title}
                            onChange={(e) => setLinkBuilder({...linkBuilder, title: e.target.value})}
                            className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white"
                          />
                          <input 
                            type="number"
                            placeholder="Price (KSh)"
                            value={linkBuilder.price}
                            onChange={(e) => setLinkBuilder({...linkBuilder, price: Number(e.target.value)})}
                            className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-mono"
                          />
                          <button onClick={handleGenerateLink} className="w-full bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 font-bold uppercase text-[10px] py-2 rounded transition-all cursor-pointer">
                            Generate Safe Link
                          </button>
                        </div>
                        {generatedLink && (
                          <div className="p-2 bg-slate-950 rounded border border-slate-800 text-[10px] space-y-1.5 select-all">
                            <span className="text-slate-400 font-mono">Safe Escrow URL:</span>
                            <p className="text-emerald-400 break-all font-mono font-bold">{generatedLink}</p>
                          </div>
                        )}
                      </div>

                    </div>
                  </div>
                </div>
              )}

              {/* 5. LOGISTICS PAGE */}
              {publicPage === 'logistics' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-8 text-left">
                  <div className="space-y-2 border-b border-slate-800 pb-5">
                    <span className="text-emerald-400 font-mono text-[10px] tracking-wider uppercase">LOGISTICS DISPATCH ARCHITECTURE</span>
                    <h2 className="text-2xl font-black text-white uppercase">Courier & Riders Network Page</h2>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      Steady deliveries for professional riders, drivers, and corporate fleets. We secure the waybill payouts inside local escrows.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    
                    {/* Rider Signup Form */}
                    <div className="lg:col-span-6 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                      <h3 className="text-xs uppercase font-extrabold text-white border-b border-slate-800 pb-2">Join Rider Network</h3>
                      <form onSubmit={handleRiderRegister} className="space-y-3.5 text-xs font-sans">
                        <div className="space-y-1">
                          <label className="text-slate-400">Rider / Driver Name:</label>
                          <input type="text" required placeholder="John Kamau" value={riderForm.name} onChange={e=>setRiderForm({...riderForm, name: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-400">Mobile Phone Coordinate:</label>
                          <input type="tel" required placeholder="254711000111" value={riderForm.Phone} onChange={e=>setRiderForm({...riderForm, Phone: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-mono" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-400">Motorcycle Plate Number (Or DL):</label>
                          <input type="text" required placeholder="KMQD 102Z" value={riderForm.Plate} onChange={e=>setRiderForm({...riderForm, Plate: e.target.value})} className="w-full bg-slate-950 border border-slate-805 rounded p-2 text-white font-mono" />
                        </div>
                        <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-2 rounded text-[10px] tracking-wider cursor-pointer">
                          Submit Registry Application
                        </button>
                        {joinSuccess && (
                          <p className="text-[11px] text-emerald-400 font-mono text-center">✓ Application submitted to Operations panel routing queues.</p>
                        )}
                      </form>
                    </div>

                    {/* Corporate logistics details */}
                    <div className="lg:col-span-6 space-y-5 text-xs leading-relaxed">
                      <div className="p-4 bg-slate-900/60 border border-slate-805 rounded-xl space-y-2">
                        <h4 className="font-extrabold text-white uppercase text-amber-500">How Delivery Escrows Work</h4>
                        <p className="text-slate-400 font-sans">
                          A consumer deposit includes the locked Shipping Fee. When you take the waybill parcel, the buyer gets automatic SMS. 
                          Upon OTP inspection delivery approval, the payout disbursements immediately occur. Guaranteed pay, zero risk.
                        </p>
                      </div>

                      <div className="p-4 bg-slate-900/40 border border-slate-805 rounded-xl space-y-1.5">
                        <h4 className="font-extrabold text-white uppercase text-slate-300">Integrated Carriers</h4>
                        <p className="text-slate-500">Participating courier logistics groups in East Africa:</p>
                        <div className="grid grid-cols-2 gap-2 text-[10.5px] font-mono text-slate-400">
                          <span>• Fargo Courier Kenya</span>
                          <span>• Wells Fargo Express Ltd</span>
                          <span>• Swift Rider Network</span>
                          <span>• Nairobi Central Boda Association</span>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* 6. VERIFICATION PAGE */}
              {publicPage === 'verification' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-8 text-left">
                  <div className="space-y-2 border-b border-slate-800 pb-5">
                    <span className="text-emerald-400 font-mono text-[10px] tracking-wider uppercase">MANDATORY TRUST TESTING</span>
                    <h2 className="text-2xl font-black text-white uppercase">Verification Agent & Picker Network</h2>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      Become a certified expert. Audit high-value electronics, smartphones, and vehicles before delivery. Earn KSh 500 - KSh 2,500 per passing certification.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    
                    {/* View Assignments */}
                    <div className="lg:col-span-7 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                      <h3 className="text-xs uppercase font-extrabold text-white border-b border-slate-800 pb-2">Active Inspection Missions</h3>
                      
                      <div className="space-y-3.5">
                        {inspections.map((job, idx) => (
                          <div key={idx} className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl space-y-2 text-xs">
                            <div className="flex justify-between items-center text-[10px] font-mono font-bold">
                              <span>KEY: {job.id}</span>
                              <span className={`px-2 py-0.5 rounded ${job.status === 'VERIFIED' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-500'}`}>
                                {job.status}
                              </span>
                            </div>
                            <div>
                              <h4 className="font-extrabold text-white">{job.title}</h4>
                              <p className="text-slate-400 font-mono text-[10.5px]">Price: {job.price} • Outlet: {job.seller}</p>
                            </div>
                            {job.status === 'PENDING_INSPECTION' && (
                              <button 
                                onClick={() => {
                                  const updated = [...inspections];
                                  updated[idx].status = 'VERIFIED';
                                  setInspections(updated);
                                  alert('Checklist approved. Certified passing reports dispatched to risk queues.');
                                }}
                                className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold uppercase text-[9.5px] py-1.5 rounded mt-1.5 cursor-pointer"
                              >
                                Submit Certified Passing Report
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* How to become picker */}
                    <div className="lg:col-span-5 bg-slate-900 border border-slate-805 p-5 rounded-2xl space-y-4 text-xs font-sans">
                      <h4 className="font-extrabold text-white uppercase border-b border-slate-800 pb-1.5">Picker Certification</h4>
                      <p className="text-slate-400 leading-relaxed">
                        To earn commission inspects fees, candidate Pickers must pass the standard Central Bank tier-2 fintech assessment verifying mechanical display integrity.
                      </p>
                      
                      <div className="p-3 bg-slate-950 rounded-xl border border-flat text-[10.5px] text-slate-400 font-mono space-y-1">
                        <strong className="text-emerald-400 block pb-1">COURSES INCLUDED:</strong>
                        <p>• IMEI Odometer registry audits</p>
                        <p>• Hardware clone diagnostics</p>
                        <p>• Anti-scam waybill telemetry checks</p>
                      </div>
                      
                      <button onClick={() => alert('Applications temporary capped. Next licensing cohort starts October.')} className="w-full bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 font-bold py-1.5 rounded cursor-pointer uppercase text-[10px]">
                        Apply for Licensing Course
                      </button>
                    </div>

                  </div>
                </div>
              )}

              {/* 7. CUSTOMER SUPPORT HUB */}
              {publicPage === 'support' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-10 text-left">
                  
                  {/* SUPPORT CONTROLS */}
                  <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl text-center space-y-4">
                    <span className="bg-emerald-405 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono tracking-wider font-bold block w-fit mx-auto px-3.5 py-1 rounded-full uppercase">
                      help.buysafely.africa
                    </span>
                    <h2 className="text-2xl font-black text-white uppercase tracking-tight">Customer Trust & Operations Support</h2>
                    <p className="text-xs text-slate-400 max-w-lg mx-auto font-sans leading-relaxed">
                      Seek fast tracking, trace ongoing Safaricom STK escrows, or escalate transaction scams to the dispute board.
                    </p>

                    {/* Tracking search bar */}
                    <div id="support-track-box" className="max-w-md mx-auto flex gap-2">
                      <input 
                        type="text"
                        value={trackId}
                        onChange={(e) => setTrackId(e.target.value)}
                        placeholder="Enter Escrow ID (e.g. BS-ESC-2026-00001) or mobile..."
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white placeholder-slate-600 font-mono outline-none focus:border-emerald-500"
                      />
                      <button 
                        onClick={() => handleTrackLookup(trackId)}
                        className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 px-5 rounded-xl font-bold uppercase text-[10.5px] tracking-wider transition-colors cursor-pointer"
                      >
                        Track
                      </button>
                    </div>

                    {/* Quick select list to help testing */}
                    <div className="text-[10.5px] text-slate-500 font-mono">
                      <span>Quick Select Active Escrows: </span>
                      <select 
                        onChange={(e) => {
                          setTrackId(e.target.value);
                          handleTrackLookup(e.target.value);
                        }}
                        className="bg-slate-950 text-slate-300 border border-slate-800 rounded p-1 font-mono text-[10px]"
                      >
                        <option value="">-- Choose simulated escrow --</option>
                        {transactions.map(t => (
                          <option key={t.id} value={t.id}>
                            {formatEscrowId(t.id)} ({t.description.slice(0,15)}...)
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* ACTIVE ESCROW WORKFLOW TRACKER WINDOW */}
                  {selectedTrackTx && (
                    <div className="bg-slate-900 border border-emerald-500/20 rounded-2xl p-5 space-y-4.5 shadow-xl relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl pointer-events-none"></div>
                      
                      <div className="flex flex-wrap justify-between items-center gap-3 border-b border-slate-800 pb-3">
                        <div className="space-y-0.5">
                          <span className="text-[10px] font-mono text-amber-500 tracking-wider">SECURE ESCROW TRACKING VIEW</span>
                          <h4 className="text-sm font-black font-mono text-white select-all">{formatEscrowId(selectedTrackTx.id)}</h4>
                        </div>
                        <span className={`text-xs font-mono font-bold px-3 py-1 rounded-full ${
                          selectedTrackTx.status === 'FUNDS_RELEASED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/25' :
                          selectedTrackTx.status === 'DISPUTED' ? 'bg-red-950 text-red-400 border border-red-500/25' :
                          selectedTrackTx.status === 'ITEMS_SHIPPED' ? 'bg-amber-950 text-amber-400 border border-amber-500/25' :
                          'bg-slate-950 text-slate-350 border border-slate-800'
                        }`}>
                          {selectedTrackTx.status}
                        </span>
                      </div>

                      {/* Timeline status details */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5 text-xs">
                        <div className="bg-slate-950 p-3 rounded-xl space-y-1.5">
                          <p className="text-slate-500">Transaction details:</p>
                          <strong className="text-slate-200 block truncate">{selectedTrackTx.description}</strong>
                          <p className="text-[11px] text-slate-400 font-mono">Amount: <span className="text-emerald-400 font-bold">KSh {selectedTrackTx.amount.toLocaleString()}</span></p>
                        </div>

                        <div className="bg-slate-950 p-3 rounded-xl space-y-1.5">
                          <p className="text-slate-500">Parties Involved:</p>
                          <p className="text-slate-300">Buyer Wallet: <span className="font-mono text-white">+{selectedTrackTx.buyerPhone}</span></p>
                          <p className="text-slate-300">Seller Handle: <span className="font-mono text-white">{selectedTrackTx.sellerHandle}</span></p>
                        </div>

                        <div className="bg-slate-950 p-3 rounded-xl space-y-1.5">
                          <p className="text-slate-500">Logistics telemetry:</p>
                          <p className="text-slate-300">Courier Name: <span className="text-slate-200 font-bold">{selectedTrackTx.deliveryPartnerName || 'Assigned Courier partner'}</span></p>
                          <p className="text-slate-400 font-mono text-[10px]">OTP Handover PIN: {selectedTrackTx.deliveryPin || 'Pending dispatch'}</p>
                        </div>
                      </div>

                      {/* Interactive production simulation buttons */}
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                        <p className="text-[10px] uppercase tracking-wider font-mono font-bold text-amber-500 flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Simulate Production State Events:
                        </p>
                        
                        <div className="flex flex-wrap gap-2 text-xs">
                          {selectedTrackTx.status === 'PENDING_DEPOSIT' && (
                            <button
                              onClick={async () => {
                                const res = await fetch(`/api/transactions/${selectedTrackTx.id}/deposit`, { method: 'POST' });
                                if (res.ok) { onRefresh(); alert('Daraja M-Pesa push complete: Escrow vault secured.'); }
                              }}
                              className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold uppercase text-[10px] px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
                            >
                              📲 Simulate M-Pesa STK payment (Lock Escrow)
                            </button>
                          )}

                          {selectedTrackTx.status === 'ESCROW_HELD' && (
                            <button
                              onClick={async () => {
                                const res = await fetch(`/api/transactions/${selectedTrackTx.id}/ship`, { method: 'POST' });
                                if (res.ok) { onRefresh(); alert('Seller dispatches waybills successfully. Shipments tracking active.'); }
                              }}
                              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold uppercase text-[10px] px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
                            >
                              🏍️ Simulate Seller Shipping (Mark Dispatch)
                            </button>
                          )}

                          {selectedTrackTx.status === 'ITEMS_SHIPPED' && (
                            <>
                              <button
                                onClick={async () => {
                                  const res = await fetch(`/api/transactions/${selectedTrackTx.id}/release`, { method: 'POST' });
                                  if (res.ok) { onRefresh(); alert('Buyer delivered inspect matches details. blocked escrow paid out.'); }
                                }}
                                className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold uppercase text-[10px] px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
                              >
                                ✅ Complete Handover delivery (Release Escrow)
                              </button>

                              <button
                                onClick={async () => {
                                  const res = await fetch(`/api/transactions/${selectedTrackTx.id}/dispute`, {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ reason: 'Product arrives damaged / fake.' })
                                  });
                                  if (res.ok) { onRefresh(); alert('Buyer opens scam dispute escalate. Block balances frozen.'); }
                                }}
                                className="bg-red-500 hover:bg-red-600 text-white font-bold uppercase text-[10px] px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
                              >
                                🚨 Simulate File Scam Dispute
                              </button>
                            </>
                          )}

                          {selectedTrackTx.status === 'DISPUTED' && (
                            <>
                              <button
                                onClick={async () => {
                                  const res = await fetch(`/api/transactions/${selectedTrackTx.id}/refund`, { method: 'POST' });
                                  if (res.ok) { onRefresh(); alert('Moderator adjudicates: refunding consumer wallet.'); }
                                }}
                                className="bg-blue-500 hover:bg-blue-600 text-white font-bold uppercase text-[10px] px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
                              >
                                💸 Simulate Dispute Refund to Buyer
                              </button>

                              <button
                                onClick={async () => {
                                  const res = await fetch(`/api/transactions/${selectedTrackTx.id}/release`, { method: 'POST' });
                                  if (res.ok) { onRefresh(); alert('Moderator signs audit passing waybills. paying out seller.'); }
                                }}
                                className="bg-emerald-500 hover:bg-emerald-600 text-slate-955 font-bold uppercase text-[10px] px-3.5 py-2 rounded-lg cursor-pointer transition-colors"
                              >
                                🏦 Simulate Dispute Payout to Seller
                              </button>
                            </>
                          )}

                          {selectedTrackTx.status === 'FUNDS_RELEASED' && (
                            <p className="text-emerald-400 font-mono text-[11px] font-bold">✓ This transaction has simulated settlement payout. Escrows cleared.</p>
                          )}

                          {selectedTrackTx.status === 'REFUNDED' && (
                            <p className="text-blue-400 font-mono text-[11px] font-bold">✓ This transaction has simulated scam refund processing complete.</p>
                          )}
                        </div>
                      </div>

                      {/* Display transaction log history */}
                      <div className="space-y-2 border-t border-slate-800 pt-3">
                        <strong className="text-white text-xs uppercase block font-mono">Simulated Audit Logs:</strong>
                        <div className="space-y-1.5 scrollbar-thin max-h-36 overflow-y-auto">
                          {selectedTrackTx.history?.map((evt, idx) => (
                            <div key={idx} className="p-2 bg-slate-950 rounded text-[10.5px] leading-relaxed font-mono">
                              <span className="text-slate-500">[{new Date(evt.timestamp).toLocaleString()}]</span>{' '}
                              <strong className="text-slate-300">({evt.actor}) {evt.title}:</strong>{' '}
                              <span className="text-slate-400">{evt.description}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>
                  )}

                  {/* DISPUTES FILING ENGINE */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 leading-relaxed text-xs">
                    
                    {/* Disputes Escalation Form */}
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                      <h4 className="text-xs font-black uppercase text-white font-mono tracking-wider border-b border-slate-800 pb-2">File Escrow Dispute Case</h4>
                      <form onSubmit={handleFileDispute} className="space-y-3 font-sans">
                        <div className="space-y-1">
                          <label className="text-slate-400">Escrow Transaction ID:</label>
                          <input 
                            type="text" 
                            required 
                            placeholder="e.g. BS-ESC-2026-00001" 
                            value={disputeForm.escrowId} 
                            onChange={(e) => setDisputeForm({...disputeForm, escrowId: e.target.value})} 
                            className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white font-mono" 
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-400">Reason for Dispute / Scam Evidence:</label>
                          <textarea 
                            required 
                            placeholder="Describe what occurred (e.g., merchant did not ship item / clone received instead)..." 
                            value={disputeForm.reason} 
                            onChange={(e) => setDisputeForm({...disputeForm, reason: e.target.value})} 
                            className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-white h-20" 
                          />
                        </div>
                        <button type="submit" className="w-full bg-red-500 hover:bg-red-600 text-white font-bold uppercase text-[10px] py-2 rounded cursor-pointer">
                          Submit Dispute & Freeze Funds
                        </button>
                        {disputeSuccess && (
                          <p className="text-[11px] text-red-400 font-mono font-bold text-center">✓ Escrow frozen instantly. Dispute cases escalated.</p>
                        )}
                      </form>
                    </div>

                    {/* FAQ */}
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3 font-sans">
                      <h4 className="text-xs font-black uppercase text-white font-mono tracking-wider border-b border-slate-800 pb-2">Knowledge Base & FAQ</h4>
                      {[
                        { q: 'How does Buy Safely handle deposit refunds?', a: 'If a seller fails to ship order cargo, clicking Cancel order initiates immediate M-Pesa refund routing.' },
                        { q: 'What is the standard dispute arbitration SLA?', a: 'Nairobi trust board reviews proof of waybills and photos, concluding adjudications in 24 hours.' },
                        { q: 'Should I share my Handover PIN with the courier early?', a: 'No! Only share the delivery PIN when you hold, inspect and verify the physical item operates correct.' }
                      ].map((faq, i) => (
                        <div key={i} className="border-b border-slate-850 pb-2 text-[11.5px]">
                          <button onClick={() => setFaqOpen(faqOpen === i ? null : i)} className="w-full text-left font-bold text-slate-150 hover:text-emerald-400 transition-colors cursor-pointer justify-between flex">
                            <span>{faq.q}</span>
                            <span>{faqOpen === i ? '▲' : '▼'}</span>
                          </button>
                          {faqOpen === i && <p className="text-slate-405 text-slate-400 mt-1 pl-1 leading-normal">{faq.a}</p>}
                        </div>
                      ))}
                    </div>

                  </div>
                </div>
              )}

              {/* 8. PARTNERS CORPORATE PAGE */}
              {publicPage === 'partners' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-8 text-left">
                  <div className="space-y-2 border-b border-slate-800 pb-5">
                    <span className="text-emerald-400 font-mono text-[10px] tracking-wider uppercase font-bold">ENTERPRISE INTEGRATIONS</span>
                    <h2 className="text-2xl font-black text-white uppercase">Corporate Bank Trust & Insurers</h2>
                    <p className="text-xs text-slate-400 leading-relaxed font-sans">
                      Our system couples banking-grade trusteeship to local payment switches. We partner with CBK, Safaricom, NCBA and insurers to verify risk pools.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-sans leading-relaxed">
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
                      <h3 className="font-extrabold text-white text-sm">🏦 NCBA Trust Custody</h3>
                      <p className="text-slate-350 select-text text-slate-400">
                        Total consumer balances are isolated 100% insideNCBA corporate cash reserve vaults. These pools are physically isolated from Buy Safely enterprise operational expenditures.
                      </p>
                    </div>

                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3">
                      <h3 className="font-extrabold text-white text-sm">🔒 CBK Fintech Sandbox</h3>
                      <p className="text-slate-350 select-text text-slate-400">
                        Buy Safely is actively licensed under the Central Bank of Kenya (CBK) FinTech Innovation regulatory sandbox for escrow disbursements, ensuring strict AML, risk velocity limits, and customer KYC compliance.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* 9. ABOUT US & CORPORATE PAGES */}
              {publicPage === 'about' && (
                <div className="max-w-4xl mx-auto px-6 py-14 space-y-8 text-left text-xs leading-relaxed font-sans">
                  <div className="space-y-2 border-b border-slate-804 border-slate-800 pb-5">
                    <span className="text-emerald-400 font-mono text-[10px]">CORPORATE IDENTITY PANEL</span>
                    <h2 className="text-2xl font-black text-white uppercase">About us / Compliance & Careers</h2>
                    <p className="text-slate-400 text-xs">Discover our company frameworks, regulatory benchmarks, and carrier rules.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                      <strong className="text-white text-xs uppercase font-bold block">About Our Mission</strong>
                      <p className="text-slate-405 text-slate-400 leading-relaxed text-[11px]">
                        We strive to make social commerce across Africa fully scam-free. By bringing corporate escrow rules to standard WhatsApp or Instagram chats, we safeguard billions in buyer deposits.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                      <strong className="text-white text-xs uppercase font-bold block">AML Compliance</strong>
                      <p className="text-slate-405 text-slate-400 leading-relaxed text-[11px]">
                        We enforce strict anti-money laundering (AML) controls. Merchant profiles face manual background validations, and single user escrow holds cap strictly at KSh 500,000 to prevent shadow banking.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                      <strong className="text-white text-xs uppercase font-bold block">Careers In Nairobi</strong>
                      <p className="text-slate-405 text-slate-400 leading-relaxed text-[11px]">
                        Join our Westlands Nairobi engineering squad. Openings exist for Senior Risk Analysts, Mobile Integration Engineers, and verified Field Inspection Pickers.
                      </p>
                    </div>
                  </div>

                  {/* Footnote about privacy and terms */}
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-[10.5px] text-slate-400 leading-relaxed font-mono">
                    <strong className="text-slate-200">Legal Disclosures & Privacy notice:</strong>
                    <p className="mt-1">
                      Buy Safely escrow reserves are Audited quarterly, secure customer KYC credentials remain shielded by the Kenya Data Protection act of 2019. Dispute review Board choices remain final.
                    </p>
                  </div>
                </div>
              )}

            </div>

            {/* CORPORATE FOOTER */}
            <div className="bg-slate-900 border-t border-slate-800 px-6 py-10 text-left text-xs text-slate-400 select-text">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="space-y-3.5">
                  <div className="flex items-center gap-1.5 text-white">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    <strong className="uppercase font-extrabold tracking-tight">Buy Safely Trust</strong>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed pr-2">
                    Social Escrow and dynamic courier inspection systems. Fully licensed under Central Bank guidelines, protecting buyers and sellers across Kenya.
                  </p>
                </div>

                <div className="space-y-2.5">
                  <strong className="text-white block uppercase text-[10px] tracking-wider font-mono">Simulated Subdomains</strong>
                  <ul className="space-y-1.5 text-[11px] text-slate-400">
                    <li><button onClick={() => { setActiveSimulatedDomain('help.buysafely.africa'); setPublicPage('support'); }} className="hover:text-emerald-400 transition-colors">help.buysafely.africa (FAQ)</button></li>
                    <li><button onClick={() => setActiveSimulatedDomain('merchant.buysafely.africa')} className="hover:text-emerald-400 transition-colors">merchant.buysafely.africa (Merchant)</button></li>
                    <li><button onClick={() => setActiveSimulatedDomain('courier.buysafely.africa')} className="hover:text-amber-500 transition-colors">courier.buysafely.africa (Delivery)</button></li>
                    <li><button onClick={() => setActiveSimulatedDomain('verify.buysafely.africa')} className="hover:text-sky-400 transition-colors font-semibold">verify.buysafely.africa (Auditors)</button></li>
                  </ul>
                </div>

                <div className="space-y-2.5">
                  <strong className="text-white block uppercase text-[10px] tracking-wider font-mono">Shared Mailing Lists</strong>
                  <div className="space-y-1 text-[11px] font-mono text-slate-400 text-left">
                    <p>Trust: <span className="text-emerald-400 select-all font-bold">info@buysafely.africa</span></p>
                    <p>Support: <span className="text-slate-300 select-all">support@buysafely.africa</span></p>
                    <p>Disputes: <span className="text-red-400 select-all font-bold">disputes@buysafely.africa</span></p>
                  </div>
                </div>

                <div className="space-y-2.5">
                  <strong className="text-white block uppercase text-[10px] tracking-wider font-mono">Corporate disclosures</strong>
                  <div className="flex flex-wrap gap-2 text-[11px] font-semibold text-slate-400">
                    <button onClick={() => setPublicPage('about')} className="hover:text-white">AML Policy</button>
                    <span>•</span>
                    <button onClick={() => setPublicPage('about')} className="hover:text-white">KRA Disclose</button>
                    <span>•</span>
                    <button onClick={() => setPublicPage('about')} className="hover:text-white">Privacy</button>
                    <span>•</span>
                    <button onClick={() => setPublicPage('about')} className="hover:text-white">Terms of Escrow</button>
                  </div>
                </div>
              </div>

              <div className="border-t border-slate-805 border-slate-800 mt-8 pt-5 text-center sm:text-left flex flex-col sm:flex-row justify-between text-[10.5px] text-slate-505 text-slate-500 gap-2">
                <span>© 2026 Buy Safely. Licensed under Central Bank Regulatory Sandbox frameworks.</span>
                <span className="font-mono">Reserve Vault Hash Identifier: NCBA-ESC-01982K</span>
              </div>
            </div>

          </div>
        )}

        {/* ========================================== */}
        {/* VIEWPORT 2: MERCHANT PORTAL (merchant.buysafely.africa) */}
        {/* ========================================== */}
        {activeSimulatedDomain === 'merchant.buysafely.africa' && (
          <div className="p-6 space-y-6 text-left flex-1 select-text">
            
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-lg uppercase">
                  HOST: merchant.buysafely.africa
                </span>
                <h3 className="text-xl font-bold text-white uppercase">Merchant Self-Service Dashboard</h3>
                <p className="text-xs text-slate-400">Manage digital checkout endpoints and track locked client funds.</p>
              </div>

              {/* Identity Picker Switch */}
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500 font-mono">Simulate Identity context:</span>
                <select 
                  value={selectedMerchantId}
                  onChange={(e) => setSelectedMerchantId(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg text-white font-bold p-1.5 cursor-pointer outline-none font-mono"
                >
                  {merchants.map(m => (
                    <option key={m.id} value={m.id}>{m.businessName} ({m.sellerHandle})</option>
                  ))}
                </select>
              </div>
            </div>

            {activeMerchant && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Account details */}
                <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs font-sans">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                    <strong className="text-white uppercase font-bold">Profile KYC Status</strong>
                    <span className="bg-emerald-950 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded font-bold border border-emerald-500/15">
                      {activeMerchant.onboardingStep || 'VERIFIED'}
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Seller Handle:</span>
                      <strong className="text-white font-mono">{activeMerchant.sellerHandle}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">KYC Mobile:</span>
                      <strong className="text-white font-mono">+{activeMerchant.phone}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Department Email:</span>
                      <strong className="text-emerald-400 font-mono select-all font-bold">{activeMerchant.email}</strong>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-slate-800">
                      <span className="text-slate-400">Trust Index Score:</span>
                      <span className="text-emerald-400 font-bold font-mono">{activeMerchant.trustRating}/100 Rating</span>
                    </div>
                  </div>

                  {activeMerchant.onboardingStep !== 'VERIFIED' && (
                    <button 
                      onClick={async () => {
                        const res = await fetch(`/api/merchants/${activeMerchant.id}/onboard`, {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ step: 'VERIFIED' })
                        });
                        if (res.ok) fetchMerchants();
                      }}
                      className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold uppercase text-[10px] py-2 rounded transition-colors cursor-pointer"
                    >
                      Verify Escrow Merchant profile
                    </button>
                  )}
                </div>

                {/* Seller stats & orders */}
                <div className="lg:col-span-8 space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                      <span className="text-[9.5px] font-mono text-slate-500 block">TOTAL VOLUME LIFE</span>
                      <h4 className="text-lg font-black text-white font-mono mt-1">KSh {activeMerchant.volumeKsh?.toLocaleString() || '184,000'}</h4>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                      <span className="text-[9.5px] font-mono text-slate-500 block">ACTIVE ESCROWS LOCKED</span>
                      <h4 className="text-lg font-black text-emerald-400 font-mono mt-1">
                        KSh {transactions
                          .filter(t => t.sellerHandle === activeMerchant.sellerHandle && t.status === 'ESCROW_HELD')
                          .reduce((sum, t) => sum + t.amount, 0)
                          .toLocaleString()}
                      </h4>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                      <span className="text-[9.5px] font-mono text-slate-500 block">DISPUTES COUNTER</span>
                      <h4 className="text-lg font-black text-red-400 font-mono mt-1">
                        {transactions.filter(t => t.sellerHandle === activeMerchant.sellerHandle && t.status === 'DISPUTED').length} active cases
                      </h4>
                    </div>
                  </div>

                  {/* Orders */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <h4 className="text-xs uppercase font-extrabold text-white border-b border-slate-800 pb-2">Ongoing Transactions for {activeMerchant.sellerHandle}</h4>
                    
                    <div className="space-y-3.5">
                      {transactions.filter(t => t.sellerHandle === activeMerchant.sellerHandle).length === 0 ? (
                        <p className="text-xs text-slate-500 text-center py-6 block font-sans">No active buy link orders found under this handle.</p>
                      ) : (
                        transactions.filter(t => t.sellerHandle === activeMerchant.sellerHandle).map((t, idx) => (
                          <div key={idx} className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs font-sans">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-slate-300">{formatEscrowId(t.id)}</span>
                                <span className={`text-[9.5px] px-1.5 py-0.5 rounded font-bold font-mono uppercase ${
                                  t.status === 'FUNDS_RELEASED' ? 'bg-emerald-950 text-emerald-400' :
                                  t.status === 'DISPUTED' ? 'bg-red-950 text-red-400' : 'bg-slate-900 text-slate-400'
                                }`}>
                                  {t.status}
                                </span>
                              </div>
                              <p className="text-slate-400 pr-1 mt-1">{t.description}</p>
                              <p className="text-[10px] text-slate-500 font-mono mt-1">Buyer contact: +{t.buyerPhone}</p>
                            </div>
                            <div className="text-right">
                              <span className="font-bold text-white font-mono block">KSh {t.amount.toLocaleString()}</span>
                              <span className="text-[10px] text-slate-500">Shipping: {t.shippingMethod || 'Courier'}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

              </div>
            )}
          </div>
        )}

        {/* ========================================== */}
        {/* VIEWPORT 3: COURIER LOGISTICS GATEWAY (courier.buysafely.africa) */}
        {/* ========================================== */}
        {activeSimulatedDomain === 'courier.buysafely.africa' && (
          <div className="p-6 space-y-6 text-left flex-1">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <span className="bg-amber-500/15 text-amber-400 border border-amber-500/20 text-[9px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-lg uppercase">
                  HOST: courier.buysafely.africa
                </span>
                <h3 className="text-xl font-bold text-white uppercase flex items-center gap-2">
                  <Truck className="w-5 h-5 text-amber-400" /> Courier waybills & Rider Dispatch
                </h3>
                <p className="text-xs text-slate-400">Independent motorcycle riders and drivers process escrow confirm waybills.</p>
              </div>
            </div>

            {/* Courier Task Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              <div className="lg:col-span-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 font-sans text-xs">
                <div className="border-b border-slate-800 pb-2">
                  <strong className="text-white uppercase font-bold text-amber-505">Logistics Guarded Account</strong>
                </div>
                
                <div className="space-y-2 leading-relaxed">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Current Identity:</span>
                    <strong className="text-white">Rider John (Boda Dispatch)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Assigned Payout Mobile:</span>
                    <strong className="text-white font-mono">+254711223344</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Completed waybills:</span>
                    <span className="text-emerald-400 font-bold font-mono">342 Deliveries</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg text-[10.5px] font-mono leading-relaxed text-slate-400 border border-slate-850">
                  <strong className="text-amber-500 uppercase block pb-1">CO-ESCROW TELEMETRY AGREEMENT:</strong>
                  Your logistics commission is physically structured inside the locked escrow. Share OTP confirm pinnacles with buyers at handover!
                </div>
              </div>

              {/* Waybills list */}
              <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs font-sans">
                <h4 className="font-extrabold text-white border-b border-slate-800 pb-2 uppercase">Your active delivery consignments</h4>
                
                <div className="space-y-3.5">
                  {transactions.filter(t => t.status === 'ESCROW_HELD' || t.status === 'ITEMS_SHIPPED').length === 0 ? (
                    <p className="text-slate-500 text-center py-6 font-sans">No physical deliveries pending transport at this moment.</p>
                  ) : (
                    transactions.filter(t => t.status === 'ESCROW_HELD' || t.status === 'ITEMS_SHIPPED').map((t, idx) => (
                      <div key={idx} className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-3">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-850 pb-2 gap-2">
                          <div>
                            <span className="font-mono font-bold text-slate-350">WAYBILL: BS-NBI-{t.id.replace(/[^0-9]/g,'')}</span>
                            <p className="text-slate-405 text-slate-400 text-[11px] block">{t.description}</p>
                          </div>
                          
                          <div className="text-right">
                            <span className="text-amber-450 text-[9.5px] px-1 rounded uppercase bg-amber-500/10 text-amber-400 border border-amber-500/15 font-mono">{t.status}</span>
                            <span className="text-white block font-mono font-bold mt-1">KSh {t.shippingFee || 300} Cargo Fee</span>
                          </div>
                        </div>

                        <div className="flex justify-between items-center text-[11px] text-slate-400">
                          <p>Buyer Coordinate: <strong className="font-mono text-slate-300">+{t.buyerPhone}</strong> • Store: <span className="text-slate-300 font-bold">{t.sellerHandle}</span></p>
                          
                          <div className="flex gap-2">
                            {t.status === 'ESCROW_HELD' && (
                              <button 
                                onClick={async () => {
                                  const res = await fetch(`/api/transactions/${t.id}/ship`, { method: 'POST' });
                                  if (res.ok) onRefresh();
                                }}
                                className="bg-amber-500 hover:bg-amber-600 font-bold uppercase text-[9.5px] text-slate-950 px-3 py-1 rounded transition-colors cursor-pointer"
                              >
                                Cargo Picked up
                              </button>
                            )}

                            {t.status === 'ITEMS_SHIPPED' && (
                              <button 
                                onClick={async () => {
                                  const res = await fetch(`/api/transactions/${t.id}/release`, { method: 'POST' });
                                  if (res.ok) onRefresh();
                                }}
                                className="bg-emerald-500 hover:bg-emerald-600 font-bold uppercase text-[9.5px] text-slate-950 px-3 py-1 rounded transition-colors cursor-pointer"
                              >
                                Complete Delivery
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* VIEWPORT 4: PRODUCT VERIFICATION PORTAL (verify.buysafely.africa) */}
        {/* ========================================== */}
        {activeSimulatedDomain === 'verify.buysafely.africa' && (
          <div className="p-6 space-y-6 text-left flex-1 font-sans">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <span className="bg-sky-500/15 text-sky-400 border border-sky-500/20 text-[9px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-lg uppercase">
                  HOST: verify.buysafely.africa
                </span>
                <h3 className="text-xl font-bold text-white uppercase flex items-center gap-2">
                  <Search className="w-5 h-5 text-sky-400" /> Picker Physical Audit Node
                </h3>
                <p className="text-xs text-slate-400">Safety inspectors certify hardware display, IMEI lockups, and overall condition.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              <div className="lg:col-span-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 text-xs">
                <h4 className="font-bold text-white border-b border-slate-800 pb-1.5 uppercase">Auditor profile</h4>
                
                <div className="space-y-2 font-mono text-slate-300">
                  <div className="flex justify-between">
                    <span>Officer Name:</span>
                    <strong className="text-white">Alex Ondieki</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Certifications:</span>
                    <strong className="text-emerald-400">Class II Approved</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Inspect count:</span>
                    <strong className="text-white">142 Cases Done</strong>
                  </div>
                </div>

                <p className="text-[10.5px] leading-relaxed text-slate-400 font-sans p-3 bg-slate-950 rounded-xl border border-slate-850">
                  Each physical audit checklist must confirm hardware functional capability and matching frame numbers before output matches certified criteria.
                </p>
              </div>

              {/* Assignments inspect checklist */}
              <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                <h4 className="font-extrabold text-white text-xs border-b border-slate-800 pb-2 uppercase">Pending Inspection Workloads</h4>
                
                <div className="grid grid-cols-1 gap-3 text-xs">
                  {inspections.map((job, idx) => (
                    <div key={idx} className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl space-y-2.5">
                      <div className="flex justify-between items-center font-mono">
                        <span className="font-bold">ITEM SPEC: {job.id}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] ${job.status === 'VERIFIED' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-955 bg-amber-950 text-amber-500'}`}>{job.status}</span>
                      </div>
                      <div>
                        <h4 className="font-extrabold text-white">{job.title}</h4>
                        <p className="text-slate-400">Seller page Ref: {job.seller} • Declared Pricing: {job.price}</p>
                      </div>
                      {job.status === 'PENDING_INSPECTION' && (
                        <button 
                          onClick={() => {
                            const clone = [...inspections];
                            clone[idx].status = 'VERIFIED';
                            setInspections(clone);
                          }}
                          className="bg-sky-500 hover:bg-sky-600 text-slate-95) text-slate-950 font-black uppercase text-[10px] w-full py-2 rounded cursor-pointer mt-1"
                        >
                          Submit Inspector Pass Certificate (Update product)
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* VIEWPORT 5: INTEGRATED HELP CENTRE (help.buysafely.africa) */}
        {/* ========================================== */}
        {activeSimulatedDomain === 'help.guysafely.africa' || activeSimulatedDomain === 'help.buysafely.africa' && (
          <div className="p-6 space-y-6 text-left flex-1 font-sans">
            <div className="bg-slate-900 border border-slate-850 p-5 rounded-2xl text-center space-y-3">
              <span className="bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[9px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded uppercase">
                HOST: help.buysafely.africa
              </span>
              <h2 className="text-2xl font-black text-white uppercase tracking-tight">Customer Trust Knowledge Hub</h2>
              <p className="text-xs text-slate-400 max-w-xl mx-auto">
                Read support articles, understand dispute resolution codes, escalate scams and report fraudulent checkout links.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 leading-relaxed">
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4">
                <h4 className="text-xs font-black uppercase text-white font-mono tracking-wider border-b border-slate-800 pb-2">File Dispute on Social deal</h4>
                <p className="text-xs text-slate-400 font-sans">
                  If an item did not arrive, contains severe damages or the seller blocked your contact, upload details immediately here. Funds lock in safe blockages.
                </p>
                <form onSubmit={handleFileDispute} className="space-y-3 font-sans text-xs">
                  <div className="space-y-1">
                    <label className="text-slate-450 text-slate-400">Escrow Transaction ID:</label>
                    <input type="text" required placeholder="e.g. BS-ESC-2026-00001" value={disputeForm.escrowId} onChange={e=>setDisputeForm({...disputeForm, escrowId: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-450 text-slate-400">Anti-Scam report description:</label>
                    <textarea required placeholder="Item arrives damaged / blocked my phone..." value={disputeForm.reason} onChange={e=>setDisputeForm({...disputeForm, reason: e.target.value})} className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white h-20" />
                  </div>
                  <button type="submit" className="w-full bg-red-500 hover:bg-red-650 text-white font-bold uppercase tracking-wider py-2 rounded text-[10px]">
                    Freeze Escrow & Send Case File
                  </button>
                  {disputeSuccess && (
                     <p className="text-[11px] text-red-400 font-mono text-center">✓ Case escalated. Reserved balances locked pending Nairobi review.</p>
                  )}
                </form>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-3 font-sans">
                <h4 className="text-xs font-black uppercase text-white font-mono tracking-wider border-b border-slate-800 pb-2">Support Articles</h4>
                <div className="space-y-3 text-xs text-slate-350">
                  <div className="p-3 bg-slate-950/70 border border-slate-850 rounded hover:bg-slate-955 transition-all">
                    <strong className="text-slate-100 block pb-1">When does blocked escrow pay out to Sellers?</strong>
                    <span className="text-[11px] text-slate-400 block font-sans">Payout triggers instantly when the buyer signs the Handover OTP check or when Fargo confirms waybills delivery.</span>
                  </div>
                  <div className="p-3 bg-slate-950/70 border border-slate-850 rounded hover:bg-slate-955 transition-all">
                    <strong className="text-slate-100 block pb-1">What if the seller cancels checkout?</strong>
                    <span className="text-[11px] text-slate-400 block font-sans">If dispatch is not generated, funds refund instantly to Safaricom/Airtel customer phone registries.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Persistent Floating Cart Widget & Toast Notifications */}
        {cartItems.length > 0 && activeSimulatedDomain === 'www.buysafely.africa' && (
          <div 
            id="floating-cart-widget"
            className="fixed bottom-6 right-6 z-45 bg-slate-950 border border-emerald-500/30 p-4 rounded-2xl shadow-[0_15px_30px_rgba(16,185,129,0.15)] flex items-center justify-between gap-6 max-w-sm animate-fade-in font-sans text-left"
          >
            <div className="text-left space-y-1">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-[10px] font-black font-mono uppercase tracking-widest text-emerald-400">Escrow Cart Active</span>
              </div>
              <p className="text-xs font-bold text-white">
                {cartItems.reduce((acc, item) => acc + item.quantity, 0)} Items Selected
              </p>
              <p className="text-xs font-mono font-bold text-slate-300">
                Subtotal: <span className="text-emerald-400 font-extrabold">KSh {cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0).toLocaleString()}</span>
              </p>
            </div>
            
            <button
              onClick={() => {
                setSimulatedPath('/cart');
              }}
              className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black uppercase px-4 py-2.5 rounded-xl cursor-pointer transition-all active:scale-95 flex items-center gap-1 shrink-0"
            >
              <Package className="w-3.5 h-3.5" />
              <span>View Cart</span>
            </button>
          </div>
        )}

        {/* Global Cart Toast Notification */}
        <AnimatePresence>
          {cartToast && (
            <motion.div 
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.9 }}
              className="fixed top-24 right-6 z-50 bg-slate-900 border border-emerald-500/45 p-4 rounded-xl shadow-2xl flex items-center gap-3 text-xs text-white font-sans max-w-sm"
            >
              <div className="bg-emerald-500/10 text-emerald-400 p-2 rounded-lg">
                <Package className="w-4 h-4" />
              </div>
              <div>
                <p className="font-bold uppercase tracking-wide text-emerald-400 text-[10px] font-mono">Cart Notification</p>
                <p className="text-slate-200 mt-0.5">{cartToast}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sliding Cart Drawer Overlay */}
        <AnimatePresence>
          {showCartDrawer && (
            <div className="fixed inset-0 z-50 overflow-hidden font-sans text-left">
              {/* Backdrop */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowCartDrawer(false)}
                className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
              />

              {/* Slider Content */}
              <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
                <motion.div 
                  initial={{ x: '100%' }}
                  animate={{ x: 0 }}
                  exit={{ x: '100%' }}
                  transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                  className="w-screen max-w-md bg-slate-900 border-l border-slate-800 text-slate-100 flex flex-col justify-between"
                >
                  {/* Header */}
                  <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950">
                    <div className="flex items-center gap-2">
                      <Package className="w-5 h-5 text-emerald-400" />
                      <div>
                        <h3 className="font-extrabold text-white text-sm uppercase">Smart Merchant Cart</h3>
                        <p className="text-[10px] text-slate-400 font-mono">SELLER: {cartItems[0]?.product.sellerHandle}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setShowCartDrawer(false)}
                      className="text-slate-400 hover:text-white text-xs font-bold font-mono px-3 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg cursor-pointer"
                    >
                      Close
                    </button>
                  </div>

                  {/* Items list */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-4">
                    {cartItems.length === 0 ? (
                      <div className="text-center py-12 space-y-3">
                        <Package className="w-12 h-12 text-slate-600 mx-auto" />
                        <p className="text-xs text-slate-400 font-sans">Your escrow cart is empty.</p>
                      </div>
                    ) : (
                      <>
                        <div className="space-y-3">
                          {cartItems.map((item) => (
                            <div key={item.product.id} className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-2">
                              <div className="flex justify-between items-start gap-2">
                                <div>
                                  <h4 className="font-bold text-white text-xs leading-snug">{item.product.title}</h4>
                                  <p className="text-[10px] text-emerald-400 font-mono font-bold">KSh {item.product.price.toLocaleString()}</p>
                                </div>
                                <button 
                                  onClick={() => handleRemoveFromCart(item.product.id)}
                                  className="text-[10px] text-red-400 hover:text-red-300 font-mono uppercase cursor-pointer shrink-0"
                                >
                                  Remove
                                </button>
                              </div>

                              <div className="flex justify-between items-center pt-1 border-t border-slate-850/60">
                                <div className="flex items-center gap-2">
                                  <button 
                                    onClick={() => handleUpdateCartQty(item.product.id, item.quantity - 1)}
                                    className="w-6 h-6 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-center text-xs font-mono text-slate-400 cursor-pointer"
                                  >
                                    -
                                  </button>
                                  <span className="text-xs font-black font-mono w-4 text-center">{item.quantity}</span>
                                  <button 
                                    onClick={() => handleUpdateCartQty(item.product.id, item.quantity + 1)}
                                    className="w-6 h-6 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-center text-xs font-mono text-slate-400 cursor-pointer"
                                  >
                                    +
                                  </button>
                                </div>

                                <span className="text-xs font-bold text-white font-mono">
                                  KSh {(item.product.price * item.quantity).toLocaleString()}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Order configuration fields */}
                        <div className="pt-4 border-t border-slate-800 space-y-4 text-xs">
                          {/* Shipping packages choice */}
                          <div className="space-y-1.5">
                            <span className="text-slate-400 font-mono text-[9.5px] uppercase tracking-wider block">Package Logistics Architecture:</span>
                            <div className="grid grid-cols-2 gap-2">
                              <button 
                                onClick={() => setShippingPackageStructure('SINGLE')}
                                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${shippingPackageStructure === 'SINGLE' ? 'bg-emerald-950/20 border-emerald-500' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                              >
                                <span className="font-extrabold text-[10px] text-white">Consolidated</span>
                                <span className="text-[9px] font-mono leading-none mt-1">1 Package • KSh 300 Courier</span>
                              </button>
                              <button 
                                onClick={() => setShippingPackageStructure('STAGGERED')}
                                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${shippingPackageStructure === 'STAGGERED' ? 'bg-emerald-950/20 border-emerald-500' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                              >
                                <span className="font-extrabold text-[10px] text-white">Staggered (Multi)</span>
                                <span className="text-[9px] font-mono leading-none mt-1">Multi-Package • KSh 500 Courier</span>
                              </button>
                            </div>
                          </div>

                          {/* Insurance Choice */}
                          <div className="space-y-1.5">
                            <span className="text-slate-400 font-mono text-[9.5px] uppercase tracking-wider block">Insurance Coverage Level:</span>
                            <div className="grid grid-cols-2 gap-2">
                              <button 
                                onClick={() => setInsuranceStructure('ORDER')}
                                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${insuranceStructure === 'ORDER' ? 'bg-emerald-950/20 border-emerald-500' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                              >
                                <span className="font-extrabold text-[10px] text-white">Order Level</span>
                                <span className="text-[9px] font-mono leading-none mt-1">KSh 450 Standard Premium</span>
                              </button>
                              <button 
                                onClick={() => setInsuranceStructure('ITEM')}
                                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-colors cursor-pointer ${insuranceStructure === 'ITEM' ? 'bg-emerald-950/20 border-emerald-500' : 'bg-slate-950 border-slate-850 text-slate-400 hover:border-slate-800'}`}
                              >
                                <span className="font-extrabold text-[10px] text-white">Item Level</span>
                                <span className="text-[9px] font-mono leading-none mt-1">KSh 150 per item (Toggle below)</span>
                              </button>
                            </div>
                          </div>

                          {insuranceStructure === 'ITEM' && (
                            <div className="space-y-2 p-2.5 bg-slate-950 border border-slate-850 rounded-xl">
                              <span className="text-[9px] font-mono text-slate-450 block uppercase tracking-wider">Configure Insured Items:</span>
                              {cartItems.map((item) => (
                                <div key={item.product.id} className="flex justify-between items-center text-[11px]">
                                  <span className="text-slate-300 truncate max-w-[200px]">{item.product.title}</span>
                                  <button 
                                    onClick={() => handleToggleItemInsurance(item.product.id)}
                                    className={`px-2 py-1 rounded font-mono text-[9px] uppercase cursor-pointer ${item.insured ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' : 'bg-slate-900 text-slate-500 border border-slate-800'}`}
                                  >
                                    {item.insured ? 'Insured (KSh 150)' : 'Uncovered'}
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}

                          {insuranceStructure === 'ORDER' && (
                            <div className="space-y-1.5">
                              <span className="text-slate-400 font-mono text-[9.5px] uppercase tracking-wider block">Order-Level Plan:</span>
                              <div className="grid grid-cols-3 gap-1.5 font-mono text-[9px]">
                                {['NONE', 'BASIC', 'ENHANCED'].map((opt) => (
                                  <button 
                                    key={opt}
                                    onClick={() => setOrderInsuranceOption(opt as any)}
                                    className={`p-2 rounded-lg border text-center transition-all cursor-pointer ${orderInsuranceOption === opt ? 'bg-emerald-950/20 border-emerald-500 text-white font-bold' : 'bg-slate-950 border-slate-850 text-slate-500'}`}
                                  >
                                    {opt === 'NONE' ? 'None' : opt === 'BASIC' ? 'Basic (450)' : 'Enhanced (1200)'}
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>

                  {/* Summary & Checkout CTA */}
                  {cartItems.length > 0 && (
                    <div className="p-6 border-t border-slate-800 bg-slate-950 space-y-4">
                      {/* Subtotal maths */}
                      <div className="space-y-1.5 text-xs leading-normal">
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Cart Subtotal:</span>
                          <span className="font-bold text-white font-mono">
                            KSh {cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Shipping Mode:</span>
                          <span className="font-mono text-slate-200">
                            {shippingPackageStructure === 'SINGLE' ? 'Consolidated (KSh 300)' : 'Staggered (KSh 500)'}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Secure Escrow Protection:</span>
                          <span className="text-emerald-400 font-mono font-bold">FREE (0.00%)</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Platform & Trust Node Node:</span>
                          <span className="font-mono text-slate-300">
                            KSh {Math.max(Math.round(cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0) * 0.01), 25).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Insurance Protection Premium:</span>
                          <span className="font-mono text-slate-300">
                            KSh {(() => {
                              if (insuranceStructure === 'ORDER') {
                                return orderInsuranceOption === 'BASIC' ? 450 : orderInsuranceOption === 'ENHANCED' ? 1200 : 0;
                              } else {
                                return cartItems.reduce((acc, item) => acc + (item.insured ? 150 * item.quantity : 0), 0);
                              }
                            })().toLocaleString()}
                          </span>
                        </div>

                        <div className="flex justify-between items-center pt-3 border-t border-slate-800 text-sm font-black text-white">
                          <span>TOTAL SECURED ESCROW:</span>
                          <span className="text-emerald-400 font-mono">
                            KSh {(() => {
                              const sub = cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
                              const ship = shippingPackageStructure === 'SINGLE' ? 300 : 500;
                              const plat = Math.max(Math.round(sub * 0.01), 25);
                              const ins = insuranceStructure === 'ORDER' 
                                ? (orderInsuranceOption === 'BASIC' ? 450 : orderInsuranceOption === 'ENHANCED' ? 1200 : 0)
                                : cartItems.reduce((acc, item) => acc + (item.insured ? 150 * item.quantity : 0), 0);
                              return (sub + ship + plat + ins);
                            })().toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {/* Checkout CTA */}
                      <button 
                        onClick={() => {
                          setShowCartDrawer(false);
                          setSimulatedPath(`/pay/cart`);
                        }}
                        className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black uppercase py-3.5 rounded-2xl text-xs tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-emerald-500/10"
                      >
                        <Lock className="w-4 h-4 text-slate-950" />
                        <span>Checkout Safely via Escrow</span>
                      </button>
                    </div>
                  )}

                </motion.div>
              </div>
            </div>
          )}
        </AnimatePresence>

      </div>

    </div>
  );
}
